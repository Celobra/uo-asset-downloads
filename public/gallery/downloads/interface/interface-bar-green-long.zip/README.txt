Bar Green Long

Before importing: close the client and asset editors, check access to every file to be saved, and back up the current development data. Use verified unused destination IDs. Keep MUL/IDX pairs together, preserve other entries and use the data bank/container the client actually reads. These downloads do not contain UO client data, accounts or world saves. Install matching client art for every player. Check the result in game before using it on a live shard.

PNG interface artwork at its supplied dimensions. This is a design/component file; no ready-to-import gump IDs, UI assembly or client layout code are supplied. Fit and integrate it into your own interface before use.
