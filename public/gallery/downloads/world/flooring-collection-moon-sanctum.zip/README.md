# Moon sanctum mosaic

This is one selected family from the collection. The included manifest lists its files. No destination IDs are assigned.

## Assemble a floor

Choose a world origin X,Y and a constant floor Z. Place `name-x0-y0` there; place `name-x1-y0` one world tile along the X axis, and `name-x0-y1` one world tile along Y. Continue through x0–3 and y0–3. Repeat the complete 4×4 unit to fill larger rooms. Do not shuffle patterned cells. The sun, moon and serpent designs make one medallion per 4×4 unit; use a single unit as a centerpiece or repeat them as shown.

`manifest.json` give every floor cell's coordinates and relative filename. Item-art IDs are unassigned. Allocate verified free slots in the target client, import the PNGs or BMPs, and configure matching tiledata/server definitions. A height-zero Surface floor is appropriate for small cells intended to support walking, subject to target-server testing. The decorative 176×176 full panel does not create a walkable 4×4 platform; use small floor cells or underlying terrain for player access.

The `.bin` files are individual encoded static-art records. They are not complete `art.mul`/`artidx.mul` archives and must not replace those files. The package performs no installation and contains no live client data, server accounts, saves or allocated IDs.

