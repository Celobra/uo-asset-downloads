# Craft Storage Collection

Eight furniture designs in two opposing facings: 16 native static-art records. The reagent shelf, cloth-bolt rack, potion shelf, scroll cabinet, herbalist drawers, leather rack, ore bin and tool rack share worn oak construction.

## Revised furniture

Version 2 replaces the patterned wall-like texture with newly generated fine oak grain. It adds thicker side panels and posts, shelf lips, projecting cornices, drawer fronts and brass pulls, reinforced feet and iron bindings. Cloth bolts use restrained colours selected from the native UO hue palette; the original reagent sprites remain unchanged. The original release remains separate.

## Artwork and placement

Furniture uses exact UO screen projection: 22 pixels along either diagonal tile axis and 4 vertical pixels per z unit. The two facings swap the physical x/y axes; they are not identical pictures with different labels. Cabinet depth is intentionally shallow so the shelf openings remain readable at the native camera angle. Contents retain their original UO shapes and scale; only the cloth bolts receive native UO dyes. The eight reagent source IDs are 0x0F7A, 0x0F7B, 0x0F84, 0x0F85, 0x0F86, 0x0F88, 0x0F8C and 0x0F8D. All sixteen reagent placements were compared pixel-for-pixel with these source sprites after native conversion.

Every delivered piece has a 96×208 canvas. Do not crop its padding or move its artwork when importing: it preserves the shared ground anchor. Standard drawing offset is (-width/2, 44-height). Frames span about 2.8 tiles along their long axis and 0.4 tile in depth, centred around the item anchor; allow a three-cell-wide placement area. A single item does not automatically provide a multi-cell collision footprint. For strict collision/house placement, configure an addon or suitable blocking components for the target shard. Pixel-grid previews verify artwork projection, not live placement or player movement.

The taller reagent shelf is 30z high; individual recommended heights are in the manifest. Check clearance against house walls and ceilings. PNG preserves transparency, BMP uses black outside the silhouette, and BIN contains one encoded static-art record, not a full art.mul replacement. No IDs are reserved or allocated. Import into free slots verified against current client data and merge only those records. Keep the full padded canvas. Configure item height and container/collision flags against the target client and server.

## Optional Sphere container definitions

After assigning and importing 16 unused art IDs, fill each blank value in art-id-mapping.json with its matching hexadecimal ID, for example a string beginning 0x. Then run:

    python make_sphere.py art-id-mapping.json craft_storage.scp

The generator refuses missing, duplicate, malformed and source-item IDs. It cannot determine whether your chosen slots are occupied by unrelated content; inspect the actual target first. The output defines normal empty t_container objects using the standard armoire container gump. Load the resulting script through the target shard's normal script configuration. No installer is supplied and the generator does not edit a client or server. Test after import before use on a live shard.

These are general containers. Reagent filtering, resource counts, sorting, restocking and crafting access are not implemented. Visible contents are decorative and do not change with container contents. House lockdown/security and ownership use the shard's existing house system; the package grants no special permissions. Two separate facing definitions are supplied; the script does not rotate a placed container automatically.

## Checks and remaining acceptance

All 16 records pass native RGB555 color/transparency round-trips. All 32 projected diagonal axes have equal x/y pixel displacement. All eight original reagents in both shelf facings survive pixel-identical in the delivered art. Public links, archive CRC and private-path scans are checked. The container generator is exercised with a test-only mapping, including duplicate/blank rejection. It has not been loaded into a running Sphere server.

Remaining in-game checks: client art mapping, world anchor, selection bounds, ceiling/overhead occlusion, orientation next to original furniture, collision/addon footprint, container gump, item storage/retrieval, housing security and hues. No installation, publication, account/world-save changes or game asset allocation is included.


Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
