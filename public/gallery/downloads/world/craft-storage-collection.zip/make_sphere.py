"""Generate container definitions after the recipient assigns free imported art IDs."""
import argparse,json
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('mapping',type=Path);parser.add_argument('output',type=Path)
args=parser.parse_args();root=Path(__file__).resolve().parent
rows=json.loads((root/'manifest.json').read_text());mapping=json.loads(args.mapping.read_text())
if set(mapping)!=set(r['name'] for r in rows):raise SystemExit('Mapping must contain exactly the 16 names in art-id-mapping.json.')
ids={}
for name,value in mapping.items():
    if not isinstance(value,str) or not value.startswith('0x'):raise SystemExit('Every ID must be a filled hexadecimal string beginning 0x.')
    try:tid=int(value,16)
    except ValueError:raise SystemExit('Invalid art ID for '+name)
    if not 0<tid<=65535:raise SystemExit('Art ID out of range.')
    ids[name]=tid
if len(set(ids.values()))!=16:raise SystemExit('Art IDs must be unique.')
source_ids={int(r['id'],16) for r in json.loads((root/'native-content-sources.json').read_text())}
if source_ids.intersection(ids.values()):raise SystemExit('Mapping would overwrite a native source item.')
lines=['// Craft Storage: imported custom art; normal empty containers.','// Configure housing security using the shard normal house system.','']
for row in rows:
    name=row['name'];tid=ids[name];defname='i_craft_storage_'+name.replace('-','_')
    lines += [f'[ITEMDEF 0{tid:x}]',f'DEFNAME={defname}',f'NAME={name.replace("-"," ")}', 'TYPE=t_container','TDATA2=04f','TDATA3=0180060','TDATA4=0600098','WEIGHT=25','CATEGORY=Custom Items','SUBSECTION=Craft Storage',f'DESCRIPTION={name.replace("-"," ")}','']
lines+=['[EOF]'];args.output.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Wrote 16 normal container definitions. Art import and tiledata setup must already match these IDs.')
