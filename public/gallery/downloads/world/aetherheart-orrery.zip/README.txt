THE AETHERHEART

A captive star in an ancient stone-and-brass engine.

This is animated ITEM ART. It is not a creature or wearable VD.
It has no player paperdoll or equipment actions because it is a world object.

IMPORT PREPARATION
1. Back up your client data and work on an isolated copy. Find and verify
   130 consecutive free item-art IDs. None have been assigned by this pack.
   Check current art, tiledata, animdata, server scripts and custom mappings.
2. Run Prepare-Import.ps1 with your chosen decimal or hexadecimal BaseId.
   It verifies image hashes and creates Import/massimport.xml, tiledata.csv,
   animdata.json and selected-range.txt inside this extracted folder.
   It does not install anything or change client/server data.
3. Import that prepared XML into your compatible UOFiddler workflow, then
   import the AnimData JSON through its animation-data editor. Verify all
   selected ranges and merge with CURRENT data, preserving unrelated records.
4. The working decorative loop is BaseId + 33. Dormant is BaseId. Inventory
   is BaseId + 129 and must be assigned to a separate deed/figurine definition
   if desired. The world object should be immovable, not a backpack item.

Only the active-loop base gets the Animation tile flag in the prepared rows.
The other frames stay static so a future server controller can show awakening
and sleep by stepping through their IDs in order. Three AnimData records are
included for inspection/alternative integration; native animated statics loop
globally and cannot guarantee that an individual new item starts at frame zero.
An automatic one-shot awakening is NOT implemented by merely importing art.

The preview uses nominal 100 ms/frame, matching ClassicUO's animated-static
path (50 ms constant doubled, plus scheduler overhead). This gives 3.2 seconds
to awaken/sleep and a 6.4-second active loop. Location effects use a different
timing path; do not copy their 50 ms rule onto this world item.

Normal blending preserves dark stone and brass. Do not set additive blending
on the complete object. The gold/blue core is painted luminosity; dynamic
world lighting is not included. All world frames retain the SAME dimensions
and registration. Do not auto-trim them individually during import.

Tile rows suggest an immovable, impassable centre and height 12 as starting
values. A single item does not automatically block its whole visible footprint.
The dais is wider than one tile. Choose a suitable open placement and validate
multi-tile collision, depth ordering, selection and ground alignment in game.

STATUS
Import-candidate artwork. No production IDs allocated, no installed assets,
no world saves/accounts changed. Preview controls demonstrate the intended
sequence. Quest, guildhall, encounter, ownership and interaction mechanics are
not implemented. Native decoder and package checks are recorded in
VALIDATION.txt; actual client appearance and gameplay acceptance remain open.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
