# Haunted Mirror v2 — both facings

32 native item records:16 original-facing frames and16 opposite-facing frames. Original files are byte-identical to v1. The opposite facing was created with a built-in image edit of the original atlas, retaining the emergence/withdrawal sequence. Minor generated detail differences are present.

Use a separate16-ID consecutive free block for each facing,32 IDs total, and apply each folder's relative animation record to its own base. Normal blend;96x160 canvas; origin48,116;200ms preview frames. Do not combine into one32-frame sequence. See each folder for PNG/BMP/BIN files and detailed import notes. No IDs allocated, installation or live gameplay tests. Original v1 release preserved separately.


Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
