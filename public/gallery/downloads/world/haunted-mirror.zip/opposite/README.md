# The Guest Behind the Glass

A haunted standing mirror for UO house decoration.16 unique frames, one facing,96x160 canvas. Ghostly face and hands emerge, stare outward and withdraw. Preview plays at200ms/frame (3.2seconds). No sound, proximity trigger, combat or house-deed script included.

Enable Animated on the base tiledata item. animdata-record.bin is one68-byte record for the base ID, with offsets0–15, count16, interval4, start0 and unknown0. It is not a whole animdata.mul. Create the matching server decorative item and configure its height/collision after placement checks. No installation helper is included. All users need matching art. Check animation timing, floor registration, furniture scale, ordinary-player access, occlusion and house placement in your client.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
