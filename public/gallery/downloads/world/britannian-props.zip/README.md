# Britannian Props v1

16 decorative designs in two facings: 32 native UO item sprites.

- Stone altar
- Ironbound coffer
- Smith workbench
- Tailor worktable
- Scribe desk
- Canvas market stall
- Supply crate stack
- Firewood rack
- Bucket and winding stand
- Stone washstand
- Arms rack
- Village stocks
- Stone garden bench
- Book lectern
- Barrels and freight pallet
- Traveller bedroll

Choose unused item-art IDs in your current client using an art editor. Back up current client data before importing. Import each piece independently, then configure matching tiledata and server item definitions for those IDs. The manifest deliberately leaves art_id empty; suggested_height is a starting value for testing, not a validated collision definition. Source IDs in native-sources.json identify existing stock art used for small supplies and must not be treated as destination IDs.

These are static decorative graphics. They do not include opening lids, animation, usable crafting stations, containers, sitting, restraint or other scripts. Large objects may occupy more than one tile visually; a single art record does not automatically provide collision across its whole footprint. Allow generous spacing and configure blocking appropriately. Test ordinary-player movement, ground registration, clipping, occlusion and both facings in your target client before release. No client files were patched and no in-game placement test is claimed.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
