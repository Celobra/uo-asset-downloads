Existing-tile Cottage

Before importing: close the client and asset editors, check access to every file to be saved, and back up the current development data. Use verified unused destination IDs. Keep MUL/IDX pairs together, preserve other entries and use the data bank/container the client actually reads. These downloads do not contain UO client data, accounts or world saves. Install matching client art for every player. Check the result in game before using it on a live shard.

FIELDSTONE TERRACE COTTAGE

Uses ONLY existing UO tiles. No artwork changes, new client IDs or client patch.
9x11 foundation, fieldstone cottage, brown roof, continuous wooden terrace,
open sides, low front stone wall, steps, bench and two planters.

INSTALL
Put terrace_cottage.scp under scripts/items and load it through your normal
Sphere script resources. Register the script once through your own spheretables.scp.
Start the server normally, or reload scripts if the server is already running.
This script defines f_multi_setup, Sphere's native post-placement hook.
If another package already defines that function, merge the hook instead of
loading two definitions. Check your own server for this conflict.

HOUSE DEED
As an administrator, use:
.add i_deed_terrace_cottage
Put the deed in your backpack, open the backpack, and double-click the deed.
Select a valid house location. The placement preview shows the native 9x11
foundation; the full cottage is applied after placement succeeds.
Normal housing limits and placement checks still apply. A successful placement
consumes the deed and assigns the normal owner and sign. Cancellation or
rejected placement keeps the deed. Demolition returns a cottage deed.
No price or vendor sale has been configured.

EXISTING EMPTY FOUNDATION (STAFF ALTERNATIVE)
.terrace_cottage
Target the sign of an untouched 9x11 customizable foundation. This refuses
changed designs and foundations to which the cottage has already been applied.

