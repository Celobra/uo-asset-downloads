# Great Brass Engine v2 — smooth rigged animation

32 native208x256 frames,50ms preview cadence,1.6second loop. A fixed generated body replaces the changing full-frame atlas. Separate wheel/rod/steam artwork is transformed with deterministic motion, fourfold supersampling and a common canvas. The crank drives a constant-screen-length connecting rod; this is a2D visual rig, not a full3D engineering simulation. Lower platform pixels are identical in every frame. Render phase1 equals phase0 exactly.

Use32 verified unused consecutive item-art IDs. No IDs allocated. Back up current data; import PNG/BMP or individual BIN static-art records. Keep padding and normal blend. Set Animated at base and apply provided68-byte AnimData record there: offsets0–31,count32,interval1,start0. Record is not an entire animdata.mul. V1 used16 frames: do not apply v2 to its16-ID allocation without checking the extra records are free. Original v1 retained separately.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
