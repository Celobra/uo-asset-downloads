# The Watchful Tower

An animated Eye of Sauron tower for UO: 16 unique frames with moving pupil and flickering fire, while the same tower pixels remain fixed. This is decorative scenery, not a moving vehicle, enterable building or scripted attack.

Import all 16 frames into consecutive UNUSED item-art IDs in your current client. No IDs are reserved by this package. Back up your current data first. Configure matching tiledata; enable Animated on the first frame. Apply animdata-record.bin to that base ID using a compatible animation editor: offsets 0 through 15, frame count16, FrameInterval3, FrameStart0, unknown0. This 68-byte record is not a whole animdata.mul. Use normal blending to retain opaque masonry and pupil. Timing should be checked in your client.

Create a server scenery item using the selected base art ID. Collision is not supplied: the base is visually several tiles wide, so a single blocking tile is insufficient. Configure a footprint or inaccessible placement deliberately. No install script, server behaviour or destination tiledata is included. Check ground anchor, large-sprite occlusion, screen clipping, player access and animation timing in-game before use. All users need matching client art.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
