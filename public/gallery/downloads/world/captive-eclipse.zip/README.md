# The Captive Eclipse

Animated UO house relic: a restrained black sun opens into a fiery eye, releases curling shadow tendrils and closes again.16 unique frames, one view,160x208 native canvas. Preview3.2seconds at200ms/frame. Static carved details have minor generated variation; this is not a pixel-locked mechanical simulation.

Import into16 consecutive VERIFIED UNUSED item-art IDs. None are allocated. Back up current data first. BINs are individual static-art records, not complete art.mul. Enable Animated on the base item and apply the provided68-byte animdata-record.bin to that base: relative offsets0–15, count16, interval4, start0, unknown0. It is not a complete animdata.mul. Create matching server decoration and test collision/height. All users need matching client assets.

This is visual decoration only: no damage, light-emission script, proximity behaviour, sounds, deed or installation helper. Base spans multiple tiles visually; configure footprint and player blocking deliberately. Test native timing, scale in a house, occlusion, floors and player access before release. All16 native colour/alpha round trips, uniqueness and baseline checks passed. Contact sheet inspected; no live test claimed.


Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
