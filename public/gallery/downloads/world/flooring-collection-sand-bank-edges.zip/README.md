# Sand Bank Terrain Edges

This is one selected family from the collection. The included manifest lists its files. No destination IDs are assigned.

# Mountain and land edges

Four terrain sets accompany the 30 flooring designs:

- Grass land bank: olive grass above exposed earth.
- Sandy land bank: pale sand above exposed earth.
- Rocky mountain edge: fractured grey rock cap and cliff face.
- Snowy mountain edge: snowy cap above grey cliff rock.

Each set includes 16 flat ground-transition masks and 24 upright pieces: two visible straight-face orientations plus an outer corner, at two heights, with four face-texture variations. Total: **64 ground pieces + 96 upright edge pieces = 160 terrain assets**. All include PNG, BMP and native static-art records. See `manifest.json` for filenames and sizes/roles; art IDs are unallocated.

## Ground transitions

The corner-mask convention matches the earlier Sky & Shore pack: top=1, right=2, bottom=4, left=8. Sum foreground corners to choose masks 00–15. Mask 15 is the terrain cap; 00 is the surrounding base material. Grass and sand merge to earth, rock merges to earth, snow merges to rock. Matching neighboring edges must agree at both corners. These are flat 44×44 floor diamonds.

## Upright rims

`left` and `right` describe the visible face on the screen; `corner` includes both front-facing walls. Use only the face exposed at an edge. Build inward turns by joining separate left/right runs around a recessed area; the included notched-island previews demonstrate this. These are regular grid-based, terraced rims; they do not contain standalone mountain peaks or curved terrain geometry.

`h16` and `h32` denote visual height differences of 16 or 32 Z units, rendered at four pixels per Z unit. Artwork is 44×108 or 44×172. The cap sits at the top of the sprite and the face extends downward. The same-height pieces advance one map cell along a run. Variants `v0`–`v3` sample different parts of the cliff/earth texture; cycle them for variation. The preview uses decoded native sprites, not a painted scene.

These are **scenery assets**, not functional slopes or automatic collision. Configure server/tiledata behavior deliberately. Provide separate terrain or small floor surfaces at the cap elevation for player walking, and block exposed drops as needed. The visible cap is part of an upright image and does not automatically create a walkable surface at its displayed height. Confirm the item's actual in-game anchor and Z alignment before building a large area. In-game placement and player access have not yet been tested.

The gallery includes complete piece catalogs for each set, examples of inside turns, and both heights. Assembly and catalogue previews are available on the website.
