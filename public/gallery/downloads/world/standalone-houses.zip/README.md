# Twenty Standalone Houses of Britannia

Twenty newly composed houses using existing original UO art. Foundations follow each building footprint, with small entrance steps and no square custom-house platform. Ten compact single-block designs and ten houses with lower side wings; one to three floors. Side wings have independent exterior entrances. This collection is separate from the older Native House Collection.

Gallery.html contains exterior, ground cutaway, roof-hidden and upper-level images. They are native tile compositions, not live screenshots. Each folder contains exact layout.json, components.csv and two versions of the same native multi record: multi-12.bin for legacy12-byte components and multi-16.bin for16-byte components. These are individual records, not complete multi.mul files. Door art is omitted from static multi records and supplied separately as dynamic fixtures in the server template. No new art IDs are required.

Installation preparation:
1. Back up current client/server files and select20 verified unused multi IDs in the recipient client. No IDs have been selected or reserved here.
2. Import each chosen-format multi record into the matching unused slot using a compatible editor. Keep index and MUL/UOP data consistent. All players need the same multis.
3. Copy standalone-houses.scp.in to a task-local .scp file, replace every @MULTIID_nn@ with that house's allocated hexadecimal multi ID, and review region/door/sign/storage settings. The template is deliberately not loadable with unresolved tokens. It uses ordinary t_multi houses, not square custom-house foundations.
4. Test in an isolated Sphere/client environment before installing. Corresponding deeds are named i_deed_standalone_<folder_name>. Native ownership/key/sign/placement/redeed integration requires recipient testing; this package does not claim those live behaviours verified.

Binary round trips passed for all20 houses in both record formats. Foundation cells remain within the building footprint, no terrace/plot floor was generated, and stair openings were checked. An offline cardinal walking model using current native tiledata verified reaching each occupied room level from outside on flat ground, assuming doors open. This is not a connected-player or mounted movement test. No existing world houses, scripts, accounts, saves or client data were modified.

Remaining checks: all movement routes in both directions, roof hiding, mounted headroom, collision at joins, ordinary-player placement/ownership, doors/keys, redeeding and terrain fit. Region rectangles still enclose each house; visual L-shaped footprints do not automatically create L-shaped no-build regions. No basement allocation or gameplay additions.


Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
