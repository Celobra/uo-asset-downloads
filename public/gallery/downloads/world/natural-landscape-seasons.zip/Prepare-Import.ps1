param([Parameter(Mandatory=$true)][ValidateRange(0,65484)][int]$BaseId)
$ErrorActionPreference='Stop';$root=$PSScriptRoot
$rows=Get-Content -LiteralPath (Join-Path $root 'items.json') -Raw | ConvertFrom-Json
if($rows.Count -ne 52){throw 'Expected 52 sprites.'}
foreach($r in $rows){if((Get-FileHash -LiteralPath (Join-Path $root $r.file)).Hash.ToLowerInvariant() -ne $r.sha256){throw 'Sprite checksum mismatch'}}
$output=Join-Path $root 'Import';if(Test-Path -LiteralPath $output){throw 'Rename the existing Import folder before preparing another range.'};New-Item -ItemType Directory -Path $output | Out-Null
$csv=[Collections.Generic.List[string]]::new();$csv.Add('# ID;Name;Weight;Quality;Animation;Height;Hue;Quantity;StackingOffset;MiscData;Unk2;Unk3;64 flags in bit order')
$script=[Collections.Generic.List[string]]::new();$xml=[Xml.XmlDocument]::new();[void]$xml.AppendChild($xml.CreateXmlDeclaration('1.0','utf-8',$null));$mass=$xml.CreateElement('MassImport');[void]$xml.AppendChild($mass);$index=@()
for($i=0;$i -lt $rows.Count;$i++){
 $r=$rows[$i];$id=$BaseId+$i;$file=Join-Path $root $r.file
 $fields=@([string]$id,$r.name,'255','0','0',[string]$r.height_z,'0','0','0','0','0','0');$flags=@('0')*64
 for($b=0;$b -lt 64;$b++){if(([uint64]$r.flags -band ([uint64]1 -shl $b)) -ne 0){$flags[$b]='1'}};$csv.Add((($fields+$flags) -join ';'))
 foreach($kind in 'item','tiledataitem'){$node=$xml.CreateElement($kind);$node.SetAttribute('index',[string]$id);$node.SetAttribute('file',$(if($kind -eq 'item'){$file}else{Join-Path $output 'tiledata.csv'}));$node.SetAttribute('remove','False');[void]$mass.AppendChild($node)}
 $script.Add(('[ITEMDEF 0{0:x4}]' -f $id));$script.Add(('DEFNAME=i_natural_landscape_seasons_'+$r.name.Replace('-','_')));$script.Add(('NAME='+$r.name));$script.Add('TYPE=t_normal');$script.Add('');$script.Add('ON=@Create');$script.Add('ATTR=attr_static');$script.Add('')
 $index += [pscustomobject]@{id=$id;hex=('0x{0:X4}' -f $id);base=$r.base;season=$r.season;name=$r.name;file=$r.file}
};$script.Add('[EOF]');$utf8=[Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllLines((Join-Path $output 'tiledata.csv'),$csv,$utf8);[IO.File]::WriteAllLines((Join-Path $output 'natural_landscape_seasons.scp'),$script,$utf8);$xml.Save((Join-Path $output 'massimport.xml'))
$index|Export-Csv -LiteralPath (Join-Path $output 'asset-index.csv') -NoTypeInformation
Write-Output ('Prepared 52 seasonal sprites at 0x{0:X4}-0x{1:X4}. Check that these slots are unused before importing.' -f $BaseId,($BaseId+51))
