# Workshop & Laboratory

Eight designs, two facings each,16 static native UO item sprites: tool bench, alchemy table, reagent cabinet, copper still, drafting desk, specimen cabinet, grinding station and screw press. Materials coordinate across the set. Reagent cabinet uses closed drawers and plain jars; no custom reagent icons.

Choose16 verified unused item-art IDs in your current client, back up current data and import with your preferred art editor. No IDs reserved. Configure matching server item definitions and tiledata height/blocking after in-game testing. A single item does not automatically block its whole visual footprint; benches and still may need multiple-cell collision. These are decorative assets only: no usable containers, crafting, moving grindstone, press operation or still animation. Static furnace glow is painted into the still sprite.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
