# Frost Stone Architecture

This is one selected family from the collection. The included manifest lists its files. No destination IDs are assigned.

## Import

PNG files preserve transparency. BMP files use black outside the silhouette. BIN files contain individual static-art records, not complete art.mul files. The manifest lists each piece and its intended role, suggested physical height and matching door state. No art IDs are assigned. Inspect the actual target installation for unused slots and merge into current art/tiledata files with a compatible asset editor. Back up the current target before an import. Do not replace the whole client with this package.

All pieces deliberately retain a 44×128 canvas. Do not trim, recenter or rescale them. Standard placement is screen_x=22*(x-y)-width/2; screen_y=22*(x+y)-4*z+44-height. This registers floor surfaces, door hinges and wall corners consistently. Walls are 20z high (80 vertical pixels). Half walls are 10z, low walls 5z. Side x runs along x at the front y edge of a cell; side y runs along y at its front x edge. The combined corner joins these two front edges. Wall material repeats across neighboring cells, with corners/end posts used to finish exposed junctions.

## Doors and windows

A door frame and its leaf share the same tile coordinate and base z. Each leaf has a reciprocal pair name in the manifest. Use that explicit pair to configure the target server's door behavior after assigning art IDs; do not infer native door arithmetic from the filenames. Opening pivots the art within the same registered canvas, so no display position correction is required. Locking, ownership, sounds and collision need server configuration. This pack contains artwork, not an installed door system.

Door frames and arches have visible openings; setting the entire cell as a solid wall would block entry. The importer/server must select appropriate collision flags. Window walls are solid; inset windows are decorative components and must be combined with a suitable wall/opening. Window glass is painted, not transparent to the world. The narrow arch's curve is deliberately pixel-stepped at native scale.

## Stairs

Each stair tile shows two treads rising 5z across one cell. Four stair cells placed at base z=0,5,10,15 lead from a lower floor at z=0 to an upper floor at z=20. The layouts folder includes all four directions for every style, with a floor at each end. Keep a full tile of approach/exit clearance and leave the upper floor opening clear over the entire stair run. The landing block has a 5z height: place its base 5z below the desired top, or use the zero-height floor for an already supported landing.

Geometry and adjacency checks do not prove player access. Target tiledata surface/bridge/height flags and server movement rules must be configured and tested both up and down with a normal player. A visible hole in a frame is not a per-pixel collision hole, and artwork alone cannot make a stair walkable. Foundations occupy the complete cell; do not put one in a passage or stair opening.

