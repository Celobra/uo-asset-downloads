# Sand Water

This download includes all sixteen transition masks in 44x44 and 352x352 sizes, in PNG, BMP and native BIN formats. See manifest.json for the included paths. IDs are unassigned.

## Matching pieces

Mask numbers are decimal in filenames (`00` through `15`). Add these corner values for corners occupied by the foreground material:

| Screen corner | Value |
| --- | --- |
| Top | 1 |
| Right | 2 |
| Bottom | 4 |
| Left | 8 |

`00` is all background; `15` is all foreground. `03` has foreground at the top and right; `07` has foreground everywhere except the left corner. `05` and `10` are the two diagonal connections. Adjacent tiles must agree at both endpoints of their shared edge. Use the same set and size for adjoining transition tiles.

Place small tiles one world tile apart along either map axis. Place macro tiles eight world tiles apart along either map axis, at the same height. For a 2D preview these steps are (22,22)/(−22,22) pixels for small art and (176,176)/(−176,176) for macro art. Keep a consistent item anchor when placing macro pieces.

## Import and gameplay

These are **static item-art assets**, not map-land records. Import the PNG or BMP into verified free item-art slots using your asset editor, then configure matching tiledata and server definitions. The `.bin` files contain individual native static-art records, not complete `art.mul` or `artidx.mul` files; do not rename them over client archives. Back up current data before importing. No client files, live art IDs or server scripts are included or overwritten by this pack.

Bitmap size does not define a walkable platform. A 352×352 piece is decorative art and does **not** supply collision across its visible 8×8 footprint. Place proper map terrain or individual floor surfaces beneath any area players should walk on. A small tile intended as a walkable floor can be configured as a height-zero Surface (0x200) with an appropriate floor definition; sky and water used as scenery should not automatically receive that behavior. Test flags against the target server/client before distribution.

The pack supplies flat surfaces. Floating cliff faces, waterfalls, rocks, shipwrecks and cave walls are separate vertical scenery. Water and clouds in this version are static, not animated.

