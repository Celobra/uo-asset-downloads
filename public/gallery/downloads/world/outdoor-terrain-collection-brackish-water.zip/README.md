# Brackish Water

This is one selected family from the collection. The included manifest lists its files. No destination IDs are assigned.

These are custom **static item-art** assets, not map-land records. The water is static surface artwork in this release; no water animation, swimming, boating or other gameplay behavior is installed.

## Using the tiles

Use the 44×44 files for normal one-cell placement on the UO grid. The four base variants (`v0`–`v3`) can be mixed within their own surface to soften repetition. Keep all tiles in a level patch at the same Z. At the same Z, one world tile along X appears as (22,22) screen pixels, and along Y as (−22,22).

Transition filenames identify the foreground, background and decimal mask. The foreground corner values are top=1, right=2, bottom=4, left=8. Sum the desired corners to choose a mask. Mask 03 fills top/right; mask 07 fills every corner except left. Adjacent pieces must agree at both corners of their shared edge. Mask 00 uses background `v0`; mask 15 uses foreground `v0`; these solid fills are referenced in `transition-families.json` rather than duplicated in each folder. All shared materials use the same underlying texture, so a solid material can connect compatible families.

All 276 possible pairs among these twenty-four materials have complete transitions. Reverse foreground/background by complementing the mask (15 minus the original mask). There is no need to pass through a third material. These transitions match this collection; they do not automatically match arbitrary stock UO or third-party textures.

## Import and collision

Allocate verified free item-art slots in the intended client, import the PNG/BMP files, and create matching tiledata/server definitions. Keep a backup and preserve unrelated client data. The `.bin` files are single static-art records, not complete `art.mul` or `artidx.mul` archives; do not rename them over those archives.

Walkable land cells need appropriate floor Surface/height settings and server definitions. Water and mixed shore tiles need deliberate collision decisions: one item cell cannot express a partially walkable boundary based on its painted pixels. Test shores against the target server before use. A 352×352 decorative bitmap does not provide collision for its visual 8×8 footprint; use individual floors or map terrain underneath walkable areas.

No IDs are allocated or reserved by this package. Nothing is installed, and there are no accounts, saves or live client files. Existing floor and mountain-edge packs are separate. This pack supplies flat surfaces; cliffs, banks, trees and other upright scenery remain separate assets.

