# Travelling Caravan — Sphere test build

Two movable caravans: one with a harness horse and one without. Both share a weathered timber cabin, canvas roof, turning wheels, smoking chimney, cargo chest and bedroll. The cabin stays registered while separate wheel frames animate. Four facings use UO's 44 × 44 tile projection.

Open **Caravan-Preview.html** for the animation controls, or the two **Caravan-with-*.gif** files for a quick view. These are assembled previews of the native assets, not recordings from the game.

## Install into a test client and Sphere

1. Extract the whole ZIP. Keep its folders together.
2. Close the game client, Sphere and any asset editors using those game files.
3. With Python 3.10 or newer installed, run **Install-Caravan.cmd**. Select the original UO data folder, then the Sphere server folder containing `scripts/items`.
4. The installer checks the current data and shows the destinations before saving. It refuses occupied IDs, an existing caravan script, a mismatched TileData layout or files in use. A verified backup is retained.
5. Restart Sphere and the client. Every player needs the same patched client data. The supplied Sphere script must be loaded through the server's normal `scripts/items` resources.

This package targets the original MUL artwork data and Sphere X. It updates art, TileData, AnimData and eight multis, including MultiCollection.uop if present. It is not an equipment VD package. Art-UOP clients and other server emulators require a separate conversion. Accounts and world saves are not included or replaced.

## Create and drive

A GM can create the two deeds with:

```
.add i_deed_gc_caravan
.add i_deed_gc_horse_caravan
```

Double-click a deed in your backpack and target nearby clear, level ground. Successful placement consumes the deed and gives the owner **caravan reins** in their backpack. Double-click those reins to open the controls.

- **Board:** enter the parked caravan at the rear landing. The rear steps are also walkable.
- **Travel forwards:** the owner must be aboard and dismounted. Travel advances one tile every half-second until stopped or blocked.
- **Park:** stop travel and wheel/horse walking animation. Smoke continues.
- **Turn left / right:** turn the whole caravan and its contents through 90 degrees; a generous clear area is required.
- **Leave at the rear:** leave the parked caravan if the exit is clear.
- **Secure / release an item:** secure loose furniture on the floor while preserving its original movable state for release.

The cargo chest, bedroll, passengers, eligible loose items and secured furniture retain their positions relative to the caravan during travel and turns. Items nested inside containers remain inside those containers. Keep loose contents on the floor, within the cabin; the script refuses movement if it detects static or elevated contents that native transport would leave behind. It also stops before exceeding its conservative 100-object transport budget; nested contents do not each consume a transport slot.

The horse is an attached animated part of the vehicle, not a separate pet or mount. The version without a horse uses the same controls. Logging out stops further automatic travel.

## Test-build limits

Movement supports clear land on facets 0 and 1, within the original 6144 × 4096 bounds. The full footprint must remain at the same **Sphere walkable terrain height**; slopes, water, foreign structures and obstructions are checked before movement. This is a flat-land caravan, not an all-terrain vehicle. Sphere averages terrain vertices, so a tiny isolated vertex spike may be treated as level by the engine.

The rear door is currently painted into the cabin and has no opening animation. The entrance remains passable. There is no player redeeding command in this build; do not delete a placed caravan containing valuables as a substitute for packing it up.

Native roof cutaway, circle transparency, light/hue behavior and visual overlap with players still need an in-game visual check in the recipient client. The browser's interior inspection hides the exterior for clarity; it is not a simulation of the client's cutaway behavior. Browser visual verification was unavailable during this build.

## Verification and rollback

The isolated Sphere tests cover movement and turning in all four directions for both versions; cargo offsets and nested contents; obstacle, terrain and capacity refusal; save/reload; and 20 connected non-GM stair, aisle and wall checks. Both deeds were placed and consumed through real client packets, with backpack reins used to board, drive and park. Installer checks verify native records, preservation of unrelated data, refusal when files are busy, repeat-install refusal and exact rollback. No live server installation was performed during these tests.

The installer displays its backup folder after installation. To undo an installation, close the client, server and editors, then run:

```
py -3 Import-Caravan.py --restore "FULL PATH TO THE DISPLAYED BACKUP FOLDER"
```

Rollback refuses files that have changed since installation; do not force an older backup over later content. Remove test caravans safely before removing their definitions from a saved world.

## Native allocation

This build requests item art **0x6800–0x68C7** and multis **0x48–0x4F**. These are package allocations, not permission to replace existing assets. The installer verifies availability again at installation. Two versions each have four facings; wheel loops have 12 phases and smoke loops have 13. The original horse animation is registered to the hitch.

The generated cabin is paired with adapted original UO horse, floor, smoke and furniture assets. This is a custom fan-made test asset, not an original shipped UO asset.
