"""Preserve Windows DACLs when installing staged edits.

Never ignore ACL merge failures or silently fall back to a plain rename.
Recovery records store only the DACL, not account credentials.
"""
import base64
import ctypes
import os
from pathlib import Path

if os.name == 'nt':
    from ctypes import wintypes as w
    _security = ctypes.WinDLL('advapi32', use_last_error=True)
    _kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    _security.GetFileSecurityW.argtypes = [w.LPCWSTR, w.DWORD, w.LPVOID, w.DWORD, ctypes.POINTER(w.DWORD)]
    _security.GetFileSecurityW.restype = w.BOOL
    _security.SetFileSecurityW.argtypes=[w.LPCWSTR,w.DWORD,w.LPVOID]
    _security.SetFileSecurityW.restype=w.BOOL
    _security.GetSecurityDescriptorDacl.argtypes = [w.LPVOID, ctypes.POINTER(w.BOOL), ctypes.POINTER(w.LPVOID), ctypes.POINTER(w.BOOL)]
    _security.GetSecurityDescriptorDacl.restype = w.BOOL
    _security.SetNamedSecurityInfoW.argtypes = [w.LPWSTR, w.DWORD, w.DWORD, w.LPVOID, w.LPVOID, w.LPVOID, w.LPVOID]
    _security.SetNamedSecurityInfoW.restype = w.DWORD
    _security.GetSecurityDescriptorControl.argtypes = [w.LPVOID, ctypes.POINTER(w.WORD), ctypes.POINTER(w.DWORD)]
    _security.GetSecurityDescriptorControl.restype = w.BOOL
    _kernel.ReplaceFileW.argtypes = [w.LPCWSTR, w.LPCWSTR, w.LPCWSTR, w.DWORD, w.LPVOID, w.LPVOID]
    _kernel.ReplaceFileW.restype = w.BOOL


def capture_dacl(path):
    if os.name != 'nt':
        return None
    size = w.DWORD()
    _security.GetFileSecurityW(str(Path(path).resolve()), 4, None, 0, ctypes.byref(size))
    if not size.value:
        raise ctypes.WinError(ctypes.get_last_error())
    buffer = ctypes.create_string_buffer(size.value)
    if not _security.GetFileSecurityW(str(Path(path).resolve()), 4, buffer, size, ctypes.byref(size)):
        raise ctypes.WinError(ctypes.get_last_error())
    return base64.b64encode(buffer.raw).decode('ascii')


def restore_dacl(path, descriptor):
    if os.name != 'nt' or descriptor is None:
        return
    buffer = ctypes.create_string_buffer(base64.b64decode(descriptor, validate=True))
    control, revision = w.WORD(), w.DWORD()
    if not _security.GetSecurityDescriptorControl(buffer, ctypes.byref(control), ctypes.byref(revision)):
        raise ctypes.WinError(ctypes.get_last_error())
    flags = 4 | (0x80000000 if control.value & 0x1000 else 0x20000000)
    if not control.value & 0x400:
        # Legacy descriptors without AUTO_INHERITED must remain exact; the
        # modern setter would merge the parent's ACEs and change their policy.
        if not _security.SetFileSecurityW(str(Path(path).resolve()),flags,buffer):
            raise ctypes.WinError(ctypes.get_last_error())
        return
    present, defaulted, dacl = w.BOOL(), w.BOOL(), w.LPVOID()
    if not _security.GetSecurityDescriptorDacl(buffer, ctypes.byref(present), ctypes.byref(dacl), ctypes.byref(defaulted)):
        raise ctypes.WinError(ctypes.get_last_error())
    if not present.value:
        raise ValueError('Recovery descriptor has no DACL')
    error = _security.SetNamedSecurityInfoW(str(Path(path).resolve()), 1, flags, None, None, dacl, None)
    if error:
        raise ctypes.WinError(error)


def replace_preserving_permissions(source, destination):
    """Replace an existing file, preserving its DACL and inheritance setting."""
    if os.name != 'nt':
        os.replace(source, destination)
    else:
        original=capture_dacl(destination)
        if not _kernel.ReplaceFileW(str(Path(destination).resolve()), str(Path(source).resolve()), None, 0, None, None):
            raise ctypes.WinError(ctypes.get_last_error())
        # Windows can retain the replacement file's protection flags even after
        # merging ACEs. Verify the complete DACL, not just API success.
        if capture_dacl(destination)!=original:
            restore_dacl(destination,original)
            if capture_dacl(destination)!=original:
                raise OSError('The original file permissions could not be restored; recover this save before continuing.')
