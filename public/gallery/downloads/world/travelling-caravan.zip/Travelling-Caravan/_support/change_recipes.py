import base64
def b64(raw):
    return base64.b64encode(raw).decode("ascii")
