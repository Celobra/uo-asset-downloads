"""Check every destination before creating save journals, backups or staged files.

Windows OPEN_EXISTING handles never truncate files. Zero sharing detects even a
reader that otherwise permits writes. Handles are released after the whole check;
the transaction rechecks before commit and still retains its rollback protection.
"""
import ctypes
import os
from pathlib import Path

if os.name == 'nt':
    from ctypes import wintypes as w
    _kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    _kernel.CreateFileW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, w.LPVOID, w.DWORD, w.DWORD, w.HANDLE]
    _kernel.CreateFileW.restype = w.HANDLE
    _kernel.CloseHandle.argtypes = [w.HANDLE]
    _kernel.CloseHandle.restype = w.BOOL
    INVALID_HANDLE = ctypes.c_void_p(-1).value


def _open_existing(path, directory=False, read_only=False):
    # File: read/write/delete are needed by backup and atomic replacement.
    # Folder: test creation rights, without creating a probe file or denying Explorer.
    access = (0x2 | 0x4) if directory else 0x80000000 if read_only else (0x80000000 | 0x40000000 | 0x10000)
    handle = _kernel.CreateFileW(str(path), access, 7 if directory else 0,
                                 None, 3, 0x02000000 if directory else 0, None)
    if handle == INVALID_HANDLE:
        raise ctypes.WinError(ctypes.get_last_error())
    return handle


def client_dependencies(root):
    """Also detect a client using another archive in the same selected data folder."""
    return [p for p in Path(root).iterdir() if p.is_file() and
            (p.suffix.lower() in {'.mul', '.idx', '.uop', '.def'} or p.name.lower() == 'mobtypes.txt')]


def preflight_save(paths, *, directories=(), allow_missing=(), read_dependencies=()):
    """Raise before any writes if any required file is in use or not replaceable."""
    paths = list(dict.fromkeys(Path(p).resolve() for p in paths))
    dependencies = {Path(p).resolve() for p in read_dependencies} - set(paths)
    missing = {Path(p).resolve() for p in allow_missing}
    folders = {Path(p).resolve() for p in directories}
    folders.update(p.parent for p in paths)
    handles = []; failures = []
    try:
        for path in paths + sorted(dependencies, key=str):
            try:
                if not path.exists():
                    if path not in missing: raise FileNotFoundError('Required file is missing')
                    continue
                if not path.is_file(): raise OSError('Destination is not a regular file')
                if os.name == 'nt': handles.append(_open_existing(path, read_only=path in dependencies))
                else:
                    if not os.access(path, os.R_OK | os.W_OK): raise PermissionError('File is not readable and writable')
                    # POSIX cannot reliably enumerate non-cooperating file users.
                    import fcntl
                    stream = path.open('r+b')
                    try: fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except Exception: stream.close(); raise
                    handles.append(stream)
            except OSError as exc:
                reason = ('File is in use. Close the UO client, Sphere or other editor using it.'
                          if getattr(exc, 'winerror', None) in (32, 33) else
                          'Access denied or file is read-only. Check permissions and close programs using it.'
                          if isinstance(exc, PermissionError) else str(exc))
                failures.append(f'{path}\n  {reason}')
        checked = set()
        for directory in sorted(folders, key=str):
            # A reviewed new scripts subfolder may not exist yet. Test its nearest
            # existing ancestor now; actual creation remains inside the transaction.
            while not directory.exists() and directory != directory.parent:
                directory = directory.parent
            if directory in checked: continue
            checked.add(directory)
            try:
                if not directory.is_dir(): raise OSError('Destination parent is not a folder')
                if os.name == 'nt': handles.append(_open_existing(directory, True))
                elif not os.access(directory, os.W_OK | os.X_OK): raise PermissionError('Folder is not writable')
            except OSError as exc:
                failures.append(f'{directory}\n  Cannot create save files here: {exc}')
    finally:
        for handle in reversed(handles):
            if os.name == 'nt': _kernel.CloseHandle(handle)
            else: handle.close()
    if failures:
        raise ValueError('Save safety check stopped this operation before file replacement.\n'
                         'Close the programs using these files or fix the reported access issue, then retry.\n\n'
                         + '\n\n'.join(failures))
