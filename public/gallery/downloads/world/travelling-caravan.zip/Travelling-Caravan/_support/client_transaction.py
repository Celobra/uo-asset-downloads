"""Reviewed client changes: staged files, conflict checks and recoverable saves.

A set of file replacements cannot be OS-atomic. A durable journal and original
copies allow rollback after an error or an interrupted process. Close the game,
server and other editors before saving; no live-file locking claim is made.
"""
import json
import hashlib
import os
from pathlib import Path
import shutil
import tempfile
from file_permissions import capture_dacl, restore_dacl, replace_preserving_permissions
from save_preflight import preflight_save, client_dependencies


def revision(path):
    stat = Path(path).stat()
    return (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)


def file_state(path):
    return revision(path) if path.exists() else None


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def copy_verified(source, destination):
    """Buffered copy with byte-count and stored-digest checks, before installation."""
    value = hashlib.sha256(); copied = 0
    with Path(source).open("rb") as incoming, Path(destination).open("wb") as outgoing:
        expected_size = os.fstat(incoming.fileno()).st_size
        for chunk in iter(lambda: incoming.read(1024 * 1024), b""):
            outgoing.write(chunk); value.update(chunk); copied += len(chunk)
        outgoing.flush(); os.fsync(outgoing.fileno())
    if copied != expected_size or Path(destination).stat().st_size != expected_size:
        raise OSError(f"Incomplete copy of {Path(source).name}; no replacement will be installed.")
    if file_digest(destination) != value.hexdigest():
        raise OSError(f"Copy verification failed for {Path(source).name}; no replacement will be installed.")
    return value.hexdigest()


def verify_record_patches(folder, patches):
    """Prove that fixed-record edits preserve file size and every unedited byte."""
    groups = {}
    for name, offset, raw in patches:
        groups.setdefault(name, []).append((offset, raw))
    for name, records in groups.items():
        original = (folder / "original" / name).read_bytes()
        expected = bytearray(original)
        for offset, raw in records:
            if offset < 0 or offset + len(raw) > len(original):
                raise ValueError(f"{name}: record patch lies outside the original file")
            expected[offset:offset + len(raw)] = raw
        actual = (folder / "edited" / name).read_bytes()
        if len(actual) != len(original) or actual != expected:
            raise ValueError(f"{name}: staged save changed the file length or bytes outside the reviewed records. No files installed.")


def linked_path(record):
    """Constrain journaled script/mapping destinations, including parent symlinks."""
    root = Path(record["root"])
    relative = Path(record["relative"])
    if not root.is_absolute() or relative.is_absolute() or ".." in relative.parts:
        raise ValueError("Invalid linked save path")
    if record["scope"] == "script":
        if len(relative.parts) < 2 or relative.parts[0] != "scripts" or relative.suffix.lower() != ".scp":
            raise ValueError("Linked scripts must be inside the server scripts folder")
    elif record["scope"] == "mapping":
        if relative.as_posix().lower() not in {"bodyconv.def", "mobtypes.txt"}:
            raise ValueError("Unsupported linked client mapping")
    else:
        raise ValueError("Invalid linked save scope")
    path = root / relative
    allow_missing=record.get('create_parents',False) and record['scope']=='script'
    if any(p.is_symlink() or (p.exists() and not p.is_dir()) for p in path.parents) or path.is_symlink() or (not path.parent.is_dir() and not allow_missing):
        raise ValueError("Linked saves require ordinary existing folders")
    path.resolve().relative_to(root.resolve())
    return path


def install_linked(path, data, create=False, recovery_dacl=None):
    """Stage beside the destination for cross-volume saves; creation never overwrites."""
    fd, name = tempfile.mkstemp(prefix=".uopve-link-", suffix=".tmp", dir=path.parent)
    temp = Path(name)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data); stream.flush(); os.fsync(stream.fileno())
        if create:
            restore_dacl(temp, recovery_dacl)
            os.link(temp, path)  # Atomic no-clobber install, also supported on Windows NTFS.
        else:
            replace_preserving_permissions(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def safe_file(root, name):
    if not name or Path(name).name != name or "/" in name or "\\" in name or name in {".", ".."}:
        raise ValueError("Client transaction contains an invalid filename")
    path = root / name
    if path.is_symlink() or path.resolve().parent != root.resolve():
        raise ValueError("Client editing requires ordinary files directly in the client folder")
    return path


def write_json(path, value):
    temporary = path.with_suffix(".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def pending_transactions(root):
    root = Path(root).resolve()
    result = []
    for folder in root.glob(".uopve-save-*"):
        if folder.is_symlink() or not folder.is_dir():
            continue
        journal = folder / "journal.json"
        if journal.is_file():
            data = json.loads(journal.read_text(encoding="utf-8"))
            if data.get("state") in {"committing", "recovery_required"}:
                result.append(folder)
    return result


def recover_transaction(folder):
    folder = Path(folder).resolve()
    root = folder.parent
    if not folder.name.startswith(".uopve-save-"):
        raise ValueError("Choose a UO Asset Studio save recovery folder")
    journal = folder / "journal.json"
    data = json.loads(journal.read_text(encoding="utf-8"))
    if data.get("state") not in {"committing", "recovery_required", "complete"}:
        raise ValueError("This transaction has no installed files to restore")
    names = data.get("files", [])
    if (not names and not data.get("linked")) or len(names) != len(set(names)):
        raise ValueError("Invalid recovery file list")
    for name in names:
        safe_file(root, name)
        original = safe_file(folder / "original", name)
        if not original.is_file():
            raise ValueError(f"Recovery copy is missing: {name}")
        hashes = data.get("binary_hashes", {}).get(name)
        if hashes:
            if file_digest(original) != hashes["before"]:
                raise ValueError(f"Recovery copy is damaged: {name}. Nothing restored.")
            current = root / name
            if current.exists() and file_digest(current) not in {hashes["before"], hashes["after"]}:
                raise ValueError(f"{name} changed after this save. Nothing restored. Keep this backup and the current files; resolve the later changes before restoring.")
    linked = data.get("linked", [])
    destinations = [safe_file(root, name) for name in names] + [linked_path(r) for r in linked]
    preflight_save(destinations, directories=[root, folder], allow_missing=destinations,
                   read_dependencies=client_dependencies(root))
    # Preflight every linked file before restoring anything. Do not remove a script
    # changed by another editor after the interrupted save (or retained backup).
    for i, record in enumerate(linked):
        path = linked_path(record)
        current = digest(path.read_bytes()) if path.exists() else None
        if current not in {record["before_hash"], record["after_hash"]}:
            raise ValueError(f"{path} changed after this save. Keep the recovery folder and resolve that edit first.")
        if record["before_hash"] is not None:
            original = folder / "linked-original" / str(i)
            if not original.is_file() or digest(original.read_bytes()) != record["before_hash"]:
                raise ValueError(f"Linked recovery copy is missing or damaged: {path}")
    # Copy, then replace: retain the originals if restoring is interrupted.
    for name in names:
        restore = folder / (name + ".restore")
        copy_verified(folder / "original" / name, restore)
        target = root / name
        if target.exists():
            replace_preserving_permissions(restore, target)
        else:
            # A sibling temporary inherits the real parent, never the private
            # transaction folder. Old journals without DACLs use that default.
            fd, sibling = tempfile.mkstemp(prefix='.uopve-restore-', dir=root)
            os.close(fd)
            try:
                copy_verified(restore, sibling)
                restore_dacl(sibling, data.get('binary_dacls', {}).get(name))
                os.link(sibling, target)
            finally:
                Path(sibling).unlink(missing_ok=True)
    for i, record in reversed(list(enumerate(linked))):
        path = linked_path(record)
        if record["before_hash"] is None:
            path.unlink(missing_ok=True)
        else:
            install_linked(path, (folder / "linked-original" / str(i)).read_bytes(),
                           create=not path.exists(), recovery_dacl=record.get('dacl'))
    data["state"] = "restored"
    write_json(journal, data)
    return names


class ClientChange:
    def __init__(self, root, names, summary):
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise ValueError("Select an extracted UO client folder first")
        if pending_transactions(self.root):
            raise ValueError("An interrupted client save needs recovery. Use Recover client save before editing.")
        self.names = list(dict.fromkeys(names))
        self.before = {name: revision(safe_file(self.root, name)) for name in self.names}
        self.summary = summary
        self.transforms = {}
        self.validators = []
        self.linked = []
        self.guards = []
        self.record_patches = []
        self.operations = []

    def add_write(self, root, relative, data, scope="script", create_parents=False):
        record = {"root": str(Path(root).resolve()), "relative": relative, "scope": scope}
        if create_parents: record['create_parents']=True
        path = linked_path(record)
        if any(linked_path(r) == path for r, _ in self.linked):
            raise ValueError("A linked save targets the same file twice")
        record["revision"] = file_state(path)
        record["before_hash"] = digest(path.read_bytes()) if path.exists() else None
        record["after_hash"] = digest(data)
        self.linked.append((record, data))

    def changed_paths(self):
        return [self.root / name for name in self.names] + [linked_path(r) for r, _ in self.linked]

    def add_delete(self, root, relative):
        """Journal one exact script-file deletion with a restorable original."""
        self.add_write(root, relative, b'', 'script')
        record, _ = self.linked[-1]
        if record['before_hash'] is None:
            self.linked.pop()
            raise ValueError('The script to remove no longer exists')
        record['delete'] = True
        record['after_hash'] = None

    def check(self):
        for name, expected in self.before.items():
            if revision(safe_file(self.root, name)) != expected:
                raise ValueError(f"{name} changed on disk. Close other editors and review the changes again.")
        for record, _ in self.linked:
            path = linked_path(record)
            if file_state(path) != record["revision"]:
                raise ValueError(f"{path} changed on disk. Review the import again.")
            if record["revision"] is None and path.parent.is_dir() and any(p.name.casefold() == path.name.casefold() for p in path.parent.iterdir()):
                raise ValueError(f"A file now uses the name {path.name}. Review the import again.")
        for guard in self.guards:
            guard()

    def save(self, backup=False, progress=lambda _: None):
        progress('Checking that all save files are available and writable...')
        destinations = self.changed_paths()
        new_files = [linked_path(r) for r, _ in self.linked if r['before_hash'] is None]
        preflight_save(destinations, directories=[self.root], allow_missing=new_files,
                       read_dependencies=client_dependencies(self.root))
        self.check()
        if pending_transactions(self.root):
            raise ValueError("Recover the earlier interrupted save first")
        lock = self.root / ".uopve-write.lock"
        try:
            lock_stream = lock.open("x")
        except FileExistsError as exc:
            raise ValueError("A save is already running, or was interrupted. Use Recover client save if no other UO Asset Studio is running.") from exc
        folder = None
        committing = False
        retain = False
        try:
            folder = Path(tempfile.mkdtemp(prefix=".uopve-save-", dir=self.root))
            lock_stream.write(str(folder)); lock_stream.flush()
            (folder / "original").mkdir()
            (folder / "edited").mkdir()
            journal = {"version": 4, "state": "preparing", "files": self.names, "summary": self.summary,
                       "binary_dacls": {name: capture_dacl(self.root / name) for name in self.names},
                       "linked": [record for record, _ in self.linked]}
            write_json(folder / "journal.json", journal)
            for name in self.names:
                progress(f"Preparing {name}…")
                source = safe_file(self.root, name)
                copy_verified(source, folder / "original" / name)
                copy_verified(folder / "original" / name, folder / "edited" / name)
                self.check()
            (folder / "linked-original").mkdir()
            (folder / "linked-edited").mkdir()
            for i, (record, data) in enumerate(self.linked):
                path = linked_path(record)
                if record["before_hash"] is not None:
                    record['dacl'] = capture_dacl(path)
                    copy_verified(path, folder / "linked-original" / str(i))
                    if digest((folder / "linked-original" / str(i)).read_bytes()) != record["before_hash"]:
                        raise ValueError(f"{path} changed while preparing the save")
                (folder / "linked-edited" / str(i)).write_bytes(data)
                for area in ("linked-original", "linked-edited"):
                    copy = folder / area / str(i)
                    if copy.exists():
                        with copy.open("r+b") as stream: os.fsync(stream.fileno())
            for name, transform in self.transforms.items():
                progress(f"Writing {name}…")
                transform(folder / "edited" / name)
            for validator in self.validators:
                validator(folder / "edited")
            verify_record_patches(folder, self.record_patches)
            journal["binary_hashes"] = {name: {"before": file_digest(folder / "original" / name),
                                                "after": file_digest(folder / "edited" / name)} for name in self.names}
            for name in self.names:
                for area in ("original", "edited"):
                    with (folder / area / name).open("r+b") as stream:
                        os.fsync(stream.fileno())
            self.check()
            progress('Rechecking file access before applying the reviewed changes...')
            preflight_save(destinations, directories=[self.root], allow_missing=new_files,
                           read_dependencies=client_dependencies(self.root))
            journal["state"] = "committing"
            write_json(folder / "journal.json", journal)
            committing = True
            for name in self.names:
                progress(f"Saving {name}…")
                replace_preserving_permissions(folder / "edited" / name, self.root / name)
            for i, (record, _) in enumerate(self.linked):
                path = linked_path(record)
                progress(f"Saving {path.name}…")
                if record.get('delete'):
                    path.unlink()
                else:
                    if record.get('create_parents'): path.parent.mkdir(parents=True,exist_ok=True)
                    install_linked(path, (folder / "linked-edited" / str(i)).read_bytes(), record["before_hash"] is None)
            journal["state"] = "complete"
            write_json(folder / "journal.json", journal)
            committing = False
            retain = backup
            return {"files": self.names + [r["relative"] for r, _ in self.linked],
                    "backup": str(folder) if backup else None, "script_source": getattr(self, "script_source", None)}
        except Exception:
            if committing:
                try:
                    recover_transaction(folder)
                except Exception as recovery_error:
                    retain = True
                    raise OSError(f"Save interrupted and automatic restore failed. Close programs using the files, then use Recover client save. Original copies: {folder}") from recovery_error
            raise
        finally:
            lock_stream.close()
            lock.unlink(missing_ok=True)
            if folder and not retain:
                shutil.rmtree(folder, ignore_errors=True)
