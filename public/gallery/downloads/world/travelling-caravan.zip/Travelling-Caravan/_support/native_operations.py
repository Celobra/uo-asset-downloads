import struct,time,zlib
def uop_table(path):
    entries={};last=0;seen=set()
    with path.open('rb') as f:
        header=f.read(40)
        if len(header)!=40 or header[:4]!=b'MYP\0':raise ValueError('Invalid UOP header')
        version=struct.unpack_from('<I',header,4)[0]
        block,capacity,count=struct.unpack_from('<QII',header,12)
        if version not in (4,5) or not 1<=capacity<=10000:raise ValueError('Unsupported UOP layout')
        while block:
            if block in seen or block+12>path.stat().st_size:raise ValueError('Invalid UOP block chain')
            seen.add(block);last=block;f.seek(block)
            used,nxt=struct.unpack('<IQ',f.read(12))
            if used>capacity:raise ValueError('Invalid UOP table size')
            for _ in range(used):
                pos=f.tell();row=struct.unpack('<QIIIQIH',f.read(34))
                if row[0]:
                    if row[4] in entries:raise ValueError('Duplicate UOP hash')
                    entries[row[4]]=pos
            block=nxt
    if len(entries)!=count:raise ValueError('UOP entry count mismatch')
    return None,version,capacity,entries,last


def patch_records(plan, name, replacements):
    replacements = list(replacements)
    size = (plan.root / name).stat().st_size
    if any(type(offset) is not int or offset < 0 or offset + len(raw) > size for offset, raw in replacements):
        raise ValueError(f"A {name} record patch would extend or write outside the original file")
    from change_recipes import b64
    plan.operations.append({"kind":"patch", "file":name, "records":[[at,b64(data)] for at,data in replacements]})
    plan.record_patches.extend((name, offset, bytes(raw)) for offset, raw in replacements)
    def patch(path):
        with path.open("r+b") as stream:
            for offset, raw in replacements:
                stream.seek(offset); stream.write(raw)
    plan.transforms[name] = patch
    def verify(folder):
        with (folder / name).open("rb") as stream:
            for offset, raw in replacements:
                stream.seek(offset)
                if stream.read(len(raw)) != raw:
                    raise ValueError(f"Written {name} record failed verification")
    plan.validators.append(verify)

def append_mul(plan, idx_name, mul_name, entries, index_size=0):
    """entries: index-record slot -> (encoded payload, extra)."""
    from change_recipes import b64
    operation={"kind":"mul", "index":idx_name, "file":mul_name,
               "entries":{str(i):[b64(v[0]),v[1]] for i,v in entries.items()}}
    if index_size:
        if idx_name.lower() != 'anim.idx' or mul_name.lower() != 'anim.mul' or type(index_size) is not int or index_size % 12 or not 0 < index_size <= (35000 + 1648 * 175) * 12:
            raise ValueError('Invalid equipment index expansion')
        operation['index_size']=index_size
    plan.operations.append(operation)
    idx_path = plan.root / idx_name
    idx = bytearray(idx_path.read_bytes())
    if len(idx) % 12:
        raise ValueError(f"{idx_name} has an incomplete index record")
    if index_size > len(idx): idx.extend(b'\xff' * (index_size-len(idx)))
    offset = (plan.root / mul_name).stat().st_size
    chunks = []
    for slot, (payload, extra) in sorted(entries.items()):
        if not 0 <= slot < len(idx) // 12:
            raise ValueError(f"Destination is outside {idx_name}; expanding index layouts is not supported")
        if offset + len(payload) >= 0x80000000:
            raise ValueError("The resulting MUL exceeds the supported signed 32-bit offset range")
        struct.pack_into("<III", idx, slot * 12, offset, len(payload), extra)
        chunks.append(payload); offset += len(payload)
    def append(path):
        with path.open("ab") as stream:
            for chunk in chunks:
                stream.write(chunk)
    plan.transforms[mul_name] = append
    plan.transforms[idx_name] = lambda path: path.write_bytes(idx)
    def verify(folder):
        with (folder / idx_name).open("rb") as index, (folder / mul_name).open("rb") as data:
            for slot, (payload, extra) in entries.items():
                index.seek(slot * 12)
                at, length, written_extra = struct.unpack("<III", index.read(12))
                data.seek(at)
                if length != len(payload) or written_extra != extra or data.read(length) != payload:
                    raise ValueError("Written MUL payload failed verification")
    plan.validators.append(verify)

def append_uop(path, replacements):
    _, version, capacity, entries, last = uop_table(path)
    additions = [key for key in replacements if key not in entries]
    with path.open("r+b") as stream:
        # New tables are chained onto the archive. Existing data and tables stay
        # in place except for the reviewed entry records and final next pointer.
        for start in range(0, len(additions), capacity):
            group = additions[start:start + capacity]
            stream.seek(0, 2); block = stream.tell()
            stream.write(struct.pack("<IQ", len(group), 0))
            stream.write(bytes(34 * capacity))
            stream.seek(last + 4 if last else 12)
            stream.write(struct.pack("<Q", block))
            for i, key in enumerate(group):
                entries[key] = block + 12 + i * 34
            last = block
        for key, payload in replacements.items():
            # Shipped art UOP entries are uncompressed. UOFiddler explicitly
            # warns against compressed art even though generic readers support
            # zlib. Preserve other entries; write new static art as stored data.
            packed = payload
            header = struct.pack("<HHQ", 3, 8, int((time.time() + 11644473600) * 10_000_000)) if version == 4 else b""
            stream.seek(0, 2); offset = stream.tell()
            stream.write(header); stream.write(packed)
            stream.seek(entries[key])
            stream.write(struct.pack("<QIIIQIH", offset, len(header), len(packed), len(payload), key,
                                     zlib.adler32(header or packed) & 0xffffffff, 0))
        stream.seek(24); stream.write(struct.pack("<I", len(entries)))
