"""Guarded installer for the Travelling Caravan native item/multi package.

Python 3.10+ standard library only. Running without --install is a dry review.
No accounts, world saves, client mappings or unrelated records are installed.
"""
from pathlib import Path
import sys,json,struct,base64,re,argparse
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'_support'))
from client_transaction import ClientChange,revision,recover_transaction
from native_operations import append_mul,patch_records,append_uop,uop_table

def decode(value):return base64.b64decode(value,validate=True)
def make_plan(client,server):
    client=Path(client).resolve();server=Path(server).resolve()
    payload=json.loads((HERE/'native-payload.json').read_text())
    files={p.name.lower():p for p in client.iterdir() if p.is_file()}
    if 'artlegacymul.uop' in files:raise ValueError('This build requires the original MUL artwork client. Do not import into an art-UOP client.')
    required=['art.mul','artidx.mul','tiledata.mul','animdata.mul','multi.mul','multi.idx']
    if any(n not in files for n in required):raise ValueError('Select the client DATA folder containing art.mul, tiledata.mul and multi.mul.')
    if 'multicollection.uop' in files:required.append('multicollection.uop')
    if files['tiledata.mul'].stat().st_size!=payload['tile_file_length']:raise ValueError('TileData layout differs. Rebuild the caravan package for this client; nothing was changed.')
    if not (server/'scripts/items').is_dir():raise ValueError('Select the Sphere root folder containing scripts/items.')
    destination=server/'scripts/items/travelling_caravan.scp'
    if destination.exists():raise ValueError('A caravan script already exists. This installer never overwrites an existing installation.')
    script=(HERE/'travelling_caravan.scp').read_bytes()
    declared={int(v,16) for v in re.findall(rb'(?mi)^\[ITEMDEF (0[0-9a-f]+)\]',script)}
    multi_ids={int(k) for k in payload['multis']}
    new_names=set(re.findall(rb'(?mi)^DEFNAME=(\w+)',script))
    script_stamps={}
    for p in (server/'scripts').rglob('*.scp'):
        text=p.read_bytes();script_stamps[p]=revision(p)
        if new_names.intersection(re.findall(rb'(?mi)^\s*DEFNAME\s*=\s*(\w+)',text)):
            raise ValueError('An existing script uses a caravan definition name.')
        for kind,n in re.findall(rb'(?mi)^\s*\[(ITEMDEF|MULTIDEF)\s+(0[0-9a-f]+)\]',text):
            if int(n,16) in (declared if kind.upper()==b'ITEMDEF' else multi_ids):
                raise ValueError('An existing Sphere definition occupies a required ID. Rebuild with fresh IDs; nothing was changed.')
    artidx=files['artidx.mul'].read_bytes();midx=files['multi.idx'].read_bytes();td=files['tiledata.mul'].read_bytes();ad=files['animdata.mul'].read_bytes()
    def vacant(index,slot):
        if slot*12+12>len(index):return False
        at,n,_=struct.unpack_from('<III',index,slot*12)
        return at==0xffffffff or n in (0,0xffffffff)
    for key,row in payload['art'].items():
        if not vacant(artidx,int(key)+0x4000) or any(td[row['tile_offset']:row['tile_offset']+len(decode(row['tile']))]):
            raise ValueError(f'Artwork/TileData ID 0x{int(key):04X} is occupied. Nothing was changed.')
    for key in payload['multis']:
        if not vacant(midx,int(key)):raise ValueError(f'Multi ID 0x{int(key):04X} is occupied.')
    for row in payload['animations']:
        at=row['offset']
        if at+68>len(ad) or ad[at+65]:raise ValueError('An animation slot is occupied or outside this client.')
    if 'multicollection.uop' in files:
        _,_,_,entries,_=uop_table(files['multicollection.uop'])
        if any(int(row['hash']) in entries for row in payload['multis'].values()):raise ValueError('A required UOP multi entry is occupied.')
    plan=ClientChange(client,[files[n].name for n in required],'Travelling Caravan: two variants, four facings each and two deeds')
    append_mul(plan,files['artidx.mul'].name,files['art.mul'].name,{int(k)+0x4000:(decode(v['data']),0) for k,v in payload['art'].items()})
    patch_records(plan,files['tiledata.mul'].name,[(v['tile_offset'],decode(v['tile'])) for v in payload['art'].values()])
    patch_records(plan,files['animdata.mul'].name,[(v['offset'],decode(v['data'])) for v in payload['animations']])
    append_mul(plan,files['multi.idx'].name,files['multi.mul'].name,{int(k):(decode(v['mul']),0) for k,v in payload['multis'].items()})
    if 'multicollection.uop' in files:
        name=files['multicollection.uop'].name;updates={int(v['hash']):decode(v['uop']) for v in payload['multis'].values()}
        plan.transforms[name]=lambda p:append_uop(p,updates)
        def validate(folder):
            _,_,_,entries,_=uop_table(folder/name)
            with (folder/name).open('rb') as f:
                for key,data in updates.items():
                    f.seek(entries[key]);at,head,size,unpacked,_,_,compression=struct.unpack('<QIIIQIH',f.read(34));f.seek(at+head)
                    if compression or unpacked!=len(data) or f.read(size)!=data:raise ValueError('UOP verification failed.')
        plan.validators.append(validate)
    plan.add_write(server,'scripts/items/travelling_caravan.scp',script)
    def scripts_unchanged():
        current=set((server/'scripts').rglob('*.scp'))
        if current!=set(script_stamps) or any(revision(p)!=stamp for p,stamp in script_stamps.items()):raise ValueError('Sphere scripts changed during review. Run the review again.')
    plan.guards.append(scripts_unchanged)
    plan.check()
    return plan

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--client');p.add_argument('--server');p.add_argument('--install',action='store_true');p.add_argument('--restore',type=Path);args=p.parse_args()
    if args.restore:
        print(recover_transaction(args.restore));return
    if not args.client and not args.server:
        import tkinter as tk
        from tkinter import filedialog,messagebox
        window=tk.Tk();window.withdraw()
        try:
            client=filedialog.askdirectory(title='Choose the original UO client data folder')
            if not client:return
            server=filedialog.askdirectory(title='Choose the Sphere server root folder')
            if not server:return
            plan=make_plan(client,server)
            if messagebox.askyesno('Install Travelling Caravan',f'Two caravan deeds, both versions and all animation data are ready.\n\nClient: {client}\nServer: {server}\n\nClose the game, Sphere and asset editors first. A verified backup will be kept.\n\nInstall now?'):
                result=plan.save(True);messagebox.showinfo('Caravan installed','Restart the original client and Sphere.\n\nBackup: '+result['backup'])
        except Exception as e:messagebox.showerror('No installation completed',str(e))
        return
    if not args.client or not args.server:p.error('Use both --client and --server.')
    plan=make_plan(args.client,args.server)
    if args.install:print(json.dumps(plan.save(True),indent=2))
    else:print('Review passed. No files changed. Close the game, server and editors, then repeat with --install to install with a backup.')
if __name__=='__main__':main()
