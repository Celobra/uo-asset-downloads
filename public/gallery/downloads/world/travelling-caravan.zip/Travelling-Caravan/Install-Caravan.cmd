@echo off
py -3 "%~dp0Import-Caravan.py" %*
if errorlevel 1 pause
