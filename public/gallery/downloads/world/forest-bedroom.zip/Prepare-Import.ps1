param([Parameter(Mandatory=$true)][ValidateRange(0,65535)][int]$BaseId)
$ErrorActionPreference='Stop';$root=$PSScriptRoot
$rows=Get-Content -LiteralPath (Join-Path $root 'items.json') -Raw | ConvertFrom-Json
if($rows.Count -ne 24 -or $BaseId+$rows.Count -gt 65536){throw 'Choose a valid starting ID for 24 consecutive item-art slots.'}
foreach($r in $rows){if((Get-FileHash -LiteralPath (Join-Path $root $r.file)).Hash.ToLowerInvariant() -ne $r.sha256){throw 'Sprite checksum mismatch'}}
$output=Join-Path $root 'Import';if(Test-Path -LiteralPath $output){throw 'Rename the existing Import folder before preparing another range.'};New-Item -ItemType Directory -Path $output | Out-Null
$csv=[Collections.Generic.List[string]]::new();$csv.Add('# ID;Name;Weight;Quality;Animation;Height;Hue;Quantity;StackingOffset;MiscData;Unk2;Unk3;64 flags in bit order')
$script=[Collections.Generic.List[string]]::new();$xml=[Xml.XmlDocument]::new();[void]$xml.AppendChild($xml.CreateXmlDeclaration('1.0','utf-8',$null));$mass=$xml.CreateElement('MassImport');[void]$xml.AppendChild($mass)
for($i=0;$i -lt $rows.Count;$i++){
 $r=$rows[$i];$id=$BaseId+$i;$file=Join-Path $root $r.file
 $fields=@([string]$id,('forest '+$r.family),'255','0','0',[string]$r.height_z,'0','0','0','0','0','0');$flags=@('0')*64
 for($b=0;$b -lt 64;$b++){if(([uint64]$r.flags -band ([uint64]1 -shl $b)) -ne 0){$flags[$b]='1'}};$csv.Add((($fields+$flags) -join ';'))
 foreach($kind in 'item','tiledataitem'){$node=$xml.CreateElement($kind);$node.SetAttribute('index',[string]$id);$node.SetAttribute('file',$(if($kind -eq 'item'){$file}else{Join-Path $output 'tiledata.csv'}));$node.SetAttribute('remove','False');[void]$mass.AppendChild($node)}
 $script.Add(('[ITEMDEF 0{0:x4}]' -f $id));$script.Add(('DEFNAME=i_forest_bedroom_'+$r.name.Replace('-','_')));$script.Add(('NAME=forest '+$r.family))
 if($r.gump -gt 0){$script.Add('TYPE=t_container');$script.Add(('TDATA2=0{0:x}' -f $r.gump));switch($r.gump){78{$script.Add('TDATA3=0180060');$script.Add('TDATA4=0600098')}72{$script.Add('TDATA3=010000a');$script.Add('TDATA4=09a005e')}73{$script.Add('TDATA3=0a000a');$script.Add('TDATA4=0aa0073')}}}else{$script.Add('TYPE=t_normal')}
 $script.Add('');$script.Add('ON=@Create');$script.Add('ATTR=attr_static');$script.Add('')
};$script.Add('[EOF]');$utf8=[Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllLines((Join-Path $output 'tiledata.csv'),$csv,$utf8);[IO.File]::WriteAllLines((Join-Path $output 'forest_bedroom.scp'),$script,$utf8);$xml.Save((Join-Path $output 'massimport.xml'))
Write-Output ('Prepared 24 furniture sprites and Sphere definitions at 0x{0:X4}-0x{1:X4}. Verify these slots are unused before importing.' -f $BaseId,($BaseId+23))
