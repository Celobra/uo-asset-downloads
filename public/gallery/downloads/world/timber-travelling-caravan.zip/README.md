# Timber Travelling Caravan — separate test variant

A plain timber caravan built around original Ultima Online darkwood walls, wooden floors, doors and chairs. It accompanies the earlier covered caravan; it does not replace it. Includes horse-drawn and horseless deeds, moving wheels, chimney smoke and cargo-preserving travel.

## Install

Close the client, Sphere and asset editors. Run Install-Caravan.cmd with Python 3.10 or later installed. Select the original MUL client data folder and Sphere server root. The importer checks for occupied records and script conflicts, preserves unrelated data and creates a rollback backup. Use an administrator terminal if Windows denies access to the selected installation or its recovery backups. Restart Sphere and the original client afterwards. Every player needs the same client patch.

This separate build uses art 0x68C8–0x6991 and multis 0x54–0x5B. It installs items/timber_travelling_caravan.scp. It leaves the original caravan's script, art 0x6800–0x68C7 and multis 0x48–0x4F intact. Conflicting installations are refused.

Create either deed as a GM:

    .add i_deed_tc_caravan
    .add i_deed_tc_horse_caravan

Place on clear, level ground while dismounted. If you stand inside the chosen footprint, placement moves you outside the rear steps so you can enter normally.

## Enter and drive

Walk up the rear stairs, double-click the native wooden door, then walk through. Walk around the furnishings to the native chair at the front. Standing on its tile invokes the client's normal sitting pose. Use the timber caravan reins in your backpack to travel, turn or park. The owner must occupy the driver chair to drive. Leaving the seat or disconnecting stops travel on the next control tick.

The real door opens, closes and blocks passage while closed. Movement latches it shut; someone standing in the doorway prevents movement. There are no boarding or exit teleport buttons. Park and walk out through the rear door and stairs.

The vehicle carries eligible passengers, loose cargo, secured items and nested container contents at their relative positions. Use Secure / release from the reins to fix a movable item aboard. Parked wheels and the attached horse stop animating; smoke continues. The horse is a vehicle component, not a pet.

## Testing and limits

272 isolated Sphere assertions pass, including native chair identity and driver/seat position through all four facings, movement, turning, cargo and obstacles. A connected non-GM client passes 36 doorway, stairs, chair-access and wall checks across both versions, plus two save/reload checks. Actual Green Acres map testing passes both deeds, placement, owner-only seated driving and parking. Installer tests verify 424 records, occupied-ID refusal, busy-file protection, unchanged unrelated records and exact rollback.

These are server and protocol tests. The exact on-screen seated pose during travel, roof cutaway, clothing overlap and final client layering still require a visual check in the original client. Previews are native-asset assembly renders, not in-game recordings; interior inspection explicitly hides the exterior. Generated studies are not included as finished game previews.

Flat, clear land only, original Felucca/Trammel bounds. Conservative swept-turn and 100-object limits apply. Static or elevated cargo is refused. No redeeding feature. Keep backups and use a test shard first.

## Artwork

The cabin uses existing UO material tiles and real native door/chair art. Registered wheel frames and a small chimney derive from a built-in-generated timber wagon study; original UO horse and smoke provide the other animations. This is custom fan content, not an official shipped asset.
