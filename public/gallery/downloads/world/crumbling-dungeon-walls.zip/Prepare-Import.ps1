param([Parameter(Mandatory=$true)][ValidateRange(0,65535)][int]$BaseId)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$rows=Get-Content -LiteralPath (Join-Path $root 'walls.json') -Raw | ConvertFrom-Json
if($rows.Count -ne 24 -or $BaseId+$rows.Count -gt 65536){throw 'Choose a valid range for all 24 item-art records.'}
$output=Join-Path $root 'Import'
if(Test-Path -LiteralPath $output){throw 'Import already exists. Rename it before selecting another range.'}
New-Item -ItemType Directory -Path $output | Out-Null
$csv=[Collections.Generic.List[string]]::new()
$csv.Add('# ID;Name;Weight;Quality;Animation;Height;Hue;Quantity;StackingOffset;MiscData;Unk2;Unk3;64 flags in bit order')
$script=[Collections.Generic.List[string]]::new()
$xml=[Xml.XmlDocument]::new();[void]$xml.AppendChild($xml.CreateXmlDeclaration('1.0','utf-8',$null));$mass=$xml.CreateElement('MassImport');[void]$xml.AppendChild($mass)
for($i=0;$i -lt $rows.Count;$i++){
 $row=$rows[$i];$id=$BaseId+$i
 $file=Join-Path $root $row.file
 if((Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Sprite integrity check failed'}
 $label=if($row.name -like '*arch-*'){'crumbling arch'}else{'crumbling wall'}
 $fields=@([string]$id,$label,'255','0','0',[string]$row.height_z,'0','0','0','0','0','0')
 $flags=@('0')*64;for($bit=0;$bit -lt 64;$bit++){if(([uint64]$row.flags -band ([uint64]1 -shl $bit)) -ne 0){$flags[$bit]='1'}}
 $csv.Add((($fields+$flags) -join ';'))
 foreach($kind in 'item','tiledataitem'){$node=$xml.CreateElement($kind);$node.SetAttribute('index',[string]$id);$node.SetAttribute('file',$(if($kind -eq 'item'){$file}else{Join-Path $output 'tiledata.csv'}));$node.SetAttribute('remove','False');[void]$mass.AppendChild($node)}
 $script.Add(('[ITEMDEF 0{0:x4}]' -f $id));$script.Add(('DEFNAME=i_crumbling_'+$row.name.Replace('-','_')));$script.Add(('NAME='+$label));$script.Add('TYPE=t_normal');$script.Add('');$script.Add('ON=@Create');$script.Add('ATTR=attr_static');$script.Add('')
}
$script.Add('[EOF]')
$utf8=[Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllLines((Join-Path $output 'tiledata.csv'),$csv,$utf8)
[IO.File]::WriteAllLines((Join-Path $output 'crumbling_walls.scp'),$script,$utf8)
$xml.Save((Join-Path $output 'massimport.xml'))
Write-Output ('Prepared 24 pieces at 0x{0:X4}-0x{1:X4}. Verify these IDs are unused before import.' -f $BaseId,($BaseId+$rows.Count-1))
