# Black Tower Dungeon

PNG, black-background BMP and encoded static-art BIN records are provided. All canvases are44x128. Preserve padding: UO ground axes are22 pixels and height is4 pixels per world Z. Use manifest.json/csv to map each piece to verified unused item-art IDs. No IDs are allocated. BIN files are individual records, not whole client data files. Back up current client data before importing.

Door artwork includes two axes, both hinges and open/closed states. Server door types, collision, tiledata and scripts still need configuration. Openings must not receive full-cell blocking indiscriminately. Stair layouts in layouts/ show four segments, each rising5 world Z, with landing at20; configure stair flags/height and test player traversal. Horned pieces rise24 world Z. A visual assembly does not validate live movement. No install or gameplay scripts supplied.

58 native RGB555/alpha round trips passed. Four door pairs and four stair layouts were generated. Native assembly and all-piece sheet were inspected. Check seams, corner placement, player passage through arches/doors, stairs, clipping and tiledata in your target client before release. Native pieces are static; ember slits do not animate.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
