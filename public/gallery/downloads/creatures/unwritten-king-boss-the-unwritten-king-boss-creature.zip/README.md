# The Unwritten King

A standalone animated boss creature based on the original Unwritten King summoning design: a faceless sovereign with weathered bronze trim, charcoal robes, articulated claws, hanging chains and a suspended five-blade crown.

## Contents

The earlier summoning-circle effect is a separate asset. This package supplies the moving creature's artwork; it contains no server AI, stats, loot or scripted boss abilities. No client/server files have been changed.

## Import

This is **category 1 / low / animal-layout VD**: 13 action slots and five stored facings. The client mirrors three facings to display eight. This layout supports distinct walking and running cycles and can be used for a hostile NPC. It must be imported into a body compatible with that layout; a high/monster layout has 22 slots and is not interchangeable.

Do not independently centre or rescale cropped frames. Their different crop sizes retain one shared world origin. Restore only edited records when reverting; do not overwrite newer unrelated data with an old whole-client backup.

## Actions

| Slot | Native low-layout meaning | King motion | Frames per facing |
| --- | --- | --- | --- |
| 0 | Walk | Hovering walk; moving arms, robe and chains | 16 |
| 1 | Run | Faster pursuit with wider arm swing | 16 |
| 2 | Stand | Floating idle | 12 |
| 3 | Eat | Invocation gesture; requires deliberate server routing | 12 |
| 4 | Unknown / auxiliary | Hit reaction; check recipient routing | 8 |
| 5 | Attack 1 | Claw sweep | 12 |
| 6 | Attack 2 | Two-hand strike | 12 |
| 7 | Attack 3 | Chain lash | 12 |
| 8 | Die 1 | Rightward collapse and fallen crown | 16 |
| 9 | Fidget 1 | Watch; reuses idle cycle | 12 |
| 10 | Fidget 2 | Crown command gesture | 12 |
| 11 | Lie down | Rest; reuses idle cycle for the hovering body | 12 |
| 12 | Die 2 | Leftward collapse and fallen crown | 16 |

All actions begin from the same registered neutral pose. Cyclic actions close continuously. Deaths settle into a held final pose; the overview GIF resets only to demonstrate the next playback. Invocation and crown movement are visual gestures, not implemented spells.

## Native scale and registration



The registered preview canvas is 384 × 384 with ground point (192, 350). The standing creature is roughly 290 pixels tall, intended as a large boss. The supplied crops and origins reconstruct that canvas exactly. The browser's optional enlargement is for inspection, not an alternate import scale.

## Verification

Recipient in-game verification is still required. The package has not been installed or visually accepted in a running game. Actual action routing, server cadence, collision/selection, overlap, corpse placement and final appearance remain recipient-side checks.

## Arm revision

The revised walk and pursuit use 16 frames, a clearer alternating shoulder swing and a continuous bend through the elbow and sleeve. Idle arms move more visibly. Body scale and world registration remain fixed.


Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
