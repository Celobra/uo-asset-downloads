"""Review or apply two mount-memory TileData records; Python 3, standard library.

No animation, art, accounts, saves, or server scripts are changed.
Use --apply only after closing the client and asset editors.
"""
from pathlib import Path
import argparse,struct,hashlib,json,datetime,os,re
MOUNTS=[(0x653f,291,'pack horse mount'),(0x6540,292,'pack llama mount')]
def sha(b):return hashlib.sha256(b).hexdigest()
def run(folder,server,apply=False):
 folder=Path(folder).resolve();server=Path(server).resolve()
 files={p.name.lower():p for p in folder.iterdir() if p.is_file()}
 if 'artlegacymul.uop' in files:raise ValueError('This helper supports MUL artwork only. Use the asset editor to check UOP item allocation and enter the two TileData mappings instead.')
 path=files['tiledata.mul'];data=path.read_bytes();layouts=[]
 for flags,land_record,record in [(4,26,37),(8,30,41)]:
  land=512*(4+32*land_record);group=4+32*record;rem=len(data)-land
  if rem>0 and rem%group==0 and rem//group*32<=65536:layouts.append((flags,land,record,rem//group*32))
 if len(layouts)!=1:raise ValueError('Unknown TileData layout')
 flags,land,record,count=layouts[0];idx=files['artidx.mul'].read_bytes();changes=[]
 # The package uses existing native pack bodies; their animation data is untouched.
 animation_index=files['anim.idx'].read_bytes();animation_size=files['anim.mul'].stat().st_size
 for _,body,_ in MOUNTS:
  for group in range(65):
   off,length,_=struct.unpack_from('<III',animation_index,(22000+(body-200)*65+group)*12)
   if off==0xffffffff or length in (0,0xffffffff) or off+length>animation_size:raise ValueError('A native pack-animal animation is missing')
 animated=set()
 if 'animdata.mul' in files:
  ad=files['animdata.mul'].read_bytes()
  for base in range(min(count,65536)):
   at=base//8*548+4+base%8*68
   if at+68>len(ad):break
   frames=ad[at+65]
   if frames:
    animated.add(base);animated.update(base+o for o in struct.unpack_from('<64b',ad,at)[:min(frames,64)])
 scripts=server/'scripts'
 if not scripts.is_dir():raise ValueError('Server folder must contain scripts')
 own=(Path(__file__).with_name('rideable_pack_mounts.scp')).read_text().replace('\r\n','\n')
 for item,body,name in MOUNTS:
  if item>=count:raise ValueError('Mount item is outside TileData')
  if item in animated:raise ValueError(f'Mount item 0x{item:04X} is used by AnimData')
  at=land+(item//32)*(4+32*record)+4+(item%32)*record;old=data[at:at+record]
  new=bytearray(record);new[:flags]=(0x00400000).to_bytes(flags,'little');new[flags+1]=25;struct.pack_into('<H',new,flags+6,body);new[flags+13:]=name.encode().ljust(20,b'\0');new=bytes(new)
  blank=bytearray(old)
  if blank[flags] in (0,255):blank[flags]=0
  if old!=new and any(blank):raise ValueError(f'TileData 0x{item:04X} is occupied; choose fresh IDs and update the paired script')
  art_at=(item+0x4000)*12
  if art_at+12>len(idx):raise ValueError('Mount item is outside the art index')
  off,length,_=struct.unpack_from('<III',idx,art_at)
  if off!=0xffffffff and length not in (0,0xffffffff):raise ValueError(f'Artwork 0x{item:04X} is occupied')
  for p in scripts.rglob('*.scp'):
   text=p.read_text(encoding='cp1252',errors='replace').replace('\r\n','\n')
   if text==own:continue
   if re.search(r'(?im)^\s*\[ITEMDEF\s+(?:0x0*'+format(item,'x')+r'|0+'+format(item,'x')+r'|'+str(item)+r')\s*\]',text):raise ValueError(f'Server already defines mount item 0x{item:04X}')
   if re.search(r'(?im)^\s*mount_0x0*'+format(body,'x')+r'\s*[=\t ]',text):raise ValueError(f'Server already maps pack body {body}')
  if old!=new:changes.append((at,old,new,item))
 print(json.dumps({'mode':'apply' if apply else 'review only','changes':[{'item':f'0x{i:04X}','offset':at,'before':a.hex(),'after':b.hex()} for at,a,b,i in changes]},indent=2))
 if not apply or not changes:return
 stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f');backup=folder/('pack-mount-backup-'+stamp);backup.mkdir()
 # Save only the affected records. Never restore an old complete client file.
 report={'tiledata_size':len(data),'before_sha256':sha(data),'records':[{'offset':at,'before':a.hex(),'after':b.hex(),'item':i} for at,a,b,i in changes]}
 (backup/'records.json').write_text(json.dumps(report,indent=2))
 with path.open('r+b') as stream:
  if os.name=='nt':
   import msvcrt
   msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,len(data))
  try:
   stream.seek(0)
   if stream.read()!=data:raise ValueError('Client changed since review; nothing written')
   expected=bytearray(data)
   for at,old,new,_ in changes:stream.seek(at);stream.write(new);expected[at:at+len(new)]=new
   stream.flush();os.fsync(stream.fileno());stream.seek(0)
   if stream.read()!=expected:raise RuntimeError('Post-write validation failed; retain records.json for recovery')
  finally:
   if os.name=='nt':stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,len(data))
 report['after_sha256']=sha(expected);report['unrelated_bytes_preserved']=True
 (backup/'records.json').write_text(json.dumps(report,indent=2));print('Two-record mapping applied; file permissions and unrelated bytes retained. Backup:',backup)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('client_folder');p.add_argument('--server',required=True);p.add_argument('--apply',action='store_true');a=p.parse_args();run(a.client_folder,a.server,a.apply)
