Rideable pack mounts

Before importing: close the client and asset editors, check access to every file to be saved, and back up the current development data. Use verified unused destination IDs. Keep MUL/IDX pairs together, preserve other entries and use the data bank/container the client actually reads. These downloads do not contain UO client data, accounts or world saves. Install matching client art for every player. Check the result in game before using it on a live shard.

## Setup

Import **Llama/Rideable-Pack-Llama.vd** into animal body **292 / 0x0124** to apply the rear-pack correction. Export and retain the current body first; replacing this existing body changes the pack llama's appearance for all pack llamas using it. The horse VD remains the original stock animation and is optional in a standard client. A VD alone does not enable riding: the following client mapping and server script are required together. The mapping helper changes TileData only; it does not import the revised llama artwork. If riding is already configured, only the revised llama VD is needed for this visual update.

Two internal mount-memory item slots are proposed. They were blank in the development preflight; they are not reserved and must still be free in your destination data.

| Item ID | Animation body | Layer | Flags | Weight | Name |
| --- | --- | --- | --- | --- | --- |
| 0x653F | 291 | 25 | Wearable (0x00400000) | 0 | pack horse mount |
| 0x6540 | 292 | 25 | Wearable (0x00400000) | 0 | pack llama mount |

1. Close the client. Export the current llama animation body and back up the affected server script configuration. Import the revised llama VD into body 292 using your animation editor, then save and close the editor.
2. Review these two entries in your asset editor. If both IDs are unused, enter the table's TileData values. Alternatively, with Python 3 installed, run `python Apply-Client-Mapping.py "YOUR_CLIENT_FOLDER" --server "YOUR_SERVER_FOLDER"` to review the candidate changes, then repeat with `--apply` to apply them. The helper supports MUL artwork, rejects occupied records and direct script conflicts, changes only these two records, preserves file permissions and saves a record-level recovery file beside TileData. It does not install server scripts. For UOP artwork, use the asset editor's allocation checks.
3. Copy rideable_pack_mounts.scp into your Sphere scripts/mounts folder and ensure that folder or file is listed in spheretables.scp under [RESOURCES]. Do not load it twice. If you selected different free item IDs, update both ITEMDEF headers and the client entries together.
4. Restart Sphere and the normal client. Tame or own a pack horse or pack llama, then double-click it to ride. Double-click yourself to dismount. Ownership and normal mounting restrictions remain enforced by Sphere.
5. Use `.packmount_bags` to open the ridden animal's original pack. When on foot, the command asks you to target your nearby pack animal. Bags remain on the same creature; the script does not transfer, duplicate or replace cargo.

To remove this setup, dismount affected riders first, unload the script and restore only the two recorded TileData entries from the recovery file. To undo the visual correction, restore the previously exported llama body only. Do not replace newer complete client data with an older backup.

