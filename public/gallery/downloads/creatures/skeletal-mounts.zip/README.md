# Skeletal Mounts — movement revision 2

Four complete mounts based on the original UO horse, llama, Zostrich (frenzied ostard) and Orn (forest ostard). Weathered ivory bone, dark joints, exposed ribs and small brown leather saddles keep their appearance subdued at native size. The creature and saddle are one animation.

Each mount folder contains its Skeletal-Name.vd, a manifest and a Figurine.png/Figurine.art inventory icon. There are 65 groups per mount: 13 low/animal action slots with five stored facings mirrored into eight. Walking, running, standing, feeding, rearing, kicking, attacking, looking, fidgeting and both death slots are supplied. Auxiliary slots reuse the standing artwork; each corpse holds its final pose. All actions now share fixed body and limb artwork. Frames no longer resize to changing outlines. Five movement phases match the original rider cadence; the saddle follows the native rider translations.

## Import as new mounts

These are import candidates. No destination IDs have been allocated, no original creature has been replaced, and no live client or server files have been installed.

1. Back up the recipient's current client and server. Choose four genuinely unused low/animal body IDs and eight unused item-art IDs: one mount memory and one figurine per creature. Inspect all animation banks, body remaps, mobtypes, art, TileData, AnimData and server definitions. Reference bodies 226, 220, 218 and 219 are occupied originals, not suggested destinations.
2. Import each .vd into its chosen low/animal body with UOFiddler or your animation importer. Keep all 13 actions and the supplied frame centres. Configure the target client's body routing as ANIMAL and remove no unrelated mappings.
3. Import each Figurine.art (or Figurine.png) into its chosen figurine item slot. Set its TileData name and weight 1. Configure the mount-memory item's TileData with the Wearable flag 0x00400000, layer 25 and Animation set to the corresponding body ID. Give that hidden memory slot a valid item-art entry, such as a copy of the matching figurine icon. It is the engine's mounted display record; no player-equipped armour overlay is used.
4. For Sphere X, fill Server/mapping.example.json with your verified allocations. Run `python Server/Prepare-Mounts.py --mapping your-mapping.json --output your-review-folder`. This creates a reviewable Sphere script and import plan only. It does not verify/reserve allocations or install anything. The helper rejects duplicate/out-of-range IDs and known native reference bodies; other occupied IDs remain the operator's responsibility.
5. Review the generated plan and register skeletal_mounts.scp once in the shard's mount-script category. The four definitions are c_skeletal_horse, c_skeletal_llama, c_skeletal_zostrich and c_skeletal_orn. The i_pet_skeletal_* figurines use the standard Sphere figurine behaviour. Existing ownership, taming and riding rules apply. Starter stats are 100 strength, 80 dexterity and 10 intelligence, with hunger disabled; adjust balance for the shard.
6. Test the import in the original client: both riders, clothing overlap, all directions, walking/running, attack overlays, dismount/remount, terrain, corpse routing and save/restart. The offline rider preview does not replace that acceptance check.

## Validation

All 1,200 mount frames are checked through the actual ClassicUO animation decoder for matching pixels, dimensions and origins. Automated checks cover native alpha/colour limits, clipping, five distinct walk/run phases in each stored direction and held corpse frames. Motion checks also verify unchanged upper-body pixels after rider alignment, constant bone lengths, exact closed gait loops and matching standing-to-action entries. The offline preview is exercised across all mounts, actions, directions and rider poses; the release also undergoes archive, checksum and relocated-preview checks.

The supplied Sphere definitions passed 33 runtime cases (42 assertions) on an isolated Sphere X nightly build 4232 with a connected normal player: correct body/mount-memory IDs, ownership, mounting, dismounting, remounting the same creature, stranger rejection and figurine configuration. Runtime fixtures use private test IDs, not recipient allocations. Inventory activation, save/restart, shard-specific hooks, live animation routing and visual acceptance remain after import. 

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
