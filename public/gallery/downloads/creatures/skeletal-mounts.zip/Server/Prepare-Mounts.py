"""Prepare four ordinary Sphere X mounts using operator-verified free IDs. No installation."""
from pathlib import Path
import argparse,json,hashlib
NAMES=['Horse','Llama','Zostrich','Orn']
OCCUPIED_REFERENCES={200,204,210,218,219,220,226,228,291,292,346}
def integer(value):
    if isinstance(value,bool) or not isinstance(value,(str,int)):raise ValueError('IDs must be integers or integer strings.')
    return int(value,0) if isinstance(value,str) else int(value)
def validate(mapping):
    if set(mapping)!={n.lower() for n in NAMES}:raise ValueError('Provide horse, llama, zostrich and orn mappings.')
    result={key:{k:integer(v) for k,v in row.items()} for key,row in mapping.items()}
    bodies=[];items=[]
    for row in result.values():
        if set(row)!={'body','memory','figurine'}:raise ValueError('Each mount needs body, memory and figurine.')
        if not 200<=row['body']<=399 or row['body'] in OCCUPIED_REFERENCES:raise ValueError('Select a verified unused low/animal body; native reference bodies are rejected.')
        bodies.append(row['body'])
        for key in ['memory','figurine']:
            if not 1<=row[key]<=65535:raise ValueError('Item IDs must be between 1 and 65535.')
            items.append(row[key])
    if len(set(bodies))!=4 or len(set(items))!=8:raise ValueError('Use four unique bodies and eight unique item IDs.')
    return result
def script_for(mapping):
    mapping=validate(mapping);parts=['// Skeletal mounts. Body and item allocations supplied by the operator.\n// Install matching client animations, figurine art and TileData first.\n']
    for name in NAMES:
        key=name.lower();m=mapping[key];body=m['body'];memory=m['memory'];figurine=m['figurine']
        parts.append(f'''[CHARDEF 0{body:x}]
DEFNAME=c_skeletal_{key}
NAME=Skeletal {name}
CAN=mt_walk|mt_run
DAM=3,6
ARMOR=15
ICON=0{figurine:x}
MAXFOOD=0
CATEGORY=Custom assets
SUBSECTION=Skeletal mounts
DESCRIPTION=Skeletal {name}
ON=@Create
NPC=brain_animal
STR=100
DEX=80
INT=10
KARMA=0
FAME=0
TAMING=0.0

[ITEMDEF 0{memory:x}]
DEFNAME=i_mt_skeletal_{key}
NAME=Skeletal {name} mount
TYPE=t_eq_horse
LAYER=25
WEIGHT=0

[DEFNAME skeletal_{key}_mount]
mount_0x{body:x}=i_mt_skeletal_{key}

[ITEMDEF 0{figurine:x}]
DEFNAME=i_pet_skeletal_{key}
NAME=Skeletal {name}
TYPE=t_figurine
TDATA3=0{body:x}
WEIGHT=1
CATEGORY=Custom assets
SUBSECTION=Skeletal mount figurines
DESCRIPTION=Skeletal {name} figurine
''')
    return '\n'.join(parts)+'\n[EOF]\n'
def prepare(mapping,output):
    mapping=validate(mapping);out=Path(output).resolve();root=Path(__file__).resolve().parents[1]
    if out.exists():raise ValueError('Output already exists. Choose a fresh review folder.')
    records=[]
    for name in NAMES:
        m=mapping[name.lower()];vd=root/name/f'Skeletal-{name}.vd'
        records.append(dict(name=name,**m,vd=f'{name}/Skeletal-{name}.vd',vd_sha256=hashlib.sha256(vd.read_bytes()).hexdigest(),animation_layout='13-action low/animal',memory_tiledata=dict(flags='Wearable 0x00400000',layer=25,animation=m['body'],weight=0),figurine_art=f'{name}/Figurine.art',figurine_tiledata=dict(name=f'Skeletal {name}',weight=1,layer=0)))
    plan=dict(status='REVIEW ONLY; operator-supplied IDs are not allocation-verified or reserved',mounts=records,requires=['Verify current animation banks and all body remaps','Verify item art, TileData, AnimData and Sphere references for every chosen item ID','Import VDs as low/animal bodies and classify routing as ANIMAL','Set each mount-memory TileData animation to its matching body','Register the prepared Sphere file once','Test both riders, all facings, mount/dismount and save/restart'])
    out.mkdir(parents=True);(out/'skeletal_mounts.scp').write_text(script_for(mapping),encoding='ascii');(out/'import-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8');return plan
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mapping',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    try:print(json.dumps(prepare(json.loads(a.mapping.read_text(encoding='utf-8-sig')),a.output),indent=2))
    except (ValueError,KeyError,TypeError) as error:p.error(str(error))
