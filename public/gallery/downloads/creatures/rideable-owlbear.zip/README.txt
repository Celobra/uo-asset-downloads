RIDEABLE OWLBEAR — APPROVED NATIVE ANIMATION

Owlbear.vd contains 13 animal actions, 65 sequences and 300 frames.
The included PNGs are tight native crops; frames.json preserves their centres.
Five stored directions provide eight displayed views using normal mirroring.

IMPORT AND MOUNT SETUP
Back up your client data and test in a separate development copy.
Close tools using the data, then import Owlbear.vd with UOFiddler into an
unused compatible animal/mount body slot. Preserve its category and centres.
Choose a free mount-item mapping and configure your server creature definition
and client body routing to use your chosen body. This download assigns no IDs
and installs no server script or client patch. Do not overwrite an occupied slot.

Walk/run/stand use 5/5/1 frames to match the inspected mounted rider cycles.
Offline male/female base-rider fit used zero additional Y offset. Verify the
target client, equipped layers, terrain overlap, targeting, hues, corpse
placement and actual playback in game. Animal slot 7 differs in name/routing
between UOFiddler and ClassicUO; confirm it in your client/server.

Previews: https://www.uoassets.com/?category=creatures&collection=Rideable-Owlbear#rideable-owlbear
Animation previews use 80 ms per frame for inspection, not a timing patch.
The approved VD was independently decoded with UOFiddler; all 300 frames,
dimensions, transparency, RGB555 colours and centres matched its source.
In-game mount integration remains a recipient test.
