# Healing Companions

All four creature VDs and the shared Sphere setup template are included together so the server definitions and artwork stay consistent. No destination IDs are assigned.

## Import the artwork

1. Back up the intended game data and inspect its current animation allocations. **No destination IDs have been allocated by this package.** Choose four genuinely unused low/animal body entries between decimal 200 and 399 for the supplied server preparation tool.
2. Import the matching VD into each chosen low/animal entry with UOFiddler or your animation importer. Preserve the stored frame centres. Do not import this 13-action format directly into a 22-action monster or 35-action equipment layout.
3. Verify that body conversions and `mobtypes.txt` select those exact animations as **ANIMAL**, with no conflicting UOP or body remapping. Keep the client and Sphere's animation classification consistent. An ID being in the numeric range alone does not prove it is unused or correctly mapped.
4. Test all eight facings, standing, walking, running and healing in the original client. The preview's timing is illustrative; actual movement timing is controlled by the client and server.

## Following and healing on Sphere X

The **Server** folder contains a preparation tool and script template. Python 3 is needed only to prepare the script; players do not need Python or AI tools.

Run `python Server/prepare.py --help`, then supply your four verified body IDs using `--drake`, `--slime`, `--wisp` and `--sprite`. Decimal and `0x` hexadecimal notation are accepted. The tool writes `Prepared/healing_companions.scp`; it never installs anything and refuses to overwrite an existing output. It checks numeric range and distinctness, not the recipient's actual asset allocations.

Register the prepared file once in your Sphere script resources and restart your test server. Do not register the `.scp.in` template directly. A GM can create the four charms with:

```
.add i_hc_drake_charm
.add i_hc_slime_charm
.add i_hc_wisp_charm
.add i_hc_sprite_charm
```

Give a charm to the player. Double-click it in their backpack to summon the companion; double-click again to dismiss it. It bonds on first use. Using another companion charm switches the active pet. Only one can be active per player, separately from ordinary tameable pets; these companions use zero normal follower slots.

The companion follows its owner and restores **up to 6 hit points every 8 seconds**, capped at maximum health, within **3 tiles** and clear line of sight. Switching or dismissing does not reset the shared healing cooldown. The companion does not attack, cure poison or resurrect. It rests when the owner dies, logs out, leaves its map, exceeds the 18-tile leash, or loses the active charm. Double-click the charm to call it again after returning or travelling. Standard pet speech commands are suppressed; the charm controls it.

Adjust `hc_heal_amount`, `hc_heal_seconds`, `hc_heal_range` and `hc_leash_range` in the prepared script for your shard's balance. Keep them positive. The supplied defaults are a modest starting point, not a tested balance recommendation for every shard.


Recipient asset mappings, animation timing, pathfinding, teleports, save/restart behavior, shard-specific events and balance require in-game acceptance checks.
