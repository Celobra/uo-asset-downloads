"""Prepare a standalone Sphere script. This tool does not install or edit game data."""
from pathlib import Path
import argparse

PETS=[('drake','Moss Drake','i_pet_dragon'),('slime','Balm Slime','i_pet_slime'),('wisp','Silver Wisp','i_pet_wisp'),('sprite','Woodland Sprite','i_pet_pixie')]

def prepare(ids):
    if len(set(ids)) != 4 or any(not 200 <= n < 400 for n in ids):
        raise ValueError('Supply four distinct verified free body IDs from 200 through 399, configured as low/animal animations.')
    pieces=[]
    for (slug,name,icon),body in zip(PETS,ids):
        pieces.append(f'''[CHARDEF c_hc_{slug}]
ID=0{body:x}
NAME={name}
CAN=mt_walk|mt_run
ICON={icon}
FOODTYPE=5 t_food
MAXFOOD=100
FOLLOWERSLOTS=0
TSPEECH=spk_hc_companion
TEVENTS=e_hc_companion
ON=@Create
NPC=brain_animal
STR=50
DEX=80
INT=10
HITS=50
FOOD=100
FLAGS=<FLAGS>|statf_invul|statf_conjured

[ITEMDEF i_hc_{slug}_charm]
ID={icon}
NAME={name} companion charm
TYPE=t_normal
WEIGHT=1
ON=@Create
TAG.hc_definition=c_hc_{slug}
ON=@DClick
RETURN <f_hc_toggle>
ON=@Destroy
REF1=<TAG0.hc_controller>
IF (<REF1>)
    IF (<REF1.BASEID> == i_hc_controller) && (<REF1.TAG0.hc_charm> == <UID>)
        REF1.f_hc_cleanup
    ENDIF
ENDIF
RETURN 0
''')
    template=Path(__file__).with_name('healing_companions.scp.in').read_text()
    return template.replace('__DEFINITIONS__','\n'.join(pieces))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for pet,_,_ in PETS:parser.add_argument('--'+pet,type=lambda s:int(s,0),required=True)
    parser.add_argument('--output',type=Path,default=Path('Prepared/healing_companions.scp'))
    args=parser.parse_args()
    result=prepare([getattr(args,p) for p,_,_ in PETS])
    if args.output.exists():raise SystemExit('Output already exists; choose a new output path.')
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(result)
    print('Prepared',args.output,'; no client or server installation performed.')
