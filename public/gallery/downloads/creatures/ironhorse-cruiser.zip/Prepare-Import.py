"""Create shard-specific setup files without editing a client or server."""
from pathlib import Path
import argparse,json,hashlib

def number(value):
 return int(value,16 if value.lower().startswith('0x') else 10)

def prepare(body,memory,figurine,output):
 if not 200<=body<=399:raise ValueError('Choose a verified free classic low/animal body in 200..399; other layouts need explicit animation routing.')
 if body in (218,219,220,226,291,292,346):raise ValueError('This is an occupied reference/native body, not a destination.')
 if not 0<=memory<=0xffff or not 0<=figurine<=0xffff or memory==figurine:raise ValueError('Choose two different item IDs in the client item range.')
 root=Path(__file__).resolve().parent;out=Path(output).resolve()
 if out.exists():raise ValueError('Output directory already exists; use a fresh review folder.')
 template=(root/'cruiser-mount.scp.template').read_text()
 values={'BODY':format(body,'x'),'MEMORY':format(memory,'x'),'FIGURINE':format(figurine,'x')}
 for key,value in values.items():template=template.replace('{{'+key+'}}',value)
 assert '{{' not in template
 plan={'status':'REVIEW ONLY; IDs supplied by operator, not reserved or verified by this helper','body':body,'mount_memory':memory,'figurine':figurine,'vd':'Ironhorse-Cruiser.vd','native_category':1,'tiledata':{'memory':{'flags':'Wearable (0x00400000)','layer':25,'animation':body,'weight':0},'figurine':{'name':'Ironhorse cruiser','weight':1,'art':'Cruiser-Figurine.png'}},'vd_sha256':hashlib.sha256((root/'Ironhorse-Cruiser.vd').read_bytes()).hexdigest(),'must_check':['Current animation body and all remaps are unused','Both art/TileData records and AnimData references are unused','No existing Sphere resource or mount mapping uses these IDs','Current backups and exclusive client-file editing window','Original-client riding fit, equipment overlap and sound preferences']}
 out.mkdir(parents=True);(out/'ironhorse_cruiser.scp').write_text(template,encoding='ascii');(out/'import-plan.json').write_text(json.dumps(plan,indent=2))
 (out/'READ-BEFORE-IMPORT.txt').write_text('These files are a review plan, not an installer. Verify all three IDs against the current client and server before importing. Follow the main package README. No client/server files were changed.\n')
 return plan

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--body-id',required=True,type=number);p.add_argument('--memory-id',required=True,type=number);p.add_argument('--figurine-id',required=True,type=number);p.add_argument('--output',required=True);a=p.parse_args()
 try:plan=prepare(a.body_id,a.memory_id,a.figurine_id,a.output)
 except ValueError as e:p.error(str(e))
 print(json.dumps(plan,indent=2))
