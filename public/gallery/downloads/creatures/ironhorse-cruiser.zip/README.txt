Ironhorse Cruiser

Before importing: close the client and asset editors, check access to every file to be saved, and back up the current development data. Use verified unused destination IDs. Keep MUL/IDX pairs together, preserve other entries and use the data bank/container the client actually reads. These downloads do not contain UO client data, accounts or world saves. Install matching client art for every player. Check the result in game before using it on a live shard.

In UOFiddler Animation Edit import the VD into a verified compatible low/animal body (13 action slots, five stored facings mirrored to eight). Preserve frame dimensions and centres. Save and deploy the matching animation MUL/IDX pair or the mapped bank actually read by the client. Inspect body.def, bodyconv.def and mobtypes.txt routing before allocating a new body.

Create a Sphere CHARDEF using that display body and choose the required NPC type, stats, sounds and behaviour. For a rideable creature also define a t_eq_horse mount-memory item, the Sphere mount_0xBODY mapping and a matching TileData record: Wearable 0x00400000, layer25, Animation=creature body, weight0. IDs must match on client and server. A VD alone does not create a spawn or enable riding. Test action routing, targeting, corpses and all rider/equipment views.

Use Python 3: python Prepare-Import.py --body-id YOUR_BODY --memory-id YOUR_MEMORY --figurine-id YOUR_FIGURINE --output new-import-folder. Decimal or 0x IDs are accepted. Review the output plan and script. Import the figurine PNG at its separate item ID; use the normal zero rider offset. Engine sound and continuous parked smoke are not included.
