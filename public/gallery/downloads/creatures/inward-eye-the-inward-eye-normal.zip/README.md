# The Inward Eye

A standalone floating eyeball monster with an inward-folding cast, organic trailing nerves and a bloodshot state. Original UO Gazer animations were studied for native viewpoint, restrained materials and creature scale.

## Files

Both forms use one mesh, camera, radius and animation timing. Bloodshot changes affect material colour and veins, not anatomy, position or silhouette. Normal attacks and warning gestures briefly flush red and recover; the bloodshot VD remains red between actions.

## Import as a monster

These are **UOFiddler category 0 / high / monster-layout VDs**, with 22 action slots and five stored facings. The client mirrors three to produce eight. They are not 13-slot animal-layout or wearable-equipment files.

1. Close the client and back up its current animation data using your editor's recovery workflow.
2. Verify an unused compatible monster body for each form you want to import. Inspect all relevant banks, remappings and server references. No body IDs are reserved by this package.
3. Import the chosen VD with UOFiddler or a compatible editor. Preserve all frame origins and save only the intended body edits. Cropped frame dimensions vary; do not centre or rescale each crop separately.
4. Configure a server monster to use that body and suitable AI, stats and abilities. Use the native **Cast slot 12** for the folding animation. To maintain an enraged bloodshot state, the server can switch to the separately imported bloodshot body; the files use matching action counts and origins.
5. Check every facing, locomotion, casting, hit reaction and corpse in the original client. Tune server/client timing as required.

The package provides the monster's visuals, not server combat AI, damage, spells, loot or an automatic body-switch script. VD files do not contain playback speed. Preview timing is illustrative.

## Native action map

| Slot | Native meaning | Supplied motion | Frames per facing |
| --- | --- | --- | --- |
| 0 | Walk | Floating locomotion | 16 |
| 1 | Stand | Floating idle with moving nerves | 16 |
| 2–3 | Die 1–2 | Two settling collapses | 20 each |
| 4 | Attack 1 | Gaze strike | 16 |
| 5 | Attack 2 | Bloodshot pulse | 16 |
| 6 | Attack 3 | Partial inward fold strike | 20 |
| 7–9 | Misc 1–3 | Watch, drift and rest; sampled idle motion | 12 each |
| 10 | Stumble | Recoil | 10 |
| 11 | Slap ground | Nerve lash | 16 |
| 12 | Cast | Full inward fold, hold, release and recovery | 32 |
| 13 | Get hit 1 | Hit reaction | 10 |
| 14 | Misc 4 | Bloodshot warning | 16 |
| 15–16 | Get hit 2–3 | Directional recoils | 10 each |
| 17 | Fidget 1 | Sampled idle motion | 12 |
| 18 | Fidget 2 | Bloodshot flush and recovery | 20 |
| 19 | Fly | Faster pursuit motion | 16 |
| 20 | Land | Settle gesture | 16 |
| 21 | Die in flight | Settling collapse, matching the primary death | 20 |

Monster layouts have no dedicated Run slot. Standard ground pursuit may reuse Walk at the recipient client's cadence; slot 19 is available when deliberately routed as Fly. Some auxiliary slots deliberately reuse idle or death motion as listed above. Both deaths and death-in-flight hold their last pose.

## Motion and appearance


The globe is about 72 native pixels across. All frames reconstruct on a 192 × 192 canvas with ground point (96, 174). The preview defaults to 200% for inspection. The native assets use a shared RGB555 palette and binary transparency.

## Validation and remaining checks

Recipient in-game verification is still required. No live client or server was modified. No in-game visual acceptance is claimed. Recipient allocation/import, actual spell routing and timing, movement cadence, player scale, targeting, terrain occlusion and corpse placement remain in-game checks.

Restore only your changed records if reverting; do not replace newer unrelated client data with an old whole-file backup. This is new UO-inspired monster artwork, not an official UO asset.


Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
