# Dwarf Monsters — full animations

Stoneguard Warrior, Deepdelver Miner and Runesmith are three separate dwarf monster bodies with short, broad adult proportions, substantial beards and practical clothing and tools. Each has a complete ground-monster action set and a matching whole-body paperdoll.

This runtime edition contains all three characters. Animated previews and matching paperdolls are available in the Dwarf Monsters collection on the UO Asset Library website.

## Contents

- Three individual UOFiddler VD files, one in each character folder.
- 350 frames per character: 15 actions × five stored facings, 75 populated sequences. Total: 1,050 frames.
- Transparent cropped PNG frames and their centre/dimension metadata.
- Three matching paperdolls, unchanged from the design release: PNG, native gump payload and import metadata.
- Preview, per-action profile GIFs, overview and exact artwork prompts.

## Action coverage

All three use the original **22-slot high/monster layout**. Five stored views provide eight screen directions through client mirroring; mirroring also reverses the visible tool sides.

| Slot | Action | Frames per facing |
| --- | --- | ---: |
| 0 | Walk | 10 |
| 1 | Stand | 1 |
| 2 | Death backward | 4 |
| 3 | Death forward | 4 |
| 4 | Weapon strike | 4 |
| 5 | Backhand strike | 4 |
| 6 | Heavy overhead strike | 4 |
| 10 | Stumble | 4 |
| 11 | Ground strike | 5 |
| 12 | Cast | 7 |
| 13 | Strong hit | 7 |
| 15 | Hit recoil | 3 |
| 16 | Side flinch | 3 |
| 17 | Idle breathe | 5 |
| 18 | Idle glance | 5 |

Slots 7, 8, 9, 14, 19, 20 and 21 are intentionally empty. These grounded creatures have no flight actions. This layout shares its walk with fast ground movement; there is no separate run sequence. Action names describe the supplied poses; server animation requests must use the matching monster layout.

The website uses an illustrative 80 ms per frame at Normal speed and repeats each selected action. VD files do not carry a playback speed; actual timing is controlled by the client and server. The low frame counts follow the native monster references and produce classic stepped animation.

## Import and use

1. Work from the recipient's current backed-up client data. Find three unused body slots that support this monster layout; no body IDs are preassigned here.
2. Import each character's VD through the animation editor into its chosen body slot. Check all 15 populated actions, five stored facings and frame centres before saving the animation data.
3. Configure the server creature definition and any client body conversion/type mappings for those chosen bodies. Monster behaviour, stats and AI belong to that server setup; this package supplies the artwork.
4. Import each paperdoll PNG into a separately verified free gump slot and configure the appropriate body-to-paperdoll mapping. The native `.gump.bin` is only for tools accepting a raw UO gump RLE payload with dimensions from `import.json`.
5. Check the dwarf beside a native human in game, then inspect turning, walking at normal and fast movement, each attack, cast, hit, both deaths, corpse direction, targeting and paperdoll placement.

These are complete monster-body illustrations. Their clothing, beards and tools are part of the body image. The paperdolls are complete portraits, not wearable armour layers; normal human clothing overlays will not automatically fit these proportions. They are raster sprite sets, not rigged 3D or playable human character models.

## Validation and remaining checks

The original installed ClassicUO animation decoder reproduced every exported frame, centre and dimension. All 1,050 PNG frames and preview atlas crops match the decoded VD pixels. Every action sequence has distinct frame images; the three paperdolls are byte-identical to the design release. Coverage, binary alpha, canvas bounds, mirrored preview drawing, pause/step, normal and half-speed timing, walk looping and final death holds were checked offline.

There has been no live in-game test or installation. Body/gump allocation, server routing, runtime timing, occlusion and paperdoll mapping remain to be checked in the receiving client/server. Small painted detail and shape differences between poses remain; this is not a single rigged mesh. The original static design package is preserved separately.
