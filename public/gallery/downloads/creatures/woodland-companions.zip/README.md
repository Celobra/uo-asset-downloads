# Woodland Companions

Four small companions drawn from the proportions and materials of original Ultima Online creatures: Fern Drake, Bog Frog, Moon Moth and Amber Kirin.

| Companion | Appearance | Approximate standing height |
| --- | --- | --- |
| Fern Drake | Low wingless reptile with moss-green scales and tapering tail | 28 pixels |
| Bog Frog | Natural olive-brown frog with copper eyes and a pale throat | 21 pixels |
| Moon Moth | Silver-sage wings with subtle crescent markings | 25 pixels |
| Amber Kirin | Slender young kirin with muted gold scales and auburn mane | 40 pixels |

Each folder contains a UOFiddler **.vd**, transparent PNG frames, frame positions, a manifest and movement GIFs. Each VD contains 13 low/animal action slots, five stored directions and 390 frames. The client mirrors three directions for eight display facings. The four files contain 1,560 frames in total.

The frog idle uses its first three quiet poses in a six-frame breathing loop. Six generated action sheets per companion provide walk, run, idle, heal, recoil and death. Feed, look and fidget slots reuse idle; slots 5–7 share the healing gesture; alternate death reuses the primary death. These are noncombat companions, so the server uses the attack slots to display healing. Death and recoil are supplied for animation completeness; the supplied gameplay makes the companions invulnerable.

## Import the artwork

1. Back up the intended game data and inspect its current animation allocations. **No destination IDs have been allocated by this package.** Choose four genuinely unused low/animal body entries between decimal 200 and 399 for the supplied server preparation tool.
2. Import the matching VD into each chosen low/animal entry with UOFiddler or your animation importer. Preserve the stored frame centres. Do not import this 13-action format directly into a 22-action monster or 35-action equipment layout.
3. Verify that body conversions and `mobtypes.txt` select those exact animations as **ANIMAL**, with no conflicting UOP or body remapping. Keep the client and Sphere's animation classification consistent. An ID being in the numeric range alone does not prove it is unused or correctly mapped.
4. Test all eight facings, standing, walking, running and healing in the original client. The preview's timing is illustrative; actual movement timing is controlled by the client and server.

## Following and healing on Sphere X

The **Server** folder contains a preparation tool and script template. Python 3 is needed only to prepare the script; players do not need Python or AI tools.

Run `python Server/prepare.py --help`, then supply your four verified body IDs using `--fern`, `--frog`, `--moth` and `--kirin`. Decimal and `0x` hexadecimal notation are accepted. The tool writes `Prepared/woodland_companions.scp`; it never installs anything and refuses to overwrite an existing output. It checks numeric range and distinctness, not the recipient's actual asset allocations.

If the original **Healing Companions** kit is already installed, add `--definitions-only` when preparing this set. This produces only the four new pet/charm definitions and reuses the original kit's shared core. Load that file alongside the existing kit. Without an existing kit, omit this option to create a complete standalone script. Load the shared core only once; do not load both standalone kits together. All eight companions share the one-active-pet limit and healing cooldown.

Register the prepared file once in your Sphere script resources and restart your test server. Do not register the `.scp.in` template directly. A GM can create the four charms with:

```
.add i_hc_fern_charm
.add i_hc_frog_charm
.add i_hc_moth_charm
.add i_hc_kirin_charm
```

Give a charm to the player. Double-click it in their backpack to summon the companion; double-click again to dismiss it. It bonds on first use. Using another companion charm switches the active pet. Only one can be active per player, separately from ordinary tameable pets; these companions use zero normal follower slots.

The companion follows its owner and restores **up to 6 hit points every 8 seconds**, capped at maximum health, within **3 tiles** and clear line of sight. Switching or dismissing does not reset the shared healing cooldown. The companion does not attack, cure poison or resurrect. It rests when the owner dies, logs out, leaves its map, exceeds the 18-tile leash, or loses the active charm. Double-click the charm to call it again after returning or travelling. Standard pet speech commands are suppressed; the charm controls it.

Adjust `hc_heal_amount`, `hc_heal_seconds`, `hc_heal_range` and `hc_leash_range` in the prepared script for your shard's balance. Keep them positive. The supplied defaults are a modest starting point, not a tested balance recommendation for every shard.

## Validation and remaining checks

Both standalone mode (31 cases / 32 assertions) and the add-on mode alongside the original Healing Companions core (35 cases / 36 assertions) passed. The companion script is tested separately against Sphere X nightly build 4232 using a connected test player. json** for the delivered test results. No live shard or installed client is changed by this package. Recipient asset mappings, animation timing, terrain/pathfinding, crowded passages, teleports, save/restart behaviour, shard-specific events and gameplay balance still need an in-game acceptance check.


Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
