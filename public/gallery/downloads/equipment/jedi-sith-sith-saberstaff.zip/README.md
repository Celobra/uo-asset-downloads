# Sith Saberstaff

Before importing: close the client and asset editors, check access to every file to be saved, and back up the current development data. Use verified unused destination IDs. Keep MUL/IDX pairs together, preserve other entries and use the data bank/container the client actually reads. These downloads do not contain UO client data, accounts or world saves. Install matching client art for every player. Check the result in game before using it on a live shard.

Import each VD as a human/equipment animation in UOFiddler Animation Edit, preserving all 35 actions, five stored directions and original frame centres. Choose an unused compatible equipment animation ID A; no IDs are assigned here. Import inventory-icon.png into a separate unused item-art ID. Set that item's TileData Animation to A, Quality/layer to the manifest layer and Wearable flag (0x00400000); use the supplied weapon settings where present. Import the male and female paperdoll PNGs as gumps 50000+A and 60000+A for the normal human routing; check bodyconv/equipconv and your client fork before choosing slots. Save the affected animation, art, gump and TileData files to a separate output, then deploy their matching pairs to the development copy.

Create a Sphere ITEMDEF using your chosen item-art ID and matching layer (t_clothing/t_armor for wearables, the manifest sphere_type for weapons, t_shield for shields). Set gameplay stats for your shard; art alone does not assign them. Test both human bodies, walk/run/riding/combat, mixed equipment, hues and paperdoll overlap. Elf/gargoyle fits are not established.

## Included items

- Sith Saberstaff: layer 2; two hands; 1050 frames.

The manifest lists the four files for each included item under items/. Import only those items. Every VD has 35 actions and five stored facings, mirrored to eight by the client. Original file bytes, frame sizes and origins are retained.

Robes and hoods are separate pieces. Shoes and gloves are not included. Blades remain ignited; there is no ignition toggle, sound, dynamic light or Force power. Set sword, staff or clothing behavior and balanced statistics on your shard.

Human male/female artwork is supplied. Check custom-ID layer order, hands, sleeves, hair, other equipment, actual mounts, hues and combat timing in the original client. Riding previews show the rider pose without a mount. This download contains runtime artwork and installation notes only.
