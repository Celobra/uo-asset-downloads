# Prideborn Barbarian Arms

This download contains 1 wearable item(s). The manifest identifies every included file and equipment layer. No destination IDs are assigned.

1. Back up the recipient installation and work on development copies. Close software using the target files before saving.
2. Allocate unused static-art, animation and male/female gump IDs. Check actual allocations and do not overwrite occupied entries.
3. Import inventory-icon.png as static item art, both paperdoll PNGs as gumps, and equipment.vd into a human-equipment slot that supports all 35 actions. Preserve dimensions, transparency and frame centres. Each item has 175 sequences and 1,050 frames; the client mirrors three additional facings.
4. Configure the item animation mapping, both paperdoll mappings, wearable flags and manifest layer in the client and corresponding server definition.
5. Check both human bodies, all actions and facings, hair, other equipment, hues, corpse poses, hand conflicts and real mounts in the original client. Final fitting and custom-ID behavior require in-game verification.

Paperdolls are registered 260x237 overlays. Inventory art is deliberately small. Do not enlarge or recenter either during import. Riding motion is included; website mounted previews show a rider pose without a mount.

SHA256SUMS.txt covers the files in this download. The artwork does not add gameplay systems automatically.

The open red coat uses Tunic layer 17 over the layer-5 shirt. Witch and wizard robes use layer 22. The Edward and Amestrian designs are Fullmetal Alchemist fan-inspired; Aetheric Alchemist is an original design. This is not an official release of either game or franchise.
