# Emerald Brocade Choker

- Emerald Brocade Choker: clothing layer 10, 1,050 animation frames.

## Import

These are import candidates. No destination IDs are assigned and nothing is automatically installed.

1. Back up your current client data and inspect current art, animation, paperdoll and server allocations before choosing unused IDs.
2. Create one clothing item per item folder. Import its inventory-icon.png, both paperdoll-*.png images and equipment.vd. Preserve the supplied dimensions and animation frame origins. Map the new animation to both human paperdolls.
3. Apply each item's layer from manifest.json to the client metadata and server item definition. Configure your shard's names, weights, dye behavior and crafting rules.
4. Import all 35 action groups (0–34), with five stored directions. The client mirrors three additional facings. Each item has 175 sequences and 1,050 frames.
5. Test both human bodies, complete outfits and individual pieces in game: walking, running, attacks, casting, falls, mounted movement and mounted attacks. Check hair, weapons, other clothing, hues and backpack drag/drop.

The long coat uses Tunic layer 17 so the waistcoat can show. The gown uses Robe layer 22. The tie and choker share Neck layer 10. The online Suit and Dress presets wear either the coat or the gown. Coats and gowns use folded inventory icons.

## Validation and fitting

Every supplied animation frame was decoded with the ClassicUO decoder and checked against the source pixels, dimensions and origins. Paperdolls and inventory icons passed native-format round trips. Walking, running and mounted previews are available on the collection's gallery page; the player supports all 35 actions and eight facings.

Final in-game fitting remains required. This download contains the items listed in its manifest, import notes and checksums. It contains no installed client, server, accounts, profiles or world saves. SHA256SUMS.txt covers every other file in this ZIP.
