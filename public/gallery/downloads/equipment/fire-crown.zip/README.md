# Crown of Fire

A wearable crown made of living fire. Seven flames orbit clockwise above the player's head; a taller flame marks each turn. A revolution takes 3.2 seconds. The painted orange, red and white-hot fire uses classic UO scale and additive rendering.

## Included

The fire hovers above the head. It follows the player's world position and movement interpolation, rather than being attached to the head bone or reproducing every head bob. Riding raises it by 22 pixels. It keeps turning while the body stands still and works independently of combat/casting action selection.

## Prepare an import

No destination art or animation IDs have been assigned. Choose **129 consecutive unused item-art IDs**, one unused human-equipment animation body, and its two corresponding free paperdoll gumps. Check actual client data, body/gump remaps and shard allocations before choosing. Existing native reference IDs are occupied.

Run `Prepare-Import.ps1` in PowerShell with `-BaseId` set to your verified starting item-art ID and `-EquipmentBodyId` set to the free human-equipment body. Decimal or 0x-prefixed hexadecimal art IDs are accepted. The body must be in the human-equipment range 400–2047. The helper checks artwork hashes and creates a local `Import` directory. It does not alter client or server files and refuses to overwrite a previous Import directory.

1. Back up and work on a copy of your current client data. Import `Import/massimport.xml` with UOFiddler Mass Import. It supplies 129 static-art and tiledata entries, plus both paperdoll gumps. Keep the padded frame dimensions intact. Male gump = 50000 + equipment body; female gump = 60000 + equipment body.
2. Import `equipment/transparent-proxy.vd` into the selected human-equipment body using the full 35-action group. Do not replace an occupied body or omit this file; it prevents a frozen crown from appearing underneath the animated effect. Confirm your client selects this MUL animation rather than an existing UOP/body remap for that body.
3. Import `Import/animdata.json` into AnimData. There are 16 eight-frame sequences with interval 1. Only each sequence's first art entry is marked Animated. Save the changed files into the intended client data copy.
4. Give client and server matching updated tiledata. Load `Import/fire_crown.scp` through the shard's custom script list after checking for defname conflicts. Create `i_rotating_fire_crown` and equip it in the head slot. A helmet uses the same slot.

The Sphere integration uses a type-3 effect attached to the wearer, additive blend 2, eight 50 ms frames per 400 ms dispatch, and 64 frames per revolution. It adds no damage, stats, protection or gameplay powers. It requires no client source modification.

## Behavior and acceptance checks

The supplied script accepts ordinary male and female human bodies. It pauses dispatch while hidden or invisible and stops on removal, death or logout. Login refreshes a crown still equipped. If another system equips items directly without normal equip triggers, or restores gear after resurrection, call `fire_crown_refresh` on the character after that system finishes. Re-equipping also restarts it. Polymorphs pause the crown until the wearer returns to a supported human body.

An effect already sent can remain for up to 400 ms plus network delay after hiding, removal, death or a mounting change. Server/client frame scheduling and latency can affect transitions between chunks. This is a cosmetic hovering effect, not a concealment mechanic. Flame intensity is baked into the art; changing the inventory item's hue does not recolor its fire.

Native static-art and AnimData decoding, paperdoll conversion, the transparent animation proxy, 215,040 offline preview states, and 27 isolated Sphere behavior checks passed. No connected client was used. Before release, check the original client with the selected IDs: equip/unequip on both bodies, all facings, movement, standing rotation, horse and custom mounts, casting/combat, hair, terrain, hiding, death, reconnect, visibility to another player and sustained server timing. Nonhuman bodies and custom mount heights are not fitted.

## Files

This is an import candidate, not an installed or published client update.


Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
