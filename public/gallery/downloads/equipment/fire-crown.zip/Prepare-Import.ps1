param(
 [Parameter(Mandatory=$true)][ValidatePattern('^(0[xX][0-9a-fA-F]+|[0-9]+)$')][string]$BaseId,
 [Parameter(Mandatory=$true)][ValidateRange(400,2047)][int]$EquipmentBodyId
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
function FileSha([string]$Path){
 $stream=[IO.File]::OpenRead($Path);$algorithm=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}
 finally{$algorithm.Dispose();$stream.Dispose()}
}
$packageRoot=$PSScriptRoot
$effect=Get-Content -LiteralPath (Join-Path $packageRoot 'manifest.json') -Raw | ConvertFrom-Json
$firstId=if($BaseId.StartsWith('0x',[StringComparison]::OrdinalIgnoreCase)){[Convert]::ToInt32($BaseId.Substring(2),16)}else{[Convert]::ToInt32($BaseId,10)}
if($firstId -lt 1 -or $firstId -gt 65407){throw 'Choose 129 consecutive unused item-art IDs; the highest must fit in 16 bits.'}
if($effect.frames.Count -ne 128 -or $effect.animations.Count -ne 16){throw 'Unexpected flame manifest'}
foreach($f in $effect.frames){
 if($f.file -notmatch '^frames/(foot|mounted)_\d{2}\.png$'){throw 'Unexpected frame path'}
 if((FileSha (Join-Path $packageRoot $f.file)) -ne $f.sha256){throw ('Damaged frame: '+$f.file)}
}
if((FileSha (Join-Path $packageRoot 'inventory.png')) -ne $effect.inventorySha256){throw 'Damaged inventory icon'}
$output=Join-Path $packageRoot 'Import'
if(Test-Path -LiteralPath $output){throw 'Import already exists. Keep or rename it before preparing another range.'}
New-Item -ItemType Directory -Path $output | Out-Null
$utf8=[Text.UTF8Encoding]::new($false);$csv=[Collections.Generic.List[string]]::new()
$csv.Add('# ID;Name;Weight;Quality;Animation;Height;Hue;Quantity;StackingOffset;MiscData;Unk2;Unk3;64 flags in bit order')
$xml=[Xml.XmlDocument]::new();[void]$xml.AppendChild($xml.CreateXmlDeclaration('1.0','utf-8',$null));$mass=$xml.CreateElement('MassImport');[void]$xml.AppendChild($mass)
for($i=0;$i -lt 129;$i++){
 $id=$firstId+$i;$fields=@([string]$id,('fire crown {0:000}' -f $i))+(@('0')*10);$flags=@('0')*64
 if($i -lt 128 -and ($i%8 -eq 0)){$flags[24]='1'}
 if($i -eq 128){$fields[1]='crown of fire';$fields[2]='1';$fields[3]='6';$fields[4]=[string]$EquipmentBodyId;$fields[5]='1';$flags[22]='1';$flags[14]='1';$flags[1]='1'}
 $csv.Add((($fields+$flags) -join ';'))
 foreach($kind in 'item','tiledataitem'){
  $node=$xml.CreateElement($kind);$node.SetAttribute('index',[string]$id)
  $file=if($kind -eq 'item'){if($i -eq 128){Join-Path $packageRoot 'inventory.png'}else{Join-Path $packageRoot $effect.frames[$i].file}}else{Join-Path $output 'tiledata.csv'}
  $node.SetAttribute('file',$file);$node.SetAttribute('remove','False');[void]$mass.AppendChild($node)
 }
}
foreach($sex in @(@('male',50000),@('female',60000))){
 $node=$xml.CreateElement('gump');$node.SetAttribute('index',[string]([int]$sex[1]+$EquipmentBodyId));$node.SetAttribute('file',(Join-Path $packageRoot ('equipment/paperdoll-'+$sex[0]+'.png')));$node.SetAttribute('remove','False');[void]$mass.AppendChild($node)
}
[IO.File]::WriteAllLines((Join-Path $output 'tiledata.csv'),$csv,$utf8);$xml.Save((Join-Path $output 'massimport.xml'))
$animations=[ordered]@{Version=1;Data=[ordered]@{}}
foreach($anim in $effect.animations){
 $timeline=@($anim.timeline | ForEach-Object {[int]$_})
 $animations.Data[[string]($firstId+$anim.offset)]=[ordered]@{FrameData=($timeline+(@(0)*(64-$timeline.Count)));Unknown=0;FrameCount=$timeline.Count;FrameInterval=1;FrameStart=0}
}
[IO.File]::WriteAllText((Join-Path $output 'animdata.json'),($animations | ConvertTo-Json -Depth 9),$utf8)
$template=Get-Content -LiteralPath (Join-Path $packageRoot 'Sphere-Template.txt') -Raw
foreach($pair in @(@('FOOT',0),@('MOUNTED',64),@('ITEM',128))){$template=$template.Replace(('@@'+$pair[0]+'@@'),('0{0:X4}' -f ($firstId+[int]$pair[1])))}
[IO.File]::WriteAllText((Join-Path $output 'fire_crown.scp'),$template,$utf8)
$note='Selected item-art range: 0x{0:X4}-0x{1:X4}. Crown item: 0x{1:X4}. Equipment body: {2}. Male/female gumps: {3}/{4}. These are user-selected IDs; their availability has NOT been checked.' -f $firstId,($firstId+128),$EquipmentBodyId,(50000+$EquipmentBodyId),(60000+$EquipmentBodyId)
$note += [Environment]::NewLine+'Manually import equipment/transparent-proxy.vd into the chosen human-equipment body with all 35 actions. Do not skip this step or reuse an occupied body.'
[IO.File]::WriteAllText((Join-Path $output 'selected-range.txt'),$note,$utf8)
Write-Output 'Prepared 129 art/tile records, two gumps, 16 AnimData records and the cosmetic Sphere script. Import the transparent VD separately.'
Write-Output 'No client or server files were changed.'
