"""Portable, offline Sphere/TileData preparation after choosing free destinations.

Does not modify a client or server. Python 3, standard library only.
Usage: python make_import_files.py allocated-ids.json output-folder
"""
import csv,json,sys
from pathlib import Path

def number(v):
 if isinstance(v,int):return v
 if isinstance(v,str)and v.lower().startswith('0x'):return int(v,16)
 return int(v)
def prepare(manifest,allocations,destination):
 settings={p['slug']:p for p in manifest['weapons']};chosen=[];itemids=set();animids=set()
 for row in allocations:
  slug=row['slug']
  if slug not in settings:raise ValueError('Unknown weapon: '+slug)
  item=number(row['item_id']);anim=number(row['animation_id'])
  if not 1<=item<=65535 or not 400<=anim<2048:raise ValueError('Item or human equipment ID outside supported range')
  if item in itemids or anim in animids or any(p[0]['slug']==slug for p in chosen):raise ValueError('Duplicate weapon or destination ID')
  itemids.add(item);animids.add(anim);chosen.append((settings[slug],item,anim))
 if not chosen:raise ValueError('No allocated IDs supplied')
 destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
 for name in('weapons.scp','tiledata.csv','import-map.json'):
  if(destination/name).exists():raise ValueError('Output exists; choose a new output folder: '+name)
 scripts=['// Generated for the explicitly supplied free IDs. Verify allocations before importing.'];rows=[];mapping=[]
 for p,item,anim in chosen:
  o=p['settings'];symbol='i_wc_'+p['slug'].replace('-','_')
  lines=[f'[ITEMDEF 0{item:x}]',f'DEFNAME={symbol}',f'NAME={p["name"]}',f'TYPE={o["sphere_type"]}',f'LAYER={o["layer"]}',f'TWOHANDS={"Y"if o["layer"]==2 else"N"}',f'SKILL={o["skill"]}',f'DAM={o["damage_min"]},{o["damage_max"]}',f'SPEED={o["speed"]}',f'REQSTR={o["required_strength"]}',f'WEIGHT={o["weight"]}','CANUSE=can_u_human','CATEGORY=Custom weapons','SUBSECTION=Weapon collection',f'DESCRIPTION={p["name"]}']
  if o.get('ammo'):lines +=[f'TDATA3={o["ammo"]}',f'TDATA4={o["projectile"]}','RANGE=2,10']
  lines+=['','ON=@Create',f'HITPOINTS={o["durability"]}'];scripts.append('\n'.join(lines))
  # TileData quality stores the equipment layer. Keep the item as equippable weapon art.
  rows.append(dict(item_id=hex(item),name=p['name'][:20],animation=anim,quality=o['layer'],weight=o['weight'],height=0,flags=hex(o['tile_flags'])))
  mapping.append(dict(slug=p['slug'],item_id=item,animation_id=anim,male_gump=50000+anim,female_gump=60000+anim,files=p['files'],create_command='.add '+symbol))
 scripts.append('[EOF]');(destination/'weapons.scp').write_text('\n\n'.join(scripts)+'\n',encoding='cp1252')
 with(destination/'tiledata.csv').open('w',newline='')as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 (destination/'import-map.json').write_text(json.dumps(mapping,indent=2))
 return mapping
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit(__doc__)
 root=Path(__file__).resolve().parent
 manifest=json.loads((root/'manifest.json').read_text());allocations=json.loads(Path(sys.argv[1]).read_text());result=prepare(manifest,allocations,sys.argv[2]);print('Prepared',len(result),'weapons. No installed files were changed.')
