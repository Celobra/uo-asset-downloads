# Storm Cloud for Ultima Online

Two animated effects for Sphere X and ClassicUO: a small cosmetic cloud (72 by 128 pixels) and a large boss cloud (216 by 384 pixels). Each contains 24 frames and lasts 3.6 seconds, with lightning at about 0.9 and 2.1 seconds. Both use normal blending so the dark cloud stays visible.

## Import into a development copy

1. Back up your client assets and work in a separate development copy. Close programs using that copy.
2. Find 48 consecutive unused ITEM ART IDs. Check art, tile data, animation data, art.def mappings and server references. There is deliberately no default ID or production allocation in this package. This is animated item art, not a creature animation VD file.
3. Open PowerShell in this extracted folder. Run `powershell -ExecutionPolicy Bypass -File .\Prepare-Import.ps1 -BaseId YOUR_FREE_ID`, replacing YOUR_FREE_ID with your verified hexadecimal or decimal starting ID.
4. In UOFiddler configured for the development copy, use Mass Import with `Import/massimport.xml` for the artwork and tile data, then import `Import/animdata.json` in the animation-data editor. Save art, art index, tile data and animation data to the development copy. Consult your editor version's controls if labels differ.
5. The first ID is the small animation; starting ID plus 24 is the boss animation. Each has 24 frames, FrameInterval 3 and FrameStart 0. Only those two base IDs have the animated tile flag. All tiles have zero height.
6. Load `Import/storm_cloud.scp` in your Sphere custom script list. Test on an isolated server before deploying. Use the original client with the same art data as that server. No alternate client executable is required.

The preparation step writes only an Import subfolder. It refuses to overwrite an existing one. Regenerate it after moving the extracted package because the import XML contains locally generated absolute paths. Do not distribute that generated Import folder.

## Commands and boss integration

- `.storm_cloud`: small harmless cosmetic effect on the caller.
- `.storm_cloud_preview`: large harmless version at a fixed cast origin.
- `.storm_cloud_boss`: large damaging version at a fixed cast origin.
- Call `f_storm_cloud` from a boss attack script, or opt in with `TEVENTS=e_boss_storm_cloud` for a 25 percent cast attempt on incoming hits. No existing boss is modified automatically.

The boss attack has a 12-second cooldown. It deals 25 energy damage before mitigation at each of two strikes, within a circular radius of two tiles. A target can be hit once per strike. Online players and player-owned pets are eligible; other NPCs require `TAG.storm_cloud_target=1`. GMs, the caster, dead/invulnerable/stone targets, safe regions, allies and the caster's own pets are excluded. Set the same positive `TAG.storm_cloud_team` on allied actors. Set `TAG.storm_cloud_damage` on a boss to override damage; use the preview command for zero damage. Set `storm_cloud_damage` in the config to change the default.

The origin stays fixed when the boss moves. Terrain height and line of sight restrict hits. Caster deletion, death or map change cancels future damage at the next strike; already-sent visual effects may finish on the client. Temporary controllers are excluded from saves. Energy resistance requires Sphere's elemental combat configuration; this package does not change your server settings.

## Acceptance checks


