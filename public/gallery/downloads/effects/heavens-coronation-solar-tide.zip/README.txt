The Solar Tide
A white-hot pulse erupts beneath the crown and sweeps outward in a rolling ring of golden fire.
Duration: 3200 ms; placement: ground; blend: additive

HEAVEN'S CORONATION

Three separate painted item-art animations combine into one 5.4-second celestial entrance: The Celestial Seal, Wings of the Crown, and The Solar Tide.

Each animation has 16 frames and a nominal 3.2-second duration. Full-cast records use 64 relative frame offsets at the 50 ms nominal client tick, repeating each frame four times. Optional bloom-and-decay and decay records begin at offsets 4 and 12. Use additive blending for all three layers. Preview timing is nominal; live client scheduling may differ.

COMBINED SEQUENCE
All anchors share the player's ground location. Start the seal at 0 ms, wings/crown at 600 ms, and fire wave at 2200 ms. End the respective effects at 3200, 3800 and 5400 ms. Draw the seal on the floor and the apparition behind the actor; the fire wave has front/back occlusion around the actor. The HTML preview splits the wave at 16 pixels above the ground anchor. This composition is a visual specification, not an installed server ability. Packet placement, effect lifetimes, blend mode and native actor occlusion require in-game integration and testing.

This package supplies original art and portable import preparation. No art IDs are reserved, no gameplay statistics or server scripts are included, and no client or server files are changed. These are animated item-art effects, not creature/body animation records; a creature-animation .vd would be the wrong format. The complete ZIP and individual layer ZIPs are the distribution formats.

IMPORT PREPARATION
Extract a layer's ZIP before running Prepare-Import.ps1 with -BaseId and a verified-unused starting item-art ID, for example -BaseId 0x7000. That number is an example, not a reservation: inspect all 16 destination slots and references in your current client first. Each layer needs its own unused block of 16 slots; do not reuse the same block for different layers.

The helper creates an Import folder inside the extracted package. It includes UOFiddler massimport.xml, tiledata.csv, animdata.json and selected-range.txt. It checks native-frame hashes and generates references for the extracted location. Keep Import or rename it before generating different paths. Import item art and tile-data with a compatible UOFiddler mass-import workflow; import the AnimData JSON separately with compatible tooling. Back up the current destination data before any import. This helper prepares files only and does not perform an installation.

The full-cast effect starts at the chosen base ID. Bloom-and-decay starts at base + 4, and decay at base + 12. Only those three entries carry the Animated flag. AnimData can loop if an effect persists; the game integration must enforce the intended one-shot lifetime. The art has no damage, immunity, resurrection or stat changes attached.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
