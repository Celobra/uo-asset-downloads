The Hollow Seam
A hairline wound in the ground opens into a cold, lightless hollow, laced with crooked root-like thorns.
Duration: 3200 ms; placement: ground; blend: normal

THE UNMAKING

An original sinister Ultima Online spell spectacle in three layers: The Hollow Seam, The Unblinking Witness and The Grasping Night. A crooked ground fissure opens beneath a floating eye and thorn crown; hooked shadows rise and fold inward before withdrawing below the surface. This is visual art only, with no damage or gameplay changes.

Each layer has 16 frames and a nominal 3.2-second duration. The complete staged effect lasts 5.4 seconds. All three layers use NORMAL blending to preserve their black surfaces; do not use additive blending, which would erase the shadow material.

COMBINED STAGING
Place all layers at the same ground anchor. Start Hollow Seam at 0 ms, Unblinking Witness at 600 ms, and Grasping Night at 2200 ms. End each at 3200, 3800 and 5400 ms respectively. Draw the seam on the floor and the witness behind the player. The preview splits the reaching-shadow layer into back/front sections at 16 pixels above the ground anchor to surround the actor. Native client actor occlusion, packet placement and world heights require in-game integration and testing. This visual composition is not an installed ability or a wearable item.

No art IDs are allocated or reserved. Every layer needs 16 consecutive verified-unused item-art slots, in separate blocks. Inspect current client data and every reference before selecting destination IDs; back up that current data before import.

Extract a layer ZIP, then run Prepare-Import.ps1 with -BaseId and your chosen starting ID. For example, -BaseId 0x7000 illustrates the syntax only; this ID is not reserved and may already be occupied. The helper checks native frame hashes and creates Import/massimport.xml, tiledata.csv, animdata.json and selected-range.txt inside that extracted layer. It does not modify client or server files. Keep or rename any existing Import folder before regenerating paths or changing IDs.

Use a compatible UOFiddler mass-import workflow for item art and tile data, and import AnimData JSON separately with compatible tooling. Keep the 16 shared canvases and their anchors; do not crop individual animation frames to their changing silhouettes.

ANIMATION RECORDS
Full cast starts at the chosen base ID, bloom-and-decay at base+4, and decay at base+12. Only these three bases carry the Animated flag. Full cast contains 64 relative offsets, each of the 16 art frames held for four nominal 50 ms ticks; bloom-and-decay contains 48 ticks and decay 16 ticks. Live scheduling can differ. AnimData may repeat while an effect persists, so the eventual integration must enforce one-shot lifetime and cleanup. This package supplies no server script or combat behavior.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
