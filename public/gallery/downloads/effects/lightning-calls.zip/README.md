# Custom Lightning Calls

Custom blue-white lightning and crawling ground electricity for Sphere X and ClassicUO. Random strikes fill a radius of 5–7 tiles for 15 seconds. Default radius: 6 tiles. There are no clouds or red sparkles.

## In-game commands

- `.lightning_calls_preview` — harmless visual storm.
- `.lightning_calls` — damaging storm.
- `.lightning_calls_end` — stop early; the cooldown remains.

These commands require GM privilege level 4. For a player spell or boss ability, call `f_lc_start 1` on the caster from a trusted server handler, after your own mana, skill and eligibility checks. Call `f_lc_start 0` for cosmetic playback. No spellbook entry is added automatically.

The storm stays at its original cast location. Set the caster's `TAG.lightning_calls_radius` to 5, 6 or 7 to override the default. Cooldown is 20 seconds from cast start.

## Import into your own shard

1. Back up your client data and current Lightning Calls script. Use a development copy, with the client, server and asset editors closed.
2. Find 16 consecutive unused item-art IDs. Check existing art, TileData, AnimData, art.def and server references. No destination ID is assumed by this package.
3. Open PowerShell 7 in the extracted package folder and run `pwsh -File .\Prepare-Import.ps1 -BaseId YOUR_FREE_ID`, replacing `YOUR_FREE_ID` with the verified starting ID (decimal or 0x-prefixed hexadecimal).
4. In UOFiddler, import `Import/massimport.xml` into the development copy. Save art.mul, artidx.mul and tiledata.mul. Import `Import/animdata.json` through the AnimData editor and save animdata.mul as well.
5. Load `Import/lightning_calls.scp` through your Sphere script list. If you already use Lightning Calls, replace that script; do not load both versions. The generated script contains your selected art IDs.
6. Distribute the matching modified client files through your normal patch process. Restart the normal client and Sphere against the matching data. Test the harmless command before combat tests.

The preparation script only creates an `Import` subfolder and refuses to overwrite an existing one. Regenerate after moving the extracted package, because the import paths are generated locally. Share the original ZIP, not the generated Import folder.

This is animated item art plus AnimData and a server script. Creature/equipment `.vd` files use a different animation system and cannot install these spell effects.

## Artwork and timing

Twelve bolt frames use 112 × 202 canvases, anchored at (56, 180). Four separate ground frames use 112 × 50 canvases, anchored at (56, 28). Only transparent padding was removed from the approved artwork; its visible pixels were preserved.

The bolt uses a 14-step animation at nominal 50 ms per step (700 ms). The ground effect uses six steps (300 ms). Some frames repeat to approximate the artwork preview's variable cadence. Both use additive blend mode 2, zero hue and fixed coordinates. Ground animations appear at three successive positions along two outward branches, retaining their horizontal floor orientation.

Frames +0 and +12 are the two animated bases. Both have the animated tile flag, zero height and zero weight. The client additive blend adds light; the browser artwork study used Screen compositing, so the client can appear slightly brighter on light terrain.

## Gameplay

Up to two strikes per half-second volley. Each damaging strike deals 10 energy damage before normal mitigation, within one tile of its impact and inside the overall field. A victim can be hit at most once per second across overlapping storms. Ground electricity is cosmetic.

The caster, their pets, matching positive team tags, GMs, dead/invulnerable/stone characters and offline players are excluded. Safe regions, height differences and line of sight are checked. Other shard combat legality rules should be reviewed for your deployment. Configure defaults in the script's `lightning_calls_config` section. Team protection uses `TAG.lightning_calls_team`.

Death, logout, map change or moving more than 18 tiles from the cast origin stops the storm. Its invisible controller is marked NOSAVE and is removed at cooldown expiry. Already displayed client effects may finish their short remaining frames after manual cancellation. No permanent character stats are altered.
