THE UNWRITTEN KING

The circle was never meant to call him. It was the last thing keeping him out.

ARTWORK
The imported art really uses a 384x448 canvas. This is not a small sprite
enlarged only in the preview. Separate painted body parts move in a fixed
camera; the robe passes through a registered portal and its front stone rim.
There are 32 warning, 48 emergence, 64 presence and 48 retreat frames. The last
retreat frame is completely clear. The quiet seal is logical frame 0.

Each frame has TWO registered native layers, upper and lower, divided at
row 260. This preserves large detailed artwork while keeping every record
within the classic static-art 16-bit row-offset limit. Together they reproduce
the preview exactly; the layers have no overlapping opaque pixels. Both must
be displayed at the SAME location, on the SAME clock, with the SAME lifetime.
Never trim, resize or centre the layers separately.

This is an animated ITEM-ART manifestation, not a creature VD or wearable.
It does not include walking directions, a combat NPC, damage, loot or a
paperdoll. Those would be separate gameplay and creature-animation work.

PREPARING IMPORT FILES
1. Back up your client and work on an isolated copy. Find 387 consecutive
   unused item-art IDs, checking current art, tiledata, animdata, server
   definitions and existing custom mappings. No IDs are allocated by this pack.
2. Run Prepare-Import.ps1 with your verified decimal or hexadecimal BaseId.
   It verifies every native frame/icon hash, then creates an Import folder.
   Existing Import folders are refused to prevent accidental overwriting.
3. Use Import/massimport.xml with a compatible UOFiddler mass-import workflow.
   Merge Import/animdata.json through the animation-data editor. Eight records
   contain the four phase sequences for both layers. Review Import/tiledata.csv
   and preserve unrelated current records; do not overwrite a newer client
   from a stale baseline. Save and distribute matching data through your normal
   process. The helper does not install anything or modify client/server files.

RELATIVE PHASE BASES
                    Upper    Lower    Frames     Duration
Warning                 1      194        32      1.6 s
Emergence              33      226        48      2.4 s
Presence               81      274        64      3.2 s
Retreat               145      338        48      2.4 s
Quiet seal              0      193         1      static
Inventory             386        -         1      static

These durations use location-effect timing: nominal 50 ms per frame.
Ordinary animated world statics run on a different timing path and should not
be substituted for the location-effect sequence. Use normal blend 0. Additive
blending would lose the dark face, robe and portal. Light is painted into the
art; no dynamic lighting change is included.

OPTIONAL COSMETIC SPHERE X SEQUENCE
The helper generates Import/unwritten_king.scp with the selected IDs. The
unresolved Sphere-Template.txt is reference text, not an install-ready script.
Review the generated file, then load it through your normal custom-script
workflow only after the matching client artwork is available.

The staff command .unwritten_king plays the entire manifestation at the living
caster's current position, reveals the caster so the effect can broadcast, and
keeps that origin fixed if the caster moves. It sends both layers together for
each phase. An invisible, non-saving temporary controller advances the phases
and removes itself when finished. It blocks overlapping casts by the same
caster. Different casters may run independent sequences.

.unwritten_king_cancel prevents subsequent phases and clears the controller.
Caster death, deletion or map change also stops future phases. Already-sent
client effects finish their current lifetime (up to 3.2 seconds); cancellation
does not instantly erase them. Moving on the same map leaves the origin fixed.
Commands are declared at staff privilege level 4. No NPC, damage, loot, item
reward, ownership or quest behaviour is created by this script.

VALIDATION / REMAINING CHECKS
See VALIDATION.txt for decoder, import, preview and isolated Sphere results.
The two-layer reconstruction, loop seams, full cleanup and native record-size
limits were checked. Native contact sheets were visually inspected.
Actual browser rendering and live client acceptance remain untested: verify
ordinary-player visibility, layer start synchronization, ground alignment,
terrain, occlusion, player scale, overlapping effects, latency and cleanup.
The approximate player-height guide in the preview is not an in-game capture.

The full GIF samples the ritual at 10 fps for a smaller file; the interactive
preview and native effect use all frames at 20 fps. Presence.gif uses all 64
presence frames. GIF colours are palette-reduced; native PNGs are authoritative.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
