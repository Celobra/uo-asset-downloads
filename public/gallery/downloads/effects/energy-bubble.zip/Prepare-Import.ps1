param(
    [ValidatePattern('^(0[xX][0-9a-fA-F]+|[0-9]+)$')]
    [string]$BaseId = '0x5000'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Generates import documents inside the extracted package. Never opens client or server files.
$effectRoot = $PSScriptRoot
$manifest = Get-Content -LiteralPath (Join-Path $effectRoot 'effect.json') -Raw | ConvertFrom-Json
if ($BaseId.StartsWith('0x', [StringComparison]::OrdinalIgnoreCase)) {
    $firstId = [Convert]::ToInt32($BaseId.Substring(2),16)
} else {
    $firstId = [Convert]::ToInt32($BaseId,10)
}
if ($firstId -lt 0 -or $firstId -gt 65504) { throw 'Choose a base ID from 0 through 0xFFE0, with 32 free consecutive item-art slots.' }
if ($manifest.frame_count -ne 32 -or $manifest.timeline.Count -ne 50 -or $manifest.step_ms -ne 100) {
    throw 'Unexpected effect manifest.'
}
foreach ($frame in $manifest.frames) {
    if ($frame.file -notmatch '^frames/bubble_\d{2}\.png$') { throw 'Unexpected frame path.' }
    $framePath = Join-Path $effectRoot $frame.file
    if ((Get-FileHash -LiteralPath $framePath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $frame.sha256) {
        throw ('Frame checksum failed: '+$frame.file)
    }
}
$output = Join-Path $effectRoot 'Import'
if (Test-Path -LiteralPath $output) {
    throw 'Import already exists. Keep or rename it before preparing a different slot range or regenerating paths.'
}
New-Item -ItemType Directory -Path $output | Out-Null
$utf8 = New-Object System.Text.UTF8Encoding($false)

$csv = New-Object 'System.Collections.Generic.List[string]'
$csv.Add('# Item data: ID;Name;Weight;Quality;Animation;Height;Hue;Quantity;StackingOffset;MiscData;Unk2;Unk3;64 flag columns in bit order')
$xml = New-Object System.Xml.XmlDocument
$declaration = $xml.CreateXmlDeclaration('1.0','utf-8',$null)
[void]$xml.AppendChild($declaration)
$mass = $xml.CreateElement('MassImport')
[void]$xml.AppendChild($mass)
for ($i=0; $i -lt 32; $i++) {
    $id = $firstId+$i
    $fields = @([string]$id, ('energy bubble {0:00}' -f $i)) + (@('0')*10)
    $flags = @('0')*64
    if ($i -eq 0) { $flags[24] = '1' }
    $csv.Add((($fields+$flags) -join ';'))
    $node = $xml.CreateElement('item')
    $node.SetAttribute('index',[string]$id)
    $node.SetAttribute('file',(Join-Path $effectRoot ('frames\bubble_{0:00}.png' -f $i)))
    $node.SetAttribute('remove','False')
    [void]$mass.AppendChild($node)
    $node = $xml.CreateElement('tiledataitem')
    $node.SetAttribute('index',[string]$id)
    $node.SetAttribute('file',(Join-Path $output 'tiledata.csv'))
    $node.SetAttribute('remove','False')
    [void]$mass.AppendChild($node)
}
[IO.File]::WriteAllLines((Join-Path $output 'tiledata.csv'),$csv,$utf8)
$xml.Save((Join-Path $output 'massimport.xml'))

$frames = @($manifest.timeline | ForEach-Object {[int]$_}) + (@(0)*14)
$animation = [ordered]@{Version=1;Data=[ordered]@{}}
$animation.Data[[string]$firstId] = [ordered]@{
    FrameData=$frames;Unknown=0;FrameCount=50;FrameInterval=2;FrameStart=0
}
[IO.File]::WriteAllText((Join-Path $output 'animdata.json'),($animation | ConvertTo-Json -Depth 8),$utf8)
$template = Get-Content -LiteralPath (Join-Path $effectRoot 'energy_bubble.scp.template') -Raw
$script = $template.Replace('__BASE_HEX__',('0{0:x4}' -f $firstId))
[IO.File]::WriteAllText((Join-Path $output 'energy_bubble.scp'),$script,$utf8)
[IO.File]::WriteAllText((Join-Path $output 'selected-range.txt'),('Item-art IDs: 0x{0:X4} through 0x{1:X4}. Check these slots and script references before importing.' -f $firstId,($firstId+31)),$utf8)
Write-Output ('Prepared 32 frames, 32 tile-data records and one five-second animation at 0x{0:X4}.' -f $firstId)
Write-Output ('Import files: '+$output)
Write-Output 'No client or server files have been changed. Follow README.md to import into a development copy.'
