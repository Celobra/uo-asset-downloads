# Portable energy bubble

A blue-white cosmetic bubble grows around a character, shimmers, then dissolves over five seconds. This package contains only the custom effect and its setup files. It contains no accounts, world saves, original client files, personal paths, server addresses, or credentials.

## Why this is a ZIP instead of a creature .vd

UOFiddler's animation `.vd` format stores creature/equipment body actions for `anim.mul`. This bubble is an animated item-art effect using `art.mul` or its UOP equivalent, `tiledata.mul`, and `animdata.mul`. Its server command also controls duration and blending. Importing a body `.vd` would not install this effect.

The portable equivalent is this ZIP: 32 PNG frames, one timeline, a UOFiddler MassImport preparation script, and a Sphere command. Nothing needs to be regenerated with AI.

## Requirements

- A development copy of an Ultima Online 2D client data set and a compatible ClassicUO client.
- UOFiddler with the MassImport plugin and AnimData JSON import. The formats were checked against the upstream UOFiddler implementation; older releases may not have these controls.
- Sphere X for the supplied command. Other emulators need an equivalent fixed effect command, duration, and additive blend mode.
- Windows PowerShell for the included preparation script. It only writes import documents in the extracted package.
- 32 consecutive unused item-art IDs. The suggested range is `0x5000` through `0x501F`, but it is not guaranteed free on a different installation.

## Set up on another installation

1. Close the client, server, and other asset editors. Make a development copy of the client data and back up the server scripts. Configure UOFiddler to read that copy and save into a separate output folder.
2. Extract this ZIP. Keep the extracted folder in place until importing is complete.
3. Check the proposed item-art range in UOFiddler's Items, TileData, and AnimData views. Also check the shard's scripts and art mappings for references. Blank-looking art alone does not prove an ID is unused. Reserve 32 consecutive free IDs supported by that client.
4. Open PowerShell in the extracted folder and run:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File .\Prepare-Import.ps1 -BaseId 0x5000
   ```

   Replace `0x5000` with the first ID you reserved. The same value is applied to the frames, tile data, animation, and Sphere definition. The execution-policy setting applies only to this PowerShell process. If Windows blocks a downloaded script, inspect it and use `Unblock-File .\Prepare-Import.ps1` before running it. It does not require administrator rights for a normally writable extracted folder.

5. The script creates an `Import` folder. In UOFiddler's MassImport plugin, load `Import\massimport.xml`. Expect **64 valid entries**: 32 item-art imports plus 32 tile-data imports. Resolve any invalid entries and recheck the destination IDs before importing. The plugin can replace occupied art, so this check matters.
6. Run the import. Save the changed art and tile data to the configured output folder. Preserve the PNG canvases at 144 by 144 pixels; do not crop, scale, or move the frames.
7. In UOFiddler's AnimData tab, import `Import\animdata.json`. Leave **Erase existing data unchecked**. Choose the option that keeps existing entries on conflict. Expect **one imported entry**; if zero are imported, inspect the existing record rather than overwriting it. Save `animdata.mul` to the output folder.
8. Inspect the first reserved ID in TileData: the Animation flag should be on, height zero, and other flags off. Preview the first ID in AnimData: FrameCount 50, FrameInterval 2, FrameStart 0. The frame-offset sequence is also listed in `effect.json`.
9. Close UOFiddler. Copy its changed output into the development client data folder. For a MUL art installation this is `art.mul`, `artidx.mul`, `tiledata.mul`, and `animdata.mul`. For a UOP art installation save and deploy the art UOP used by that client, plus tile and animation data. Make sure the client actually loads the edited art container; some clients prefer UOP when both exist. Do not replace `anim.mul` or `anim.idx` for this effect.
10. Copy `Import\energy_bubble.scp` into a custom script folder loaded by Sphere's `spheretables.scp`. Register that folder once if necessary. Check that `energy_bubble`, `f_energy_bubble`, and `i_fx_energy_bubble` are not already defined elsewhere.
11. Start the development server and its normal ClassicUO client. Log in as a GM and type `.energy_bubble`.
12. Check the bubble while standing, moving, and mounted. It should follow the player and finish after about five seconds. Confirm visibility, centering, and behavior near walls before distributing the patched client assets to players. Client forks may handle effect speed, blend mode, or layering differently.

The preparation output uses absolute paths for the recipient's extracted folder because MassImport resolves relative paths against its working directory. Those paths are generated on the recipient's computer and are not included in this ZIP. If you move the extracted folder or select a different base ID, rename the existing `Import` folder and rerun preparation.

## What the effect changes

- 32 custom item-art frames at the chosen range.
- 32 corresponding tile-data records, with the first marked animated.
- One animation-data entry: eight growth steps, 34 shimmer steps, eight dissolve steps, each 100 milliseconds.
- One Sphere script sending a fixed effect with duration 100 and render mode 2. In the tested ClassicUO implementation these mean five seconds and additive blending.

It adds no protection, persistent world items, saved character tags, or creature-body animations. The art is a 2D translucent overlay; separate front and rear layers are not implemented. Every player viewing it needs the matching art, tile-data, and animation-data changes.

For rollback, close the programs and restore the asset backup together with removing this script. If additional asset work has happened since the backup, merge a removal in development instead of restoring whole files over newer work.

## Format references

- [UOFiddler body VD exporter](https://github.com/polserver/UOFiddler/blob/master/Ultima/AnimationEdit.cs)
- [UOFiddler AnimData JSON format](https://github.com/polserver/UOFiddler/blob/master/UoFiddler.Controls/Classes/ExportedAnimData.cs)
- [UOFiddler MassImport XML reader](https://github.com/polserver/UOFiddler/blob/master/UoFiddler.Plugin.MassImport/Forms/MassImportForm.cs)

The supplied artwork was generated and then converted for UO's native art format. Importing, configuring, and using this package requires no AI service.
