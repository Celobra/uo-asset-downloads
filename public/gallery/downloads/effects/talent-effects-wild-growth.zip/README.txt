Wild Growth

Before importing: close the client and asset editors, check access to every file to be saved, and back up the current development data. Use verified unused destination IDs. Keep MUL/IDX pairs together, preserve other entries and use the data bank/container the client actually reads. These downloads do not contain UO client data, accounts or world saves. Install matching client art for every player. Check the result in game before using it on a live shard.

Choose 16 consecutive unused item-art IDs. Run powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File .\Prepare-Import.ps1 -BaseId YOUR_FIRST_ID (decimal or 0x). Review Import/massimport.xml in UOFiddler MassImport, save art and TileData; import Import/animdata.json with erase-existing disabled and preserve existing entries on conflicts. Deploy matching saved files to the development client. Manifest animations, phase bases, timing and blend describe how to play the art. Preserve PNG canvases and anchors.

This is visual effect art with import preparation. A server spell/buff/damage script is not included. Movement, targeting, duration and any gameplay rules require integration on your server. The gallery scene illustrates placement rather than supplying that server behaviour.
