param([Parameter(Mandatory=$true)][ValidatePattern('^(0[xX][0-9a-fA-F]+|[0-9]+)$')][string]$BaseId)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$packageRoot=$PSScriptRoot
$effect=Get-Content -LiteralPath (Join-Path $packageRoot 'manifest.json') -Raw | ConvertFrom-Json
$firstId=if($BaseId.StartsWith('0x',[StringComparison]::OrdinalIgnoreCase)){[Convert]::ToInt32($BaseId.Substring(2),16)}else{[Convert]::ToInt32($BaseId,10)}
if($firstId -lt 1 -or $firstId -gt 65520){throw 'Choose 16 consecutive unused item-art IDs starting at 1 through 0xFFF0.'}
if($effect.frames.Count -ne 16 -or $effect.animations.Count -lt 1){throw 'Unexpected animation manifest'}
foreach($f in $effect.frames){
 if($f.file -notmatch '^frames/effect_\d{2}\.png$'){throw 'Unexpected frame path'}
 if((Get-FileHash -LiteralPath (Join-Path $packageRoot $f.file)).Hash.ToLowerInvariant() -ne $f.sha256){throw ('Damaged frame: '+$f.file)}
}
$output=Join-Path $packageRoot 'Import'
if(Test-Path -LiteralPath $output){throw 'Import already exists. Keep or rename it before changing IDs or regenerating paths.'}
New-Item -ItemType Directory -Path $output | Out-Null
$utf8=[Text.UTF8Encoding]::new($false)
$csv=[Collections.Generic.List[string]]::new()
$csv.Add('# ID;Name;Weight;Quality;Animation;Height;Hue;Quantity;StackingOffset;MiscData;Unk2;Unk3;64 flags in bit order')
$xml=[Xml.XmlDocument]::new();[void]$xml.AppendChild($xml.CreateXmlDeclaration('1.0','utf-8',$null));$mass=$xml.CreateElement('MassImport');[void]$xml.AppendChild($mass)
for($i=0;$i -lt 16;$i++){
 $id=$firstId+$i;$fields=@([string]$id,('aura {0:00}' -f $i))+(@('0')*10);$flags=@('0')*64
 if($i -in @($effect.animations | ForEach-Object { [int]$_.offset })){$flags[24]='1'}
 $csv.Add((($fields+$flags) -join ';'))
 foreach($kind in 'item','tiledataitem'){
  $node=$xml.CreateElement($kind);$node.SetAttribute('index',[string]$id)
  $file=if($kind -eq 'item'){Join-Path $packageRoot $effect.frames[$i].file}else{Join-Path $output 'tiledata.csv'}
  $node.SetAttribute('file',$file);$node.SetAttribute('remove','False');[void]$mass.AppendChild($node)
 }
}
[IO.File]::WriteAllLines((Join-Path $output 'tiledata.csv'),$csv,$utf8);$xml.Save((Join-Path $output 'massimport.xml'))
$animations=[ordered]@{Version=1;Data=[ordered]@{}}
foreach($anim in $effect.animations){
 $timeline=@($anim.timeline | ForEach-Object {[int]$_})
 $animations.Data[[string]($firstId+$anim.offset)]=[ordered]@{FrameData=($timeline+(@(0)*(64-$timeline.Count)));Unknown=0;FrameCount=$timeline.Count;FrameInterval=[int]$anim.interval;FrameStart=0}
}
[IO.File]::WriteAllText((Join-Path $output 'animdata.json'),($animations | ConvertTo-Json -Depth 9),$utf8)
$note='Item-art range 0x{0:X4} through 0x{1:X4}. Blend {2}. Verify every ID and reference is free before importing.' -f $firstId,($firstId+15),$effect.blend
foreach($anim in $effect.animations){$note += [Environment]::NewLine+('{0}: base 0x{1:X4}, nominal duration {2} ms' -f $anim.phase,($firstId+$anim.offset),$anim.durationMs)}
[IO.File]::WriteAllText((Join-Path $output 'selected-range.txt'),$note,$utf8)
Write-Output ('Prepared 16 item-art frames, 16 tile-data rows and {0} AnimData sequences.' -f $effect.animations.Count)
Write-Output ('Output: '+$output)
Write-Output 'This only prepares import files inside the extracted package. No client or server was changed.'
