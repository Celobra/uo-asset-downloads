param([Parameter(Mandatory=$true)][ValidatePattern('^(0[xX][0-9a-fA-F]+|[0-9]+)$')][string]$BaseId)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$packageRoot=$PSScriptRoot
$effect=Get-Content -LiteralPath (Join-Path $packageRoot 'effect.json') -Raw | ConvertFrom-Json
$firstId=if($BaseId.StartsWith('0x',[StringComparison]::OrdinalIgnoreCase)) {[Convert]::ToInt32($BaseId.Substring(2),16)} else {[Convert]::ToInt32($BaseId,10)}
if($firstId -lt 0 -or $firstId -gt 65488) {throw 'Choose 48 consecutive free item-art IDs starting at 0 through 0xFFD0.'}
if($effect.frame_count -ne 48 -or $effect.frames.Count -ne 48 -or $effect.animations.Count -ne 0) {throw 'Unexpected effect manifest'}
foreach($frame in $effect.frames) {
    if($frame.file -notmatch '^frames/(blue|gold|violet)_\d{2}\.png$') {throw 'Unexpected frame path'}
    if((Get-FileHash -LiteralPath (Join-Path $packageRoot $frame.file)).Hash.ToLowerInvariant() -ne $frame.sha256) {throw ('Damaged frame: '+$frame.file)}
}
$output=Join-Path $packageRoot 'Import'
if(Test-Path -LiteralPath $output) {throw 'Import already exists. Keep or rename it before regenerating paths or changing IDs.'}
New-Item -ItemType Directory -Path $output | Out-Null
$utf8=New-Object Text.UTF8Encoding($false)
$csv=New-Object 'System.Collections.Generic.List[string]'
$csv.Add('# ID;Name;Weight;Quality;Animation;Height;Hue;Quantity;StackingOffset;MiscData;Unk2;Unk3;64 flags in bit order')
$xml=New-Object Xml.XmlDocument
[void]$xml.AppendChild($xml.CreateXmlDeclaration('1.0','utf-8',$null))
$mass=$xml.CreateElement('MassImport')
[void]$xml.AppendChild($mass)
for($i=0;$i -lt 48;$i++) {
    $id=$firstId+$i
    $fields=@([string]$id,('particle shield {0:00}' -f $i))+(@('0')*10)
    $flags=@('0')*64
    # Static frames; timed server playback requires no animated tile flags.
    $csv.Add((($fields+$flags) -join ';'))
    foreach($kind in 'item','tiledataitem') {
        $node=$xml.CreateElement($kind)
        $node.SetAttribute('index',[string]$id)
        $file=if($kind -eq 'item') {Join-Path $packageRoot $effect.frames[$i].file} else {Join-Path $output 'tiledata.csv'}
        $node.SetAttribute('file',$file)
        $node.SetAttribute('remove','False')
        [void]$mass.AppendChild($node)
    }
}
[IO.File]::WriteAllLines((Join-Path $output 'tiledata.csv'),$csv,$utf8)
$xml.Save((Join-Path $output 'massimport.xml'))
$script=Get-Content -LiteralPath (Join-Path $packageRoot 'particle_shield.scp.template') -Raw
$script=$script.Replace('__BLUE_HEX__',('0{0:x4}' -f $firstId)).Replace('__GOLD_HEX__',('0{0:x4}' -f ($firstId+16))).Replace('__VIOLET_HEX__',('0{0:x4}' -f ($firstId+32)))
[IO.File]::WriteAllText((Join-Path $output 'particle_shield.scp'),$script,$utf8)
[IO.File]::WriteAllText((Join-Path $output 'selected-range.txt'),('Item-art range 0x{0:X4} through 0x{1:X4}. Verify all IDs and references are free before importing.' -f $firstId,($firstId+47)),$utf8)
Write-Output ('Prepared 48 frames, 48 tile-data rows with server-driven playback at 0x{0:X4}.' -f $firstId)
Write-Output ('Import folder: '+$output)
Write-Output 'Preparation changed only this extracted package. Follow README.md to import into a development copy.'
