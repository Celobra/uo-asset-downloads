# Particle Shields for Sphere X / ClassicUO

Three protective abilities, each with its own particle artwork and colour. All begin with a two-second expansion from the character into a hollow particle sphere. Protection starts when formation ends, not immediately on cast.

| Command | Protection after formation | Appearance |
|---|---|---|
| `.particle_shield_blue` | 30% less incoming damage for 8 seconds | Calm blue orbiting motes |
| `.particle_shield_gold` | Absorbs a total of 100 damage; expires after 10 seconds if unspent | Dense golden sparks; flashes when struck |
| `.particle_shield_violet` | Blocks ordinary damage for 3 seconds | Violet crescent trails |

One shield at a time. All share a 20-second cooldown measured from cast start. `.particle_shield_end` cancels active protection and starts its short fade, without resetting cooldown. Commands are GM-level test entry points. For a normal player spell, call `f_ps_start 1`, `f_ps_start 2` or `f_ps_start 3` on the player from a trusted server spell/ability handler after your own skill, mana and eligibility checks. This package adds no spellbook entry or mana cost automatically.

## Import

1. Back up client data and use a development copy. Close programs using that copy.
2. Find 48 consecutive unused item-art IDs. Check artwork, tile data, animation references, art.def and server references. No default ID is supplied.
3. Open PowerShell in this extracted folder and run `powershell -ExecutionPolicy Bypass -File .\Prepare-Import.ps1 -BaseId YOUR_FREE_ID`, replacing YOUR_FREE_ID with the verified starting ID.
4. In UOFiddler, import the generated `Import/massimport.xml` into the development copy. It contains 48 art entries and 48 zero-height tile-data entries. Save art.mul, artidx.mul and tiledata.mul. No AnimData import is needed: all 48 frames are deliberately static, and the server selects frames at timed intervals.
5. Load `Import/particle_shield.scp` from your custom script folder through Sphere's script list. Start the normal client against the matching data and test the three commands.

Blue uses starting ID through +15, gold +16 through +31 and violet +32 through +47. The preparation script writes only an Import subfolder and refuses to overwrite an existing one. Regenerate it after moving the package because import paths are generated for your machine. Distribute the original ZIP, not the locally generated Import folder.

This is an animated item-art effect package, not a creature/body animation VD. A body-animation VD is not a replacement for these art records and the protection script.

## Damage rules and configuration

Reduction and absorption apply after native armour/resistance mitigation at the character GetHit trigger. Blue rounds remaining damage upward, so a one-point hit remains one point. Gold's reserve decreases by prevented damage; overflow damages the wearer immediately. Violet cancels ordinary physical, fire, cold, poison and energy damage delivered through that trigger. Administrator/god damage intentionally bypasses every shield. Direct scripts that edit HITS, kill a character, or bypass GetHit are not intercepted. Status effects and prior side effects such as spell debuffs are not blanket-cancelled.

The config section provides reduction, capacity, active durations and cooldown. Durations there use server tenths of a second. Do not shorten the shared cooldown below formation plus your longest active duration and fade. The defaults require no server combat configuration change. Other custom GetHit handlers may modify or stop the same damage event; review their ordering and test combinations before live use.

The server sends a short attached effect every 100ms, keeping the particles with the wearer while moving. Formation uses four poses over two seconds, then eight orbit poses repeat; four fade poses take 0.8 seconds. Rendering is additive and uses premultiplied RGB555 art. No player-body, equipment layer or mount animation is replaced. Expect ten effect updates per second per active shield; test latency and concurrent player load.

Protection ends on expiry, manual cancellation, death, logout or map change. A small invisible NOSAVE controller remains until cooldown ends; deletion of the wearer removes it. A stale saved event from a server restart is removed at login or on the next damage event. Active shields and their cooldown controllers do not survive a server restart. The script never sets the invulnerability flag or modifies permanent resistance stats.
