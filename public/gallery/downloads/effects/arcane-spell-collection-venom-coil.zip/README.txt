Venom Coil
A thin sickly-green spiral climbs the target, gathers into poison droplets and disperses.
Duration: 2000 ms; placement: ground; blend: additive

ARCANE SPELL COLLECTION — ORIGINAL UO EFFECT ART

Eight original spell animations: Frost Bloom, Runic Shackles, Void Collapse,
Venom Coil, Gale Blade, Phoenix Rebirth, Resurrection and Meteor Swarm.
These are visual assets. No damage, crowd control, poison, resurrection,
death prevention or other server gameplay is implemented.

SPELL TIMING AND MATERIALS
Frost Bloom: 2.0 seconds; sharp blue-white ice grows and fractures. Blend 2.
Runic Shackles: 2.4 seconds; opaque iron chains rise, bind and snap. Blend 0.
Void Collapse: 1.6 seconds; dark violet vortex contracts and releases ash.
  Blend 0 is required to preserve the dark centre.
Venom Coil: 2.0 seconds; thin green strands rise and turn to droplets. Blend 2.
Gale Blade: 1.6 seconds; silver wind and small leaves sweep around the caster.
  Blend 0 keeps dust and leaf shading.
Phoenix Rebirth: 2.0 seconds; ember streams open into fiery wings. Blend 2.
Resurrection: 2.4 seconds; pearl-white light rises and gathers at the heart,
  then releases a gentle gold pulse. Blend 2. This is separate from Phoenix.
Meteor Swarm: one 1.6-second meteor fall/impact sequence, reused at seven
  scattered positions in the preview. Blend 0 preserves shaded rock cores.
  Rocks fall during frames 0-7, hit at frame 8, burst through 11 and fade
  through 15. Preview starts occur at 0, 300, 650, 900, 1300, 1700 and 2100 ms;
  the last effect ends at 3700 ms. The pattern is a repeatable visual example,
  not a tile-radius definition, random server scheduler or damage script.

NATIVE IMPORT
These use animated item art. Creature/equipment VD files are a different
format; do not rename this ZIP to VD. Each spell needs sixteen consecutive
free item-art IDs. No production IDs are assigned or reserved.

1. Back up a development client copy and close programs using its files.
2. Choose sixteen consecutive unused IDs per spell. Check current art,
   tile data, AnimData, art.def and server references; avoid overlapping ranges.
   The included helper does not determine or certify that IDs are free.
3. Extract one individual ZIP. Open PowerShell in that folder and run:
   ./Prepare-Import.ps1 -BaseId YOUR_FREE_DECIMAL_OR_0xHEX_ID
   Replace the placeholder with your verified free base ID. The helper checks
   native frame hashes and creates Import inside that extracted folder only.
   It refuses to overwrite an existing Import directory. Retain or rename the
   old directory before regenerating. No installed client files are changed.
4. Import Import/massimport.xml with UOFiddler MassImport, then import
   Import/animdata.json through AnimData JSON import. Save to the development
   client copy and inspect playback. Regenerate Import if the extraction moves.
5. Only the base tile is Animated; all sixteen tiles have zero height and
   weight. Manifest animation offsets are relative to the selected free base.

PLACEMENT AND GAMEPLAY INTEGRATION
Ground anchor and frame focus are (48,106). Generated source cells share one
fixed anchor; do not individually centre cropped frames, which causes jitter.
AnimData uses nominal 50 ms ticks. Repeated frame offsets produce the exact
durations listed above. The preview reads the same timelines and repeats a
cast after a one-second clear interval for inspection only.

Each record is a complete cast. Server/client integration must start it at
frame zero and stop at its lifetime; AnimData alone is not a guaranteed
one-shot playback mechanism. Shackles show a fixed visual bind and release;
coordinate real root duration and release with authoritative combat logic.
Phoenix and Resurrection are cosmetic sequences until connected to validated
death-prevention or resurrection events. The local preview's fading player
illustrates revival only, not actual death, corpse movement or resurrection.

Meteor Swarm should schedule separate location effects from a visible caster
at validated ground positions. Preserve each instance's start phase. Apply any
damage at that instance's frame-8 impact, 800 ms after it begins, rather than
at the initial cast. Radius, impact count, damage, eligible targets, terrain,
teams, attribution and cancellation must be defined by your shard. Avoid
reusing one target position for all strikes unless that is intentional.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
