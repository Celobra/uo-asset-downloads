Skill gain
A tiny silver-blue quill draws one short stroke and disappears.
Duration: 800 ms; placement: overhead; blend: additive

PLAYER NOTIFICATIONS — ORIGINAL UO ITEM-ART ANIMATIONS

Eight brief effects for everyday events and milestones. Skill gain and stat
increase are deliberately subtle; mastery and level-up are more prominent.
Quest completion, discovery, exceptional crafting and rewards use small
recognisable symbols. Level-up is a possible custom shard event, not a claim
that the original UO skill system has character levels.

EFFECTS AND NOMINAL TIMING
Skill gain: silver-blue quill, overhead, 800 ms, additive blend 2.
Stat increase: three amber motes, shoulder, 800 ms, additive blend 2.
Skill mastery: antique-gold laurel, overhead, 1600 ms, additive blend 2.
Level up: boot ring and rising gold ribbons, ground, 1600 ms, additive blend 2.
Quest complete: parchment and wax seal, overhead, 1200 ms, normal blend 0.
New discovery: silver compass, overhead, 1000 ms, additive blend 2.
Exceptional craft: hammer and anvil, overhead, 1200 ms, normal blend 0.
Reward received: a single flipping brass coin, overhead, 1000 ms, normal blend 0.

NATIVE IMPORT
These are animated item-art effects. Creature/equipment VD files are a
different format; renaming this package to VD would not make it compatible.
No production art IDs are assigned, and the included helper does not edit
any client or server files.

1. Back up a development copy and close programs using its client files.
2. Choose 16 consecutive unused item-art IDs per effect. Check current art,
   tile data, AnimData, art.def and server references. Do not overlap ranges.
   The helper does not determine whether your selected IDs are unused.
3. Extract an individual ZIP. In PowerShell in its folder, run:
   ./Prepare-Import.ps1 -BaseId YOUR_FREE_DECIMAL_OR_0xHEX_ID
   Replace the placeholder with your verified free starting ID. The helper
   checks native frame hashes and makes an Import directory. It refuses to
   replace an existing Import directory; keep or rename that before retrying.
4. Import Import/massimport.xml using UOFiddler MassImport, then import
   Import/animdata.json using AnimData JSON import. Save to your development
   copy and inspect the result. Regenerate Import if its extracted path moves.
5. Only the base tile is Animated. All tiles have zero height and weight.
   Each manifest contains one relative AnimData sequence starting at offset 0.

PLACEMENT AND INTEGRATION
The native canvas ground anchor is (48,106). Frames for overhead/shoulder
symbols use focus (48,75); level-up uses focus (48,106). A focus coordinate
is an art-registration point, not a server world-Z value. Convert placement
appropriately in the actual client/server effect path and verify it in game.
The local demonstration uses one standing player and illustrative placement.

AnimData uses nominal 50 ms ticks, including repeated offsets to hold frames.
The preview reads that exact timeline. Server integration must start at frame
zero, limit lifetime to one complete sequence and remove the effect at its end;
AnimData alone does not guarantee one-shot playback on every client path.

Trigger only after the authoritative event succeeds. Routine gains should
be visible to the recipient and batched or throttled during rapid gains so
they do not stack into visual noise. Give milestones priority over routine
notifications. Discovery should fire once for a newly discovered location;
craft and reward notices should follow confirmed results. These are suggested
integration behaviours, not implemented hooks or rewards.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
