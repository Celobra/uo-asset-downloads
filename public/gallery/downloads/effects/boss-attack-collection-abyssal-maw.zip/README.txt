Leviathan's Last Bite
A gigantic maw and writhing black tendrils swallow the space around one target, then strike again.
Duration: 3000 ms; placement: ground; blend: normal

APOCALYPSE — BOSS ATTACK ART COLLECTION

Six extreme UO boss effects: Worldbreaker Inferno, Cathedral of Ruin,
Ossuary Apocalypse, The Final Sentence, Leviathan's Last Bite and
Heavenfall Judgment. Original painted art at 384x384 pixels per frame.
The first three are area demonstrations; the last three focus on one target.

These are animated item-art effects. Use the supplied ZIP import workflow;
creature/equipment VD is a different format. No art IDs are assigned or reserved.
The package does not install assets or provide server damage/targeting logic.

FRAME TIMING
Frames 0-3: warning, 300 ms each, 1.2 seconds total.
Frames 4-11: attack, 150 ms each, 1.2 seconds total.
Frames 12-15: decay, 150 ms each, 0.6 seconds total.
The complete one-shot sequence lasts 3.0 seconds at nominal 50 ms ticks.
The first visible attack is frame 4 at 1200 ms after each full cast begins.

PREVIEW CHOREOGRAPHY
Area attacks use a central full cast at 0 ms plus six surrounding full casts
at 180, 360, 540, 720, 900 and 1080 ms. Each position gets its own 1200 ms
warning. A final attack-and-decay sequence begins at the centre at 2600 ms.
There are seven distinct positions and eight total casts; cleanup is at 4400 ms.

The Final Sentence: a full cast at 0 ms, attack-only restarts at 2000 and
2800 ms, with cleanup at 4600 ms. All three converge on the same point.
Leviathan's Last Bite: a full cast at 0 ms and attack-only restart at 2400 ms;
cleanup at 4200 ms. Emergence and the later jaw snap are separate visual cues.
Heavenfall Judgment: a full cast at 0 ms and attack-only restarts at 1500,
1900, 2300 and 2700 ms; cleanup at 4500 ms. Five lightning strikes overlap
on the same fixed target. Later strikes deliberately reuse the announced
attack window; they do not play another full warning sequence.

The preview repeats after one clear second. Positions are illustrative screen
coordinates, not world tiles, a selected radius, collision or implemented damage.
Use the full-cast record for standalone effects or the optional phase records
to build a similar sequence in authoritative boss logic. Importing AnimData
alone does not create the multi-instance choreography.

IMPORT
1. Back up a development client and close applications using its data files.
2. Verify 16 consecutive unused item-art IDs per effect, checking current art,
   tile data, AnimData, art.def and server references. The helper does not find
   or certify free IDs, and different effects must not overlap.
3. Extract an individual ZIP and open PowerShell in its folder. Run:
   ./Prepare-Import.ps1 -BaseId YOUR_FREE_DECIMAL_OR_0xHEX_ID
   Replace the placeholder with your verified free base. The helper checks
   native-frame hashes and writes an Import directory inside that package only.
   It refuses to replace an existing Import directory. Regenerate after moving
   the extraction folder because UOFiddler import paths are absolute.
4. Use UOFiddler MassImport with Import/massimport.xml, then import
   Import/animdata.json through AnimData JSON import. Save to the development
   client copy and verify it. No installed client is edited by the helper.

ANIMATION BASES
base+0: full cast, 3000 ms, 60 nominal ticks.
base+4: attack and decay, 1800 ms, 36 nominal ticks.
base+12: decay only, 600 ms, 12 nominal ticks.
Offsets in each record are relative to its own base. Only these three bases
are Animated; other tiles are frames. Tile height and weight are zero.
The full cast already contains attack and decay; do not chain every record
unless deliberately building repeated attacks. Limit lifetime and remove each
instance; AnimData alone does not guarantee one-shot playback.

Canvas: 384x384. Ground/focus registration is recorded per frame in the manifest.
Additive blend 2: Worldbreaker Inferno, Heavenfall Judgment.
Normal blend 0: Cathedral of Ruin, Ossuary Apocalypse, The Final Sentence,
Leviathan's Last Bite. Normal blending preserves dark chitin/metal and shaded ice.

Public packages exclude stock character art, source atlases, personal paths,
accounts, saves, credentials, private workspace notes and test output.


Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
