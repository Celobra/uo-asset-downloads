# Black Tentacle: cosmetic and attack versions

Both versions use the same naturalistic black tentacle: it breaks through the earth, rises into a curl, then withdraws. Sixteen frames last 3.2 seconds. The spell stays rooted at its cast location if the caster moves.

| Command | Behavior |
|---|---|
| `.black_tentacle` | Harmless cosmetic effect |
| `.black_tentacle_preview` | Alias for the harmless effect |
| `.black_tentacle_attack` | Damaging version |

The attack deals 25 physical damage before mitigation once at frame 8, approximately 1.6 seconds after casting. Default reach is a circular radius of one tile: cardinal neighbors are included; diagonal neighbors are outside. Both versions share a 12-second cooldown per caster. The art has a curling strike rather than a new sweeping whip animation.

## Import into a development copy

1. Back up your client data and use a separate development copy. Close programs using that copy.
2. Select 16 consecutive free item-art IDs. Check artwork, tile data, animation references, art.def and server references. This package has no default destination ID.
3. In PowerShell, from this extracted folder, run `powershell -ExecutionPolicy Bypass -File .\Prepare-Import.ps1 -BaseId YOUR_FREE_ID`, replacing YOUR_FREE_ID with the verified first ID.
4. Use UOFiddler Mass Import with `Import/massimport.xml`; save art.mul, artidx.mul and tiledata.mul to the development copy. All 16 tiles are zero-height and deliberately non-animated. No AnimData import is required: Sphere selects each frame at 200ms intervals. Normal rendering preserves the black skin.
5. Put the generated `Import/black_tentacle.scp` into your server's `scripts/effects` folder. Register `effects/` once in the resource-file section of spheretables.scp if that folder is not already loaded. Keep existing scripts in place; do not relocate other content.
6. Start the normal client against matching data and use the commands above as a GM. Verify appearance and placement before live deployment.

Import preparation writes only a new Import subfolder and refuses to overwrite one. Regenerate it after moving the extracted package, because XML image paths are generated for your machine. Share the original ZIP, not the generated Import folder. This is an item-art spell effect; a creature-animation VD cannot carry this working implementation.

## Boss integration and configuration

Call `f_black_tentacle` on a boss from its attack sequence. Alternatively opt a boss in with `TEVENTS=e_boss_black_tentacle` for a 25 percent cast attempt on incoming hits, subject to cooldown. Nothing is attached automatically. Player spell bindings must invoke the trusted function after your own targeting, mana, skill and eligibility checks; no spellbook entry or resource cost is added here.

Config defaults are `black_tentacle_damage=25`, `black_tentacle_radius=1`, `black_tentacle_cooldown_ms=12000` and height tolerance 8. Per-caster positive tags `black_tentacle_damage` and `black_tentacle_radius` override damage/radius. Radius is restricted to 1–3; increasing it widens damage without enlarging the sprite, so keep the default unless you deliberately want a broader hit area. Use the cosmetic command for zero damage. Valid cooldown is 3200–120000ms.

Eligible targets are online players and player-owned pets; other NPCs require `TAG.black_tentacle_target=1`. GMs, the caster, its own pets, dead/invulnerable/stone targets, safe regions and matching positive `TAG.black_tentacle_team` allies are excluded. Owners' team tags also protect pets. Terrain height and line of sight restrict hits. Targets can move out during the emergence; only those in range at the strike are hit, once per cast. Damage uses normal physical mitigation and caster attribution.

An invisible NOSAVE controller holds the fixed cast origin and cooldown. Caster death, deletion or map change cancels an active sequence; any effect already sent can finish its 200ms pulse. It does not modify world terrain or create a blocking tentacle creature. The ground crack is artwork only. No accounts, saves, permanent stats or client executable changes are required.

## Acceptance checks


