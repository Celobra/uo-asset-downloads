Empowering Aura

Before importing: close the client and asset editors, check access to every file to be saved, and back up the current development data. Use verified unused destination IDs. Keep MUL/IDX pairs together, preserve other entries and use the data bank/container the client actually reads. These downloads do not contain UO client data, accounts or world saves. Install matching client art for every player. Check the result in game before using it on a live shard.

Native PNG frames and timing data only. Import the frames at verified unused item-art IDs, preserve their canvases/anchors and configure AnimData and server phase playback using frames.json. No import helper, damage or buff script is included.
