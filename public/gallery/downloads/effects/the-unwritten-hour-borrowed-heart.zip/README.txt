The Borrowed Heart
A pearl opens into an elongated crystal heart, threaded with pale gold and turquoise light, suspended at the eclipse's center.
Duration: 6400 ms; placement: behind-player; blend: additive

THE HOUR THAT NEVER HAPPENED

An original Ultima Online spell in three synchronized layers: The Broken Eclipse, The Borrowed Heart and The Unfallen Stars. A black mirrored eclipse opens around a luminous crystal heart; falling star fragments spread outward, pause at maximum spread, then retrace their paths into one suspended seed.

The reversal is encoded in the supplied AnimData timelines and uses the same native art frames in reverse order. It is not just a browser playback trick. This is artwork and import preparation; no gameplay or installation is supplied.

STAGING
Start all three layers together at the same world ground location. All canvases are 448x496; eclipse and heart have ground focus (224,420), while stars use (224,340) to leave room below for their falling trails. Their suspended seed centers align above the player. Eclipse uses NORMAL blending; heart and stars use ADDITIVE blending. Draw the shell and heart behind the actor. The preview splits the stars into back/front portions at ground Y-16. Native world-height placement, actor occlusion, effect phase and blend behavior require in-game integration.

The complete cycle lasts 6400 ms nominal. Frames 0 through 15 unfold the effect; frames 15 through 0 recall it exactly. Each frame is held for two 100 ms nominal ticks (FrameInterval=2). The repeated maximum frame gives a 400 ms pause at the turning point. At the end only the small seed remains; remove all layers at 6400 ms. Actual scheduling can differ.

NATIVE RECORDS
Each layer has 16 unique native frames and three relative AnimData entry points:
- Base+0: full-reversal, 64 tick entries, 6400 ms.
- Base+4: unfold-only, frames 4..15, 24 tick entries, 2400 ms.
- Base+12: recall-only, frames 15..0, 32 tick entries, 3200 ms.
The recall-only record deliberately uses signed negative frame offsets. Do not clamp them to zero. Only bases 0,4,12 carry Animated. AnimData can repeat while an effect persists, so the integration must provide the intended lifetime and cleanup. The unfold-only entry omits the earliest seed frames; it is useful after a separate opening cue.

No art IDs are allocated or reserved. Each layer needs its own block of 16 verified-unused item-art slots. Inspect current client data and references before choosing IDs, and back up current destination files before import.

Extract a layer ZIP, then run Prepare-Import.ps1 with -BaseId and your chosen starting item-art ID. For example, -BaseId 0x7000 is syntax only, not a reservation. The helper verifies native frame hashes and creates Import/massimport.xml, tiledata.csv, animdata.json and selected-range.txt inside the extracted layer. It does not modify any client or server files. Keep or rename an existing Import folder before generating different paths or IDs.

Use compatible UOFiddler mass-import tooling for item art and tile data; load AnimData JSON separately using tooling that preserves signed offsets and FrameInterval=2. Each of the three layers requires a distinct unused ID range. Never crop each frame to its changing silhouette: preserve the common canvas and anchor.

Runtime/import edition: native files, required import helpers and setup notes only. Read SHA256SUMS.txt for package checksums.
