# Soul Grasp

Sixteen original-style spectral-hand item-art frames, with a tested Sphere X script. One target, eight-tile cast range, a 1.2-second formation, one 10-cold-damage pulse, three-second slow and 0.6-second dissolve. Cold resistance applies. The animation follows the target. Shared caster cooldown: 12 seconds. Existing active visuals/slows do not stack.

## Install into a development copy first

1. Back up art.mul, artidx.mul, tiledata.mul and your Sphere resource list. Close client, server and asset editors before writing.
2. Choose sixteen consecutive unused item-art IDs. Check current art, tile data, scripts and art.def mappings; this package reserves no IDs.
3. Run Prepare-Import.ps1 -BaseId 0xYOURBASE from the extracted folder. It verifies frame hashes and generates Import/massimport.xml, tiledata.csv and the remapped script. Do not move the extracted folder after preparation; generated import paths refer to that location.
4. Import the item-art and tile-data entries using UOFiddler into the development copy. Use MUL item art, retain static zero-height flags, and import all sixteen frames. No AnimData changes. If your client routes art through UOP, use a compatible verified workflow before deployment.
5. Place generated soul_grasp.scp under scripts/effects and register effects/soul_grasp.scp in spheretables.scp if it is not already loaded. Restart Sphere and the client. Avoid duplicate resource registrations.

## Commands

.soul_grasp opens a character targeting cursor and casts the damaging spell. .soul_grasp_preview plays the harmless effect on yourself. Commands require GM level 4. Scripts may call f_soul_grasp with the target UID on the caster; do not expose internal functions to untrusted callers.

The spell rejects dead/offline targets, map changes, range/line-of-sight failures, invulnerable/stone/GM targets, safe regions, the caster and its own pets. Matching positive TAG.soul_grasp_team values are friendly. Configure range/damage/cooldown in the DEFNAME section. No boss event or spellbook entry is automatically assigned. Target legality for custom guild/party/criminal systems needs shard-specific integration.

Players use Sphere's slow movement mode (walking on the normal compatible client); existing stronger slow/freeze modes are preserved. NPCs temporarily use the old-style movement calculation with a larger delay multiplier. Previous settings are restored conditionally so a different intervening setting is retained. The temporary equipped restorer and its timed callback are saved; restart restoration is tested. Death/logout/login cleanup is included. Generic scripts concurrently writing the same speed settings must coordinate their own status ownership.

## Art and distribution

Frames are 96x96 with fixed scale and ground registration. Normal blending preserves muted colours. Source alpha becomes native binary transparency in MUL; actual ClassicUO decoding was checked. This is an item-art spell package, not a creature/body animation: VD is not the compatible format. Distribute this complete ZIP.
