# Fire nova: portable boss attack

A one-second ember warning is followed by a wave of fire expanding five tiles from the cast origin. The wave checks for targets as it advances; a target can be hit once per wave. The default is 25 fire damage before mitigation, one wave, and a 12-second cooldown. These are starting values for playtesting, not a claim of encounter balance.

This package contains custom artwork, import preparation, and a Sphere X script. It contains no original client files, accounts, world saves, private logs, server addresses, credentials, or personal paths. It does not need an AI service to install or use.

## Requirements and setup

Use a development copy of a UO 2D client data set, ClassicUO, Sphere X with `TIMERFMS` and `EFFECTLOCATION`, and UOFiddler with MassImport and AnimData JSON import. The supplied art is an animated effect, not a creature `.vd`.

1. Close the client, server, and asset editors. Back up the client data and server scripts. Configure UOFiddler to read a development copy and save to a separate output folder.
2. Extract the ZIP. Find **24 consecutive unused item-art IDs**, checking Items, TileData, AnimData, art mappings, and server script references. The suggested range is `0x5040` through `0x5057`; it is not guaranteed free on another installation.
3. Open PowerShell in the extracted folder and run:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File .\Prepare-Import.ps1 -BaseId 0x5040
   ```

   Substitute your chosen first ID. This prepares files only inside the package. It does not modify a client or server. The execution-policy option applies only to that process. If Windows blocks a downloaded script, inspect it and use `Unblock-File .\Prepare-Import.ps1` before running it.
4. In UOFiddler's MassImport plugin, load `Import\massimport.xml`. Expect **48 valid entries**: 24 art frames and 24 tile-data records. Verify every destination is free before importing; MassImport can replace occupied entries. Import and save the art and tile data to the output folder.
5. In AnimData, import `Import\animdata.json`. Leave **Erase existing data unchecked**, and choose the option that keeps existing entries on conflict. Expect **two imported entries**. If either conflicts, inspect it instead of overwriting it. Save `animdata.mul`.
6. The first reserved ID is the warning animation: 20 steps, FrameInterval 1, FrameStart 0. The ID eight slots later is the burst: 16 steps, FrameInterval 1, FrameStart 0. These two tile-data records have the Animation flag; all 24 have height zero. Preserve every PNG's 64 by 96 pixel canvas and alignment.
7. Close UOFiddler and deploy its output into the development data folder. A MUL installation needs the edited `art.mul`, `artidx.mul`, `tiledata.mul`, and `animdata.mul`. For UOP art, save and deploy the art container the client actually reads, plus tile and animation data. Check routing if both MUL and UOP exist. Do not modify creature-body `anim.mul` or `anim.idx` for this effect.
8. Copy `Import\fire_nova.scp` to a custom script folder loaded once by Sphere's `spheretables.scp`. Check for existing definitions using the same function, item, event, or config names before adding it.
9. Start the normal development server and ClassicUO client. As a GM, use `.fire_nova_preview` for a harmless visual check. Wait for its cooldown before the next cast. Use `.fire_nova` outside a safe region to exercise damage against valid targets.
10. Verify the wave while standing, moving, and mounted, and in the intended boss arena. Test walls, doors, stairs, floors, slopes, and client latency there. Check damage balance with ordinary player characters and pets before enabling it for encounters. Every viewer needs the matching custom client assets.

MassImport resolves relative filenames against its process working directory. The preparation script therefore generates absolute paths for the recipient's extracted folder. They are not included in this ZIP. Keep the folder in place until import finishes; rename the generated `Import` folder and rerun preparation if you move it or choose other art IDs.

## Attach it to a boss

The script does not automatically change any existing monster. For a reactive attack, add this line to the chosen boss's existing `CHARDEF` alongside its other events:

```scp
TEVENTS=e_boss_fire_nova
```

That event attempts the nova on 25 percent of incoming hits. The cooldown prevents overlapping casts from the same boss. Its event returns normally so the rest of the boss's hit handling can continue.

For a boss with its own scripted attack sequence, call this function on the boss at the desired point instead:

```scp
f_fire_nova
```

The return value is 1 when a cast starts and 0 when rejected, such as during cooldown, after death, or in a safe region. A harmless preview may start in a safe region.

## Configuration

Edit the `fire_nova_config` section in the generated Sphere script:

| Setting | Default | Meaning |
| --- | ---: | --- |
| `fire_nova_damage` | 25 | Fire damage before the server's mitigation |
| `fire_nova_windup_ms` | 1000 | Warning time; 500 to 3000 milliseconds |
| `fire_nova_step_ms` | 300 | Time per expanding ring; 100 to 600, in multiples of 100 |
| `fire_nova_cooldown_ms` | 12000 | Minimum time between casts; capped at 120000 |
| `fire_nova_waves` | 1 | One to three successive waves |
| `fire_nova_wave_gap_ms` | 800 | Gap between waves; 100 to 3000 milliseconds |
| `fire_nova_height_tolerance` | 8 | Maximum elevation difference in UO Z units |

The radius is fixed at five tiles. The cooldown is raised automatically if needed to outlast the chosen wave sequence. Target checks occur every 100 milliseconds while the leading ring is active. Lingering embers behind that ring are cosmetic.

Optional tags on an individual boss override damage and wave count:

```scp
TAG.fire_nova_damage=25
TAG.fire_nova_waves=2
TAG.fire_nova_team=7
```

Damage overrides must be positive and at most 5000. The team number is optional: characters, or pet owners, with the same positive `TAG.fire_nova_team` are excluded. A boss's own pets are also excluded.

By default the attack targets online players and player-owned pets, excluding GMs, dead, invulnerable, or stone characters. Other NPCs are ignored unless they have `TAG.fire_nova_target=1`; this is useful for a training dummy or an explicitly hostile NPC. Characters in safe regions are spared. The ordinary Sphere damage pipeline also handles its combat permissions and immunities.

The damage call identifies the caster and supplies a 100 percent fire split. Fire resistance applies when Sphere's elemental combat engine is enabled. On other combat configurations, the server's existing mitigation rules apply. This package does not change those server settings.

## Placement, timing, and cleanup

The cast origin remains fixed if the boss moves. Each valid tile is anchored with Sphere's native ground-height adjustment, and line of sight is checked during preparation. Targets are checked against the same tile/ring geometry and a fresh line of sight back to that origin. Shape is circular: cardinal points five tiles away are included, but offsets of four tiles in both X and Y are outside it.

The controller is invisible, has zero height, and uses `TAG.NOSAVE` so it is excluded from world saves. It retains per-wave hit markers and clears its caster reference when removed. Death, deletion, or a map change of the caster cancels the remaining attack; normal cooldown completion also removes the controller. Effects expire in the client. No permanent fire-field items are created.

The tested ClassicUO fixed-effect renderer uses 50-millisecond animation ticks and additive blend mode 2. The default warning lasts one second, each tile burst lasts 0.8 seconds, and the complete single-wave visual finishes at about three seconds. Client forks and network delay can affect perceived synchronization; the server is authoritative for damage.
